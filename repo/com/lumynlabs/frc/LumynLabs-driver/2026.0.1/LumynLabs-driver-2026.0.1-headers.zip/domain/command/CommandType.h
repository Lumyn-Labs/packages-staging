#pragma once

#include <cinttypes>

#include "led/LEDCommand.h"
#include "system/SystemCommand.h"

namespace lumyn::internal::Command
{
  // 8-bit identifier for API grouping
  enum class APIGroupType : uint8_t
  {
    System,
    LED,
    Device,
  };
} // namespace lumyn::internal::Command