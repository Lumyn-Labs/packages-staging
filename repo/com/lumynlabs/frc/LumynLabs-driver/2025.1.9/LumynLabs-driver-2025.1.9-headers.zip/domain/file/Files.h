#pragma once

#include <cinttypes>

#include "FileType.h"
#include "packed.h"

namespace lumyn::internal::Files
{
  PACK(struct FileTransferInfoHeader {
    char path[32];
  });

  PACK(struct SendConfigInfoHeader{});

  PACK(struct FilesHeader {
    FileType type;
    union
    {
      FileTransferInfoHeader fileTransfer;
      SendConfigInfoHeader sendConfig;
    };
    uint16_t md5;
    uint32_t fileSize;
  });

  PACK(struct Files {
    FilesHeader header;
    uint8_t *bytes;
  });
} // namespace lumyn::internal::Files