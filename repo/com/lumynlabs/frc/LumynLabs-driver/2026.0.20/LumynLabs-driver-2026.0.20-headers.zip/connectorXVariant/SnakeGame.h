#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>
#include <vector>
#include <random>

namespace lumyn::internal::c_ConnectorX {

class SnakeGame {
public:
    SnakeGame() : showWindow_(false), gameWidth_(20), gameHeight_(20), 
                  snakeDir_{1, 0}, food_{10, 10}, gameOver_(false), score_(0),
                  moveTimer_(0.0f), moveInterval_(0.2f) {
        snake_.push_back({5, 5});
        snake_.push_back({4, 5});
        snake_.push_back({3, 5});
        generateFood();
    }
    
    ~SnakeGame() = default;

    void update(float deltaTime) {
        if (!showWindow_ || gameOver_) return;
        
        moveTimer_ += deltaTime;
        if (moveTimer_ >= moveInterval_) {
            moveTimer_ = 0.0f;
            moveSnake();
        }
    }
    
    void render() {
        if (!showWindow_) return;
        
        if (ImGui::Begin("Snake Game", &showWindow_)) {
            if (gameOver_) {
                ImGui::Text("Game Over! Score: %d", score_);
                if (ImGui::Button("Restart")) {
                    resetGame();
                }
            } else {
                handleInput();
                renderGame();
                ImGui::Text("Score: %d", score_);
                ImGui::Text("Use WASD to move");
            }
        }
        ImGui::End();
    }
    
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    struct Point {
        int x, y;
        bool operator==(const Point& other) const {
            return x == other.x && y == other.y;
        }
    };
    
    bool showWindow_;
    int gameWidth_, gameHeight_;
    std::vector<Point> snake_;
    Point snakeDir_;
    Point food_;
    bool gameOver_;
    int score_;
    float moveTimer_;
    float moveInterval_;
    std::mt19937 rng_{std::random_device{}()};

    void handleInput() {
        if (ImGui::IsKeyPressed(ImGuiKey_W) && snakeDir_.y != 1) snakeDir_ = {0, -1};
        if (ImGui::IsKeyPressed(ImGuiKey_S) && snakeDir_.y != -1) snakeDir_ = {0, 1};
        if (ImGui::IsKeyPressed(ImGuiKey_A) && snakeDir_.x != 1) snakeDir_ = {-1, 0};
        if (ImGui::IsKeyPressed(ImGuiKey_D) && snakeDir_.x != -1) snakeDir_ = {1, 0};
    }
    
    void moveSnake() {
        Point newHead = {snake_[0].x + snakeDir_.x, snake_[0].y + snakeDir_.y};
        
        // Check wall collision
        if (newHead.x < 0 || newHead.x >= gameWidth_ || 
            newHead.y < 0 || newHead.y >= gameHeight_) {
            gameOver_ = true;
            return;
        }
        
        // Check self collision
        for (const auto& segment : snake_) {
            if (newHead == segment) {
                gameOver_ = true;
                return;
            }
        }
        
        snake_.insert(snake_.begin(), newHead);
        
        // Check food collision
        if (newHead == food_) {
            score_ += 10;
            generateFood();
        } else {
            snake_.pop_back();
        }
    }
    
    void generateFood() {
        std::uniform_int_distribution<int> xDist(0, gameWidth_ - 1);
        std::uniform_int_distribution<int> yDist(0, gameHeight_ - 1);
        
        do {
            food_ = {xDist(rng_), yDist(rng_)};
        } while (std::find(snake_.begin(), snake_.end(), food_) != snake_.end());
    }
    
    void renderGame() {
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 canvas_pos = ImGui::GetCursorScreenPos();
        float cellSize = 15.0f;
        
        // Draw grid
        for (int x = 0; x <= gameWidth_; x++) {
            draw_list->AddLine(
                ImVec2(canvas_pos.x + x * cellSize, canvas_pos.y),
                ImVec2(canvas_pos.x + x * cellSize, canvas_pos.y + gameHeight_ * cellSize),
                IM_COL32(100, 100, 100, 255)
            );
        }
        for (int y = 0; y <= gameHeight_; y++) {
            draw_list->AddLine(
                ImVec2(canvas_pos.x, canvas_pos.y + y * cellSize),
                ImVec2(canvas_pos.x + gameWidth_ * cellSize, canvas_pos.y + y * cellSize),
                IM_COL32(100, 100, 100, 255)
            );
        }
        
        // Draw snake
        for (size_t i = 0; i < snake_.size(); i++) {
            ImU32 color = (i == 0) ? IM_COL32(0, 255, 0, 255) : IM_COL32(0, 200, 0, 255);
            draw_list->AddRectFilled(
                ImVec2(canvas_pos.x + snake_[i].x * cellSize + 1, 
                       canvas_pos.y + snake_[i].y * cellSize + 1),
                ImVec2(canvas_pos.x + (snake_[i].x + 1) * cellSize - 1, 
                       canvas_pos.y + (snake_[i].y + 1) * cellSize - 1),
                color
            );
        }
        
        // Draw food
        draw_list->AddRectFilled(
            ImVec2(canvas_pos.x + food_.x * cellSize + 1, 
                   canvas_pos.y + food_.y * cellSize + 1),
            ImVec2(canvas_pos.x + (food_.x + 1) * cellSize - 1, 
                   canvas_pos.y + (food_.y + 1) * cellSize - 1),
            IM_COL32(255, 0, 0, 255)
        );
        
        ImGui::Dummy(ImVec2(gameWidth_ * cellSize, gameHeight_ * cellSize));
    }
    
    void resetGame() {
        snake_.clear();
        snake_.push_back({5, 5});
        snake_.push_back({4, 5});
        snake_.push_back({3, 5});
        snakeDir_ = {1, 0};
        gameOver_ = false;
        score_ = 0;
        moveTimer_ = 0.0f;
        generateFood();
    }
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
