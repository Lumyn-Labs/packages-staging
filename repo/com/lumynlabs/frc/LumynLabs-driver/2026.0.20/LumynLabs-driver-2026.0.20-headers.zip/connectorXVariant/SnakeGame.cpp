#ifdef DESKTOP
#include "SnakeGame.h"
#include <algorithm>
#include <ctime>
#include <cstdlib>

namespace lumyn::internal::c_ConnectorX {

SnakeGame::SnakeGame()
    : showWindow_(false)
    , gameActive_(false)
    , gridWidth_(20)
    , gridHeight_(15)
    , gameTime_(0.0f)
    , updateInterval_(0.30f)
    , lastUpdateTime_(0.0f)
    , direction_(2)
    , nextDirection_(2)
    , score_(0)
    , gameOver_(false)
    , food_{0, 0}
{
}

void SnakeGame::update(float deltaTime) {
    if (!showWindow_ || (!gameActive_ && !gameOver_)) {
        return;
    }

    gameTime_ += deltaTime;
    
    if (gameActive_ && !gameOver_ && gameTime_ - lastUpdateTime_ >= updateInterval_) {
        updateGameLogic();
    }
}

void SnakeGame::render() {
    if (!showWindow_) {
        return;
    }

    ImGui::Begin("Lumyn Snake Game", &showWindow_);
    
    // Initialize snake game if not active
    if (!gameActive_ && !gameOver_) {
        initialize();
    }
    
    // Fixed width for game layout to prevent shifting
    ImVec2 gameSize(gridWidth_ * GRID_SIZE + 40, gridHeight_ * GRID_SIZE + 120);
    ImGui::BeginChild("SnakeGameArea", gameSize, false);
    
    // Game controls explanation
    ImGui::Text("Controls: Arrow keys or WASD to move");
    ImGui::Text("Score: %d", score_);
    
    if (gameOver_) {
        ImGui::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "GAME OVER! Press spacebar to restart");
        
        // Check for spacebar to restart
        if (ImGui::IsKeyPressed(ImGuiKey_Space)) {
            initialize();
        }
        
        // Keep the Restart button (same size as Pause button) for mouse users
        float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
        ImGui::SetCursorPosX((gameSize.x - buttonWidth) * 0.5f);
        if (ImGui::Button("Restart Game", ImVec2(buttonWidth, 0))) {
            initialize();
        }
    }
    
    // Pause/Resume button - center it
    if (!gameOver_) {
        float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
        ImGui::SetCursorPosX((gameSize.x - buttonWidth) * 0.5f);
        if (ImGui::Button(gameActive_ ? "Pause Game" : "Resume Game", ImVec2(buttonWidth, 0))) {
            gameActive_ = !gameActive_;
        }
    }
    
    processInput();
    renderGame();
    
    ImGui::EndChild(); // End the fixed-size game area
    ImGui::End(); // End Snake Game window
}

void SnakeGame::initialize() {
    snakeBody_.clear();
    snakeBody_.push_back({gridWidth_ / 2, gridHeight_ / 2}); // Head
    snakeBody_.push_back({gridWidth_ / 2 - 1, gridHeight_ / 2}); // Initial body
    snakeBody_.push_back({gridWidth_ / 2 - 2, gridHeight_ / 2}); // Initial body
    
    generateFood();
    
    direction_ = 1; // Start moving right
    nextDirection_ = 1;
    score_ = 0;
    gameOver_ = false;
    gameActive_ = true;
    gameTime_ = 0.0f;
    lastUpdateTime_ = 0.0f;
}

void SnakeGame::processInput() {
    if (!gameOver_ && gameActive_) {
        // Up: Arrow Up or W
        if ((ImGui::IsKeyPressed(ImGuiKey_UpArrow) || ImGui::IsKeyPressed(ImGuiKey_W)) && direction_ != 2)
            nextDirection_ = 0;
        // Right: Arrow Right or D
        else if ((ImGui::IsKeyPressed(ImGuiKey_RightArrow) || ImGui::IsKeyPressed(ImGuiKey_D)) && direction_ != 3)
            nextDirection_ = 1;
        // Down: Arrow Down or S
        else if ((ImGui::IsKeyPressed(ImGuiKey_DownArrow) || ImGui::IsKeyPressed(ImGuiKey_S)) && direction_ != 0)
            nextDirection_ = 2;
        // Left: Arrow Left or A
        else if ((ImGui::IsKeyPressed(ImGuiKey_LeftArrow) || ImGui::IsKeyPressed(ImGuiKey_A)) && direction_ != 1)
            nextDirection_ = 3;
    }
}

void SnakeGame::updateGameLogic() {
    lastUpdateTime_ = gameTime_;
    
    // Update direction
    direction_ = nextDirection_;
    
    // Calculate new head position
    SnakeSegment newHead = snakeBody_.front();
    switch (direction_) {
        case 0: newHead.y--; break; // Up
        case 1: newHead.x++; break; // Right
        case 2: newHead.y++; break; // Down
        case 3: newHead.x--; break; // Left
    }
    
    // Check for collisions with walls
    if (newHead.x < 0 || newHead.x >= gridWidth_ || 
        newHead.y < 0 || newHead.y >= gridHeight_) {
        gameOver_ = true;
        return;
    }
    
    // Check for collisions with self (except tail which will move)
    for (size_t i = 0; i < snakeBody_.size() - 1; i++) {
        if (newHead.x == snakeBody_[i].x && newHead.y == snakeBody_[i].y) {
            gameOver_ = true;
            return;
        }
    }
    
    // Check if eating food
    bool growing = (newHead.x == food_.x && newHead.y == food_.y);
    
    if (growing) {
        score_ += 10;
        
        // Make game faster as score increases but at a much slower rate
        updateInterval_ = std::max(0.1f, 0.30f - (score_ / 2000.0f));
        
        generateFood();
    }
    
    // Move snake: add new head
    snakeBody_.insert(snakeBody_.begin(), newHead);
    
    // Remove tail only if not growing
    if (!growing) {
        snakeBody_.pop_back();
    }
}

void SnakeGame::renderGame() {
    // Game area
    const ImVec2 boardPos = ImGui::GetCursorScreenPos();
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    
    // Draw board background
    ImVec2 boardSize(gridWidth_ * GRID_SIZE, gridHeight_ * GRID_SIZE);
    draw_list->AddRectFilled(
        boardPos,
        ImVec2(boardPos.x + boardSize.x, boardPos.y + boardSize.y),
        IM_COL32(20, 20, 20, 255));
    
    // Draw grid lines
    for (int i = 0; i <= gridWidth_; i++) {
        draw_list->AddLine(
            ImVec2(boardPos.x + i * GRID_SIZE, boardPos.y),
            ImVec2(boardPos.x + i * GRID_SIZE, boardPos.y + boardSize.y),
            IM_COL32(50, 50, 50, 255));
    }
    for (int i = 0; i <= gridHeight_; i++) {
        draw_list->AddLine(
            ImVec2(boardPos.x, boardPos.y + i * GRID_SIZE),
            ImVec2(boardPos.x + boardSize.x, boardPos.y + i * GRID_SIZE),
            IM_COL32(50, 50, 50, 255));
    }
    
    // Draw food
    draw_list->AddRectFilled(
        ImVec2(boardPos.x + food_.x * GRID_SIZE + 2, boardPos.y + food_.y * GRID_SIZE + 2),
        ImVec2(boardPos.x + (food_.x + 1) * GRID_SIZE - 2, boardPos.y + (food_.y + 1) * GRID_SIZE - 2),
        IM_COL32(255, 0, 0, 255));
    
    // Draw snake
    for (size_t i = 0; i < snakeBody_.size(); i++) {
        const auto& segment = snakeBody_[i];
        ImU32 snakeColor = (i == 0) ? 
            IM_COL32(0, 255, 0, 255) : // Head (green)
            IM_COL32(0, 200, 0, 255);  // Body (darker green)
            
        draw_list->AddRectFilled(
            ImVec2(boardPos.x + segment.x * GRID_SIZE + 1, boardPos.y + segment.y * GRID_SIZE + 1),
            ImVec2(boardPos.x + (segment.x + 1) * GRID_SIZE - 1, boardPos.y + (segment.y + 1) * GRID_SIZE - 1),
            snakeColor);
    }
    
    // Reserve space for the board in ImGui layout
    ImGui::Dummy(ImVec2(boardSize.x, boardSize.y));
}

void SnakeGame::generateFood() {
    // Place food at a random position not occupied by snake
    std::srand(static_cast<unsigned int>(std::time(nullptr)));
    do {
        food_.x = std::rand() % gridWidth_;
        food_.y = std::rand() % gridHeight_;
    } while (isFoodPosition(food_.x, food_.y));
}

bool SnakeGame::isFoodPosition(int x, int y) const {
    return std::any_of(snakeBody_.begin(), snakeBody_.end(), 
                      [x, y](const SnakeSegment& seg) { 
                          return seg.x == x && seg.y == y; 
                      });
}

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
