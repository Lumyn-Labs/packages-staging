#pragma once

#include "device/IDevice.h"
#include "networking/TransmissionPortListener.h"

namespace lumyn::internal
{
  class IConnectorXVariant
  {
  };
}