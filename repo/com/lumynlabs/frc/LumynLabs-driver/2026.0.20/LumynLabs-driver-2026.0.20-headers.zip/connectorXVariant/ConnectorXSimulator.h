#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>

namespace lumyn::internal::c_ConnectorX {

class ConnectorXSimulator {
public:
    ConnectorXSimulator() : ledCount_(16), connectorAnimTime_(0.0f), selectedZoneId_(0), status_("Disconnected") {
        zoneNames_[0] = "Zone 1";
        zoneNames_[1] = "Zone 2"; 
        zoneNames_[2] = "Zone 3";
        std::strcpy(textBuffer_, "Hello World");
        initializeLEDs();
    }
    
    ~ConnectorXSimulator() = default;

    void update(float deltaTime) {
        connectorAnimTime_ += deltaTime;
        updateLEDAnimations();
    }
    
    void render() {
        if (ImGui::Begin("ConnectorX Simulator")) {
            renderLEDStrip();
            renderControls();
            renderEventLog();
        }
        ImGui::End();
    }

private:
    // LED simulation variables
    std::vector<ImColor> ledColors_;
    int ledCount_;
    char textBuffer_[128];
    float scrollSpeed_[3];
    int animationSelector_[3];
    ImVec4 colorPicker_[3];
    bool animationRunning_[3];
    
    // Animation and control variables
    float connectorAnimTime_;
    int selectedZoneId_;
    const char* zoneNames_[3];
    std::string status_;
    std::vector<std::string> eventLog_;

    void initializeLEDs() {
        ledColors_.resize(ledCount_, ImColor(0.0f, 0.0f, 0.0f));
        for (int i = 0; i < 3; i++) {
            scrollSpeed_[i] = 1.0f;
            animationSelector_[i] = 0;
            colorPicker_[i] = ImVec4(1.0f, 0.0f, 0.0f, 1.0f);
            animationRunning_[i] = false;
        }
    }
    
    void updateLEDAnimations() {
        for (int i = 0; i < ledCount_; i++) {
            float phase = connectorAnimTime_ + i * 0.1f;
            float brightness = (std::sin(phase) + 1.0f) * 0.5f;
            ledColors_[i] = ImColor(brightness, brightness * 0.5f, brightness * 0.2f);
        }
    }
    
    void renderLEDStrip() {
        ImGui::Text("LED Strip Visualization");
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 canvas_pos = ImGui::GetCursorScreenPos();
        
        for (int i = 0; i < ledCount_; i++) {
            ImVec2 led_pos = ImVec2(canvas_pos.x + i * 25, canvas_pos.y);
            draw_list->AddCircleFilled(led_pos, 10, ledColors_[i], 12);
        }
        
        ImGui::Dummy(ImVec2(ledCount_ * 25, 25));
    }
    
    void renderControls() {
        ImGui::Separator();
        ImGui::Text("Controls");
        
        ImGui::Combo("Zone", &selectedZoneId_, zoneNames_, 3);
        ImGui::ColorEdit3("Color", (float*)&colorPicker_[selectedZoneId_]);
        ImGui::InputText("Text", textBuffer_, sizeof(textBuffer_));
        
        if (ImGui::Button("Set Color")) {
            logEvent("Color set for " + std::string(zoneNames_[selectedZoneId_]));
        }
        
        ImGui::SameLine();
        if (ImGui::Button("Set Text")) {
            logEvent("Text set for " + std::string(zoneNames_[selectedZoneId_]) + ": " + textBuffer_);
        }
    }
    
    void renderEventLog() {
        ImGui::Separator();
        ImGui::Text("Event Log");
        
        if (ImGui::BeginChild("EventLog", ImVec2(0, 100))) {
            for (const auto& event : eventLog_) {
                ImGui::Text("%s", event.c_str());
            }
        }
        ImGui::EndChild();
    }
    
    void logEvent(const std::string& event) {
        eventLog_.push_back(event);
        if (eventLog_.size() > 20) {
            eventLog_.erase(eventLog_.begin());
        }
    }
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
