#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>

namespace lumyn::internal::c_ConnectorX {

// Forward declarations
class SnakeGame;
class PongGame;

class GameMenu {
public:
    GameMenu() : showWindow_(false) {}
    ~GameMenu() = default;

    void render(SnakeGame& snakeGame, PongGame& pongGame) {
        if (!showWindow_) return;
        
        if (ImGui::Begin("Game Menu", &showWindow_)) {
            ImGui::Text("Available Games");
            ImGui::Separator();
            
            if (ImGui::Button("Snake", ImVec2(100, 40))) {
                snakeGame.setWindowOpen(true);
            }
            ImGui::SameLine();
            if (ImGui::Button("Pong", ImVec2(100, 40))) {
                pongGame.setWindowOpen(true);
            }
            
            ImGui::Separator();
            ImGui::Text("Game Controls:");
            ImGui::BulletText("Snake: Use WASD to move");
            ImGui::BulletText("Pong: Use W/S for left paddle");
            
            ImGui::Separator();
            if (ImGui::Button("Close All Games")) {
                snakeGame.setWindowOpen(false);
                pongGame.setWindowOpen(false);
            }
        }
        ImGui::End();
    }
    
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    bool showWindow_;
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
