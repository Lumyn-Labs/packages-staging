#pragma once

#include <units/time.h>
#include <optional>
#include <vector>
#include <string>
#include <cstddef>
#include "lumyn/connectorXVariant/ConnectorX.h"
#include "lumyn/util/serial/ISerialIO.h"
#include "lumyn/util/serial/UsbSerialIO.h"
#include "lumyn/util/serial/UartSerialIO.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/connection/UARTPort.h"

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include "ui/ConnectorXSimUI.h"
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, lumyn::connection::USBPort port);
    bool cx_ConnectUart(ConnectorX_int *, lumyn::connection::UARTPort port, int baud);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr, int maxCount);

  // If modules are enabled for the variant...
  // Returns latest data entries for the module id, if available (id + bytes)
  bool cx_GetLatestData(ConnectorX_int *, const char *, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor, Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor, Command::LED::MatrixTextScrollDirection, units::millisecond_t, bool);

    // Requests
    bool cx_RequestConfig(ConnectorX_int *, std::string &outJson);
    void cx_RestartDevice(ConnectorX_int *, uint16_t delayMs);
    void cx_ApplyConfigurationJson(ConnectorX_int *, const char *jsonData, size_t length);

    // Simulation helper
    void cx_SetDeployPath(const char* path);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP

  inline void initSimGui()
  {
    static bool initialized = false;
    if (initialized) {
      return;
    }
    initialized = true;
    
    HAL_RegisterExtensionListener(nullptr, [](void *, const char *name, void *data)
                                  {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiLateExecuteFn>(data)([]() {
          ConnectorXSimUI::GetInstance().render();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_ADDGUIINIT) {
        reinterpret_cast<::lumyn::internal::sim::AddGuiInitFn>(data)([]() {
          ConnectorXSimUI::GetInstance().init();
        });
      } else if (std::string_view{name} == HALSIMGUI_EXT_GETIMGUICONTEXT) {
        ImGuiContext* context = reinterpret_cast<::lumyn::internal::sim::GetImGuiContextFn>(data)();
        if (context) {
          ConnectorXSimUI::GetInstance().setImGuiContext(context);
        }
      }
    });
  }
#endif // DESKTOP
} // namespace lumyn::internal::c_ConnectorX
