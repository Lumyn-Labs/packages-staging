#pragma once

#include <chrono>
#include <units/time.h>

namespace lumyn::util {
    inline std::chrono::milliseconds toChronoMilliseconds(units::millisecond_t ms) {
        return std::chrono::milliseconds(static_cast<int64_t>(ms.value()));
    }
    
    inline units::millisecond_t toWpiMilliseconds(std::chrono::milliseconds ms) {
        return units::millisecond_t(ms.count());
    }
}