#pragma once

#include "lumyn/domain/event/Event.h"
#include <string>

namespace lumyn::utils {

std::string GetDisabledCauseText(lumyn::internal::Eventing::DisabledCause cause);
std::string GetErrorTypeText(lumyn::internal::Eventing::ErrorType type);
std::string GetFatalErrorTypeText(lumyn::internal::Eventing::FatalErrorType type);

} // namespace lumyn::utils

#ifdef __cplusplus
extern "C" {
#endif

const char* Lumyn_GetDisabledCauseText(int cause);
const char* Lumyn_GetErrorTypeText(int type);
const char* Lumyn_GetFatalErrorTypeText(int type);

#ifdef __cplusplus
}
#endif
