#pragma once

#include "lumyn/util/serial/ISerialIO.h"
#include <hal/SerialPort.h>
#include <cstdint>
#include <functional>
#include <memory>

namespace lumyn::internal {

class UsbSerialIOImpl; // Forward declaration

class UsbSerialIO : public ISerialIO {
public:
    UsbSerialIO(HAL_SerialPort port, int baud = 115200);
    ~UsbSerialIO() override;

    void writeBytes(const uint8_t* data, size_t length) override;
    void setReadCallback(std::function<void(const uint8_t*, size_t)> callback) override;

    bool open();
    void close();
    bool isOpen() const;

private:
    bool _isOpen;
    std::unique_ptr<UsbSerialIOImpl> _impl;
};

} // namespace lumyn::internal
