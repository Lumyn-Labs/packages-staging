#pragma once

#include "lumyn/util/serial/ISerialIO.h"
#include <hal/SerialPort.h>
#include <cstdint>
#include <functional>
#include <memory>

namespace lumyn::internal {

class UartSerialIOImpl; // Forward declaration

class UartSerialIO : public ISerialIO {
public:
    UartSerialIO(HAL_SerialPort port, int baud = 115200);
    ~UartSerialIO() override;

    void writeBytes(const uint8_t* data, size_t length) override;
    void setReadCallback(std::function<void(const uint8_t*, size_t)> callback) override;

    bool open();
    void close();
    bool isOpen() const;

private:
    bool _isOpen;
    std::unique_ptr<UartSerialIOImpl> _impl;
};

} // namespace lumyn::internal
