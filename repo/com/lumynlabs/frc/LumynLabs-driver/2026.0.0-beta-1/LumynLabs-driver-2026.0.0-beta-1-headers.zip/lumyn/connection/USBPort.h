#pragma once

#include <hal/SerialPort.h>
#include <stdexcept>

namespace lumyn {
namespace connection {

// These values correspond to the HAL SerialPort usb ports.
enum class USBPort {
    kUSB1 = 2,
    kUSB2 = 3
};

inline HAL_SerialPort toHalSerialPort(USBPort port) {
    switch (port) {
        case USBPort::kUSB1:
            return HAL_SerialPort_USB1;
        case USBPort::kUSB2:
            return HAL_SerialPort_USB2;
        default:
            throw std::invalid_argument("Invalid USBPort value encountered in toHalSerialPort.");
    }
}

} // namespace connection
} // namespace lumyn 