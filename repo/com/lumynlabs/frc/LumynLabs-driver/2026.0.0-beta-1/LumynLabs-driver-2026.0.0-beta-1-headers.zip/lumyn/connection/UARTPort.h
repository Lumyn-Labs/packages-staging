#pragma once

#include <hal/SerialPort.h>
#include <stdexcept>

namespace lumyn {
namespace connection {

// RoboRIO UART ports
enum class UARTPort {
    kMXP = HAL_SerialPort_MXP
};

inline HAL_SerialPort toHalSerialPort(UARTPort port) {
    switch (port) {
        case UARTPort::kMXP:
            return HAL_SerialPort_MXP;
        default:
            throw std::invalid_argument("Invalid UARTPort value encountered in toHalSerialPort.");
    }
}

} // namespace connection
} // namespace lumyn
