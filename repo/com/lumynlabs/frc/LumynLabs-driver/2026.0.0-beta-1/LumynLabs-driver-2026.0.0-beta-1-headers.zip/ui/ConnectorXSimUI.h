#pragma once

// class for handling imgui in connectorX simulation
#ifdef DESKTOP
#include <imgui.h>

namespace lumyn::internal
{
  class ConnectorXSimUI
  {
  public:
    static ConnectorXSimUI& GetInstance();
    
    void init();
    void render();
    void shutdown();
    void setImGuiContext(ImGuiContext* context);

  private:
    ConnectorXSimUI();
    ~ConnectorXSimUI();
    
    void DrawDeviceTab();
    void DrawLedTab();
    void DrawModulesTab();
    void DrawStatusControls();

    // Delete copy constructor and assignment operator
    ConnectorXSimUI(const ConnectorXSimUI&) = delete;
    ConnectorXSimUI& operator=(const ConnectorXSimUI&) = delete;
    
    ImGuiContext* m_imguiContext;
  };

} // namespace lumyn::internal


#endif // DESKTOP
