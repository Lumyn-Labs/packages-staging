#pragma once

#ifdef DESKTOP
#include <hal/SimDevice.h>
#include "lumyn/domain/event/Event.h"
#include "lumyn/domain/event/EventType.h"
#include "lumyn/domain/response/Response.h"
#include "lumyn/version.h"
#include <array>
#include <atomic>
#include <deque>
#include <functional>
#include <mutex>
#include <optional>
#include <string>
#include <vector>
#include "lumyn/configuration/Configuration.h"
#include <unordered_map>
#include "lumyn/domain/command/led/LEDCommand.h"
#include "lumyn/definitions/led/AnimationInstance.h"
#include "lumyn/domain/device/ConnectorXSimTypes.h"
#include "lumyn/domain/module/ModulePayloadDescriptor.h"
#include "lumyn/util/hashing/MD5.h"
#include <atomic>

namespace lumyn::internal {
    class ConnectorXSimDevice {
    public:
        using SimProductSku = connectorx::sim::SimProductSku;
        using ConfiguredModule = connectorx::sim::ConfiguredModule;
        using ZoneState = connectorx::sim::ZoneState;
        static constexpr auto &kStatusOptions = connectorx::sim::kStatusOptions;

    private:
        hal::SimDevice m_simDevice;
        hal::SimBoolean m_connected;
        hal::SimEnum m_connectionTypeEntry;
        hal::SimEnum m_statusEntry;
        hal::SimInt m_channelCountValue;
        hal::SimInt m_zoneCountValue;
        hal::SimInt m_moduleCountValue;
        mutable std::mutex m_configMutex;
        std::vector<lumyn::internal::Configuration::Channel> m_channels;
        std::vector<std::pair<std::string, std::string>> m_moduleConfig;
        std::unordered_map<uint16_t, lumyn::internal::Configuration::Bitmap> m_bitmapConfig;
        mutable std::optional<lumyn::internal::Configuration::LumynConfiguration> m_appliedConfig;
        
        mutable std::mutex m_eventMutex;
        std::deque<connectorx::sim::EventHistoryEntry> m_eventQueue;
        std::deque<connectorx::sim::EventHistoryEntry> m_eventHistory;
        static constexpr size_t kMaxEventHistory = 100;

        std::unordered_map<uint16_t, ZoneState> m_zones;
        
        // Track last known connection state to detect external changes
        bool m_lastConnectedState;
        // Track last known status value to detect external changes
        int m_lastStatusValue;
        std::atomic<Eventing::ConnectionType> m_connectionType{Eventing::ConnectionType::USB};

        void ApplyLED_(const Command::LED::LEDCommand &led);

    public:
        ConnectorXSimDevice();
        
        static ConnectorXSimDevice& GetInstance() {
            static ConnectorXSimDevice instance;
            return instance;
        }
        
        void SetConnected(bool connected);
        bool GetConnected();
        void SetConnectionType(Eventing::ConnectionType type);
        Eventing::ConnectionType GetConnectionType() const;
        void SetStatus(Eventing::Status status);
        Eventing::Status GetStatus();
        void SetStatusFromInt(int status);

        void SetSku(connectorx::sim::SimProductSku sku);
        
        static constexpr const char* kDeviceName = "ConnectorX";
        static constexpr int kDeviceIndex = 0;

        static const char* StatusToString(Eventing::Status status);
        static Eventing::Status IntToStatus(int statusInt);

        Response::ResponseHandshakeInfo GetHandshakeInfo();

        void PushEvent(const Eventing::Event& evt);
        bool TryPopLatestEvent(Eventing::Event& out);
        int TryPopAllEvents(Eventing::Event* out, int maxCount);
        std::vector<connectorx::sim::EventHistoryEntry> PeekRecentEvents(size_t maxEvents) const;
        bool RemoveEventByTimestamp(double timestampSec);
        void ClearAllEvents();

        // Configuration API (simulation only)
        void ApplyConfiguration(const lumyn::internal::Configuration::LumynConfiguration& config);
        void ClearConfiguration();
        std::vector<lumyn::internal::Configuration::Channel> GetChannelsCopy();
        std::vector<connectorx::sim::ConfiguredModule> GetConfiguredModules() const;
        void RegisterModuleDescriptor(const std::string& moduleType, std::vector<module::ModuleFieldDescriptor> fields);
        std::optional<uint16_t> GetBitmapFrameDelay(uint16_t bitmapId) const;
        std::optional<lumyn::internal::Configuration::Bitmap> GetBitmapInfo(uint16_t bitmapId) const;
        std::optional<lumyn::internal::Configuration::LumynConfiguration> GetAppliedConfiguration() const;

        // Simulation state API (replaces SimState)
        void Tick(float deltaMs);
        bool TryGetZone(uint16_t zoneId, ZoneState &out) const;
        void DispatchSetAnimation(uint16_t zoneId, uint16_t animationId, uint16_t delay,
                                  Command::LED::AnimationColor color, bool reversed, bool oneShot);
        void DispatchSetColor(uint16_t zoneId, Command::LED::AnimationColor color);
        void DispatchSetAnimationSequence(uint16_t zoneId, uint16_t sequenceId);
        void DispatchSetBitmap(uint16_t zoneId, uint16_t bitmapId, Command::LED::AnimationColor color, bool setColor, bool oneShot);
        void DispatchSetMatrixText(uint16_t zoneId, const Command::LED::SetMatrixTextData &data);
        void DispatchSetGroupColor(uint16_t groupId, Command::LED::AnimationColor color);
        void DispatchSetGroupAnimation(uint16_t groupId, uint16_t animationId, uint16_t delay,
                                       Command::LED::AnimationColor color, bool reversed, bool oneShot);
        void DispatchSetGroupAnimationSequence(uint16_t groupId, uint16_t sequenceId);
        void DispatchSetGroupBitmap(uint16_t groupId, uint16_t bitmapId, Command::LED::AnimationColor color, bool setColor, bool oneShot);
        void DispatchSetGroupMatrixText(uint16_t groupId, const Command::LED::SetMatrixTextGroupData &data);
        
        // Check for external changes to connection state (from WPILib simulation GUI)
        void CheckForExternalConnectionChanges();
        // Check for external changes to status (from WPILib simulation GUI)
        void CheckForExternalStatusChanges();
        
        // UI helper methods
        std::vector<std::string> GetAnimationNames() const;
        std::vector<std::pair<uint16_t, std::string>> GetSequenceSummaries() const;
        std::vector<std::pair<uint16_t, std::string>> GetBitmapSummaries() const;

        // Module data simulation APIs
        void InjectModuleData(const std::string& moduleKey, uint16_t id, const std::vector<uint8_t>& bytes);
        bool TryPopModuleData(const std::string& moduleKey, std::vector<std::pair<uint16_t, std::vector<uint8_t>>>& out);
        std::optional<std::pair<uint16_t, std::vector<uint8_t>>> PeekLastModuleData(const std::string& moduleKey) const;

    private:
        struct SequenceStep
        {
            const Animation::AnimationInstance *animation{nullptr};
            uint16_t animationId{0};
            Command::LED::AnimationColor color{};
            uint16_t delay{0};
            bool reversed{false};
            bool hasRepeat{false};
            uint8_t repeatCount{0};
        };

        struct SequenceDefinition
        {
            uint16_t id{0};
            std::string name;
            std::vector<SequenceStep> steps;
        };

        struct SequencePlaybackState
        {
            const SequenceDefinition *definition{nullptr};
            size_t stepIndex{0};
            uint8_t repeatCounter{0};
        };

        void StopSequencePlayback(uint16_t zoneId);
        bool ApplySequenceStep(uint16_t zoneId, SequencePlaybackState &state);
        void UpdateSequencePlayback();
        const Animation::AnimationInstance *FindAnimationByHash(uint16_t animationId) const;

        bool ApplyColor_(uint16_t zoneId, Command::LED::AnimationColor color);
        bool ApplyAnimation_(uint16_t zoneId, const Command::LED::SetAnimationData &data, bool stopSequence = true);
        bool ApplySequence_(uint16_t zoneId, uint16_t sequenceId);
        bool ApplyBitmap_(uint16_t zoneId, const Command::LED::SetBitmapData &data);
        bool ApplyMatrixText_(uint16_t zoneId, const Command::LED::SetMatrixTextData &data);
        void UpdateMatrixTextRuntime(uint16_t zoneId, ZoneState &state);
        bool ForEachZoneInGroup(uint16_t groupId, const std::function<bool(uint16_t)> &fn);
        void EmitLedError(Eventing::ErrorType type, const std::string &entity, const std::string &detail);
        std::string DescribeZone(uint16_t zoneId) const;
        std::string DescribeGroup(uint16_t groupId) const;
        bool ValidateZone(uint16_t zoneId, lumyn::internal::Configuration::ZoneType expectedType);
        bool ValidateAnimationId(uint16_t animationId);
        bool ValidateSequenceId(uint16_t sequenceId);
        bool ValidateBitmapId(uint16_t bitmapId);
        void EmitHeartbeat();
        void RecalculateConfigHash();
        template <typename FillFn>
        void BuildAndApplyLed_(Command::LED::LEDCommandType type, FillFn&& fill);

        // UI state
        mutable std::mutex m_uiStateMutex;
        mutable std::vector<std::string> m_cachedAnimationNames;
        mutable bool m_animationNamesCached = false;

        std::array<uint8_t, 16> m_configHash{};
        std::array<char, 24> m_assignedId{};
        uint64_t m_serialNumber{0};
        float m_timeSinceLastHeartbeat{0.0f};
        uint32_t m_heartbeatInterval{5000};

        mutable std::mutex m_moduleDescriptorMutex;
        std::unordered_map<std::string, std::vector<module::ModuleFieldDescriptor>> m_moduleTypeDescriptors;

        std::unordered_map<uint16_t, std::vector<uint16_t>> m_groups;
        std::unordered_map<uint16_t, lumyn::internal::Configuration::ZoneType> m_zoneTypes;
        std::unordered_map<uint16_t, std::string> m_zoneNames;
        std::unordered_map<uint16_t, std::string> m_groupNames;
        std::unordered_map<uint16_t, uint16_t> m_zoneStripLengths;
        std::unordered_map<uint16_t, SequenceDefinition> m_sequenceDefs;
        std::unordered_map<uint16_t, SequencePlaybackState> m_sequencePlayback;
        std::unordered_map<uint16_t, lumyn::internal::Configuration::ZoneMatrix> m_zoneMatrixInfo;
        std::atomic<uint16_t> m_sku{0};

        // Module simulation buffers: moduleKey -> list of (id, payload bytes)
        mutable std::mutex m_moduleDataMutex;
        std::unordered_map<std::string, std::vector<std::pair<uint16_t, std::vector<uint8_t>>>> m_moduleData;
    };
}

template <typename FillFn>
void lumyn::internal::ConnectorXSimDevice::BuildAndApplyLed_(Command::LED::LEDCommandType type, FillFn&& fill)
{
    Command::LED::LEDCommand led{};
    led.type = type;
    fill(led);
    ApplyLED_(led);
}
#endif // DESKTOP
