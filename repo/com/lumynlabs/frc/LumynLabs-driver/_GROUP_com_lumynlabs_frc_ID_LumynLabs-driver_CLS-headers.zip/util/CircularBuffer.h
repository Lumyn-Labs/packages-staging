#pragma once

#include <cinttypes>
#include <mutex>

template <typename T>
class CircularBuffer
{
public:
  CircularBuffer(uint32_t capacity) : _readPos{0}, _writePos{0}, _inUse{0}, _capacity{capacity}
  {
    _buf = new T[capacity];
  }

  uint32_t size()
  {
    std::lock_guard lock(_mtx);

    return _inUse;
  }

  void push(T const &t)
  {
    std::lock_guard<std::mutex> lock(_mtx);

    if (_inUse >= _capacity)
    {
      pop();
    }

    new (&_buf[_writePos]) T(t);

    _writePos = _writePos + 1;
    _writePos = _writePos % _capacity;
    _inUse = _inUse + 1;
  }

  T front()
  {
    std::lock_guard<std::mutex> lock(_mtx);

    return _buf[_readPos];
  }

  void pop()
  {
    std::lock_guard<std::mutex> lock(_mtx);

    if (!_inUse)
      return;

    _buf[_readPos].~T();
    _readPos = _readPos + 1;

    _readPos = _readPos % _capacity;
    _inUse = _inUse - 1;
  }

  ~CircularBuffer()
  {
    std::lock_guard<std::mutex> lock(_mtx);

    while (_inUse)
    {
      pop();
    }

    delete[] _buf;
  }

private:
  T *_buf;
  volatile uint32_t _readPos;
  volatile uint32_t _writePos;
  volatile uint32_t _inUse;
  const uint32_t _capacity;
  std::mutex _mtx;
};