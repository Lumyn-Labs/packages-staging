#pragma once

#include <cinttypes>
#include <map>
#include <string_view>

namespace lumyn::led
{
  // TODO: make this match the firmware
  enum class Animation : uint16_t
  {
    None,
    Fill,
    Blink,
    Breathe,
    RainbowFade,
    SineRoll,
    Chase
  };

  const std::map<Animation, std::string_view> kAnimationMap =
      {
          {Animation::Fill, "Fill"},
          {Animation::Blink, "Blink"},
          {Animation::Breathe, "Breathe"},
          {Animation::RainbowFade, "RainbowFade"},
          {Animation::SineRoll, "SineRoll"},
          {Animation::Chase, "Chase"},
      };
} // namespace lumyn::led