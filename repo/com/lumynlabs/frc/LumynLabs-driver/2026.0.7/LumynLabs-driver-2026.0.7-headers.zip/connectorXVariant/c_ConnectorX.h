#pragma once

#include "./ConnectorX.h"
// for development only to enable intellisense, remove before building
// #define DESKTOP

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include <wpi/print.h>
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, HAL_SerialPort);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr);

    // If modules are enabled for the variant...
    bool cx_GetLatestData(ConnectorX_int *, const char *, std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                    units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP
  // Desktop-specific implementation
  inline void init_sim() {
    std::cout << "[Lumyn] init_sim hooking simgui" << std::endl;
    
    // State variables for simulator
    static std::vector<ImColor> ledColors;
    static int ledCount = 24;
    static char textBuffer[128] = "Hello WPILib!";
    static float scrollSpeed = 0.5f;
    static int animationSelector = 0;
    static ImVec4 colorPicker = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // Red default
    static bool animationRunning = false;
    static float animationTime = 0.0f;
    static bool deviceEnabled = false;
    static int selectedZoneId = 0;
    static const char* zoneNames[] = {"Zone-1", "Zone-2", "Left-Strip", "Right-Strip"};
    static std::string status = "Disconnected";
    static std::vector<std::string> eventLog;
    
    // Initialize LED colors if empty
    if (ledColors.empty()) {
      ledColors.resize(ledCount, ImColor(30, 30, 30, 255)); // Default dark LEDs
    }

    HAL_RegisterExtensionListener(nullptr, [](void*, const char* name, void* data) {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<vendor::AddGuiLateExecuteFn>(data)([] {
          ImGui::Begin("Lumyn ConnectorX Simulator");
          
          // Connection status and controls
          if (ImGui::Checkbox("Device Enabled", &deviceEnabled)) {
            if (deviceEnabled) {
              status = "Connected";
              if (eventLog.size() < 20) {
                eventLog.push_back("Device connected");
              } else {
                eventLog.erase(eventLog.begin());
                eventLog.push_back("Device connected");
              }
            } else {
              status = "Disconnected";
              if (eventLog.size() < 20) {
                eventLog.push_back("Device disconnected");
              } else {
                eventLog.erase(eventLog.begin());
                eventLog.push_back("Device disconnected");
              }
            }
          }
          
          ImGui::SameLine();
          ImGui::Text("Status: %s", status.c_str());
          
          // Device visualization - draw a simple ConnectorX-like device
          ImGui::Separator();
          ImGui::Text("ConnectorX Device");
          
          ImDrawList* draw_list = ImGui::GetWindowDrawList();
          const ImVec2 p = ImGui::GetCursorScreenPos();
          
          // Draw device body
          float deviceWidth = 300.0f;
          float deviceHeight = 100.0f;
          ImVec2 deviceMin = ImVec2(p.x + 10, p.y + 10);
          ImVec2 deviceMax = ImVec2(p.x + 10 + deviceWidth, p.y + 10 + deviceHeight);
          
          // Device outline
          draw_list->AddRectFilled(deviceMin, deviceMax, 
              deviceEnabled ? IM_COL32(100, 100, 100, 255) : IM_COL32(80, 80, 80, 255),
              5.0f);
          draw_list->AddRect(deviceMin, deviceMax, IM_COL32(200, 200, 200, 255), 5.0f, 0, 2.0f);
          
          // LED display area
          ImVec2 displayMin = ImVec2(deviceMin.x + 20, deviceMin.y + 20);
          ImVec2 displayMax = ImVec2(deviceMax.x - 20, deviceMin.y + 60);
          draw_list->AddRectFilled(displayMin, displayMax, IM_COL32(20, 20, 20, 255), 3.0f);
          
          // Animate LED strip
          if (deviceEnabled) {
            float ledSpacing = (displayMax.x - displayMin.x) / ledCount;
            animationTime += ImGui::GetIO().DeltaTime;
            
            // Update LED colors based on animation
            for (int i = 0; i < ledCount; i++) {
              float x = displayMin.x + i * ledSpacing + ledSpacing/2;
              float y = displayMin.y + (displayMax.y - displayMin.y)/2;
              float radius = ledSpacing/2 - 1;
              
              ImColor ledColor;
              
              if (animationRunning) {
                // Different animation patterns
                switch (animationSelector) {
                  case 0: // Rainbow
                    {
                      float hue = (float)i / ledCount + animationTime * 0.3f;
                      hue = hue - floorf(hue);
                      ImColor color = ImColor::HSV(hue, 1.0f, 1.0f);
                      ledColors[i] = color;
                    }
                    break;
                  case 1: // Chase
                    {
                      int pos = (int)(animationTime * 5) % ledCount;
                      ledColors[i] = (i == pos) ? ImColor(colorPicker) : ImColor(30, 30, 30, 255);
                    }
                    break;
                  case 2: // Breathe
                    {
                      float brightness = 0.5f + 0.5f * sinf(animationTime * 3.0f);
                      ledColors[i] = ImColor(
                          colorPicker.x * brightness,
                          colorPicker.y * brightness,
                          colorPicker.z * brightness,
                          1.0f);
                    }
                    break;
                  case 3: // Text scroll
                    {
                      // Simple simulation of text scrolling with blinking
                      int scrollPos = (int)(animationTime * scrollSpeed * 5) % (ledCount * 2);
                      bool isVisible = (i >= scrollPos - 3 && i <= scrollPos + 3);
                      ledColors[i] = isVisible ? ImColor(colorPicker) : ImColor(10, 10, 10, 255);
                    }
                    break;
                }
              }
              
              // Draw LED
              draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors[i]);
              draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
            }
          }
          
          ImGui::Dummy(ImVec2(deviceWidth + 20, deviceHeight + 20));
          
          // Controls section
          ImGui::Separator();
          ImGui::Text("Controls");
          
          // Animations dropdown
          const char* animations[] = { "Rainbow", "Chase", "Breathe", "Text Scroll" };
          if (ImGui::Combo("Animation", &animationSelector, animations, IM_ARRAYSIZE(animations))) {
            // Log the animation change
            if (eventLog.size() < 20) {
              eventLog.push_back("Animation changed to " + std::string(animations[animationSelector]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Animation changed to " + std::string(animations[animationSelector]));
            }
          }
          
          // Color picker
          if (ImGui::ColorEdit3("Color", (float*)&colorPicker)) {
            // Log the color change
            char colorStr[64];
            snprintf(colorStr, sizeof(colorStr), "Color set to RGB(%.0f, %.0f, %.0f)", 
                colorPicker.x * 255, colorPicker.y * 255, colorPicker.z * 255);
                
            if (eventLog.size() < 20) {
              eventLog.push_back(colorStr);
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(colorStr);
            }
          }
          
          // Zone selection
          if (ImGui::Combo("Zone", &selectedZoneId, zoneNames, IM_ARRAYSIZE(zoneNames))) {
            // Log zone change
            if (eventLog.size() < 20) {
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            }
          }
          
          // Text display
          if (ImGui::InputText("Text", textBuffer, IM_ARRAYSIZE(textBuffer))) {
            // Log text change
            if (eventLog.size() < 20) {
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            }
          }
          
          // Speed control for animations
          ImGui::SliderFloat("Animation Speed", &scrollSpeed, 0.1f, 2.0f);
          
          // Start/Stop button
          if (ImGui::Button(animationRunning ? "Stop Animation" : "Start Animation")) {
            animationRunning = !animationRunning;
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back(animationRunning ? "Animation started" : "Animation stopped");
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(animationRunning ? "Animation started" : "Animation stopped");
            }
          }
          
          // Event log section
          ImGui::Separator();
          ImGui::Text("Event Log");
          
          if (ImGui::BeginListBox("##eventlog", ImVec2(-1, 100))) {
            for (const auto& evt : eventLog) {
              ImGui::TextWrapped("%s", evt.c_str());
            }
            if (!eventLog.empty()) {
              // Auto-scroll to the latest entry
              ImGui::SetScrollHereY(1.0f);
            }
            ImGui::EndListBox();
          }
          
          ImGui::End();
        });
      }
    });
  }
#endif
} // namespace lumyn::internal::c_ConnectorX