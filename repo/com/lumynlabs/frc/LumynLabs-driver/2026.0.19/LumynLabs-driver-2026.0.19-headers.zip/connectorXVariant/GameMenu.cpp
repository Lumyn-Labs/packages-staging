#ifdef DESKTOP
#include "GameMenu.h"
#include "SnakeGame.h"
#include "PongGame.h"

namespace lumyn::internal::c_ConnectorX {

GameMenu::GameMenu()
    : showMenu_(false)
{
}

void GameMenu::render(SnakeGame& snakeGame, PongGame& pongGame) {
    if (!showMenu_) {
        return;
    }

    ImGui::Begin("Lumyn Game Menu", &showMenu_);
    ImGui::Text("Select a game to play:");
    
    if (ImGui::Button("Snake Game", ImVec2(150, 40))) {
        snakeGame.setWindowOpen(true);
    }
    ImGui::SameLine();
    if (ImGui::Button("Pong Game", ImVec2(150, 40))) {
        pongGame.setWindowOpen(true);
    }
    
    ImGui::Separator();
    ImGui::Text("Game Controls:");
    ImGui::BulletText("Snake: WASD or Arrow Keys to move");
    ImGui::BulletText("Pong: W/S or Up/Down to move paddle");
    ImGui::BulletText("Both: Spacebar to restart when game over");
    
    ImGui::End();
}

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
