#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>
#include <algorithm>

namespace lumyn::internal::c_ConnectorX {

class PongGame {
public:
    PongGame() : showWindow_(false), gameWidth_(400.0f), gameHeight_(300.0f),
                 ballPos_{200.0f, 150.0f}, ballVel_{150.0f, 100.0f},
                 paddleHeight_(60.0f), paddleWidth_(10.0f),
                 leftPaddleY_(120.0f), rightPaddleY_(120.0f),
                 leftScore_(0), rightScore_(0), paddleSpeed_(200.0f) {}
    
    ~PongGame() = default;

    void update(float deltaTime) {
        if (!showWindow_) return;
        
        handleInput(deltaTime);
        updateBall(deltaTime);
        updateAI(deltaTime);
    }
    
    void render() {
        if (!showWindow_) return;
        
        if (ImGui::Begin("Pong Game", &showWindow_)) {
            renderGame();
            ImGui::Text("Score: %d - %d", leftScore_, rightScore_);
            ImGui::Text("Use W/S to move left paddle");
            if (ImGui::Button("Reset")) {
                resetGame();
            }
        }
        ImGui::End();
    }
    
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    bool showWindow_;
    float gameWidth_, gameHeight_;
    ImVec2 ballPos_, ballVel_;
    float paddleHeight_, paddleWidth_;
    float leftPaddleY_, rightPaddleY_;
    int leftScore_, rightScore_;
    float paddleSpeed_;

    void handleInput(float deltaTime) {
        if (ImGui::IsKeyDown(ImGuiKey_W)) {
            leftPaddleY_ = std::max(0.0f, leftPaddleY_ - paddleSpeed_ * deltaTime);
        }
        if (ImGui::IsKeyDown(ImGuiKey_S)) {
            leftPaddleY_ = std::min(gameHeight_ - paddleHeight_, leftPaddleY_ + paddleSpeed_ * deltaTime);
        }
    }
    
    void updateBall(float deltaTime) {
        ballPos_.x += ballVel_.x * deltaTime;
        ballPos_.y += ballVel_.y * deltaTime;
        
        // Top/bottom collision
        if (ballPos_.y <= 0 || ballPos_.y >= gameHeight_) {
            ballVel_.y = -ballVel_.y;
            ballPos_.y = std::clamp(ballPos_.y, 0.0f, gameHeight_);
        }
        
        // Left paddle collision
        if (ballPos_.x <= paddleWidth_ && ballPos_.y >= leftPaddleY_ && 
            ballPos_.y <= leftPaddleY_ + paddleHeight_) {
            ballVel_.x = std::abs(ballVel_.x);
            ballPos_.x = paddleWidth_;
        }
        
        // Right paddle collision
        if (ballPos_.x >= gameWidth_ - paddleWidth_ && ballPos_.y >= rightPaddleY_ && 
            ballPos_.y <= rightPaddleY_ + paddleHeight_) {
            ballVel_.x = -std::abs(ballVel_.x);
            ballPos_.x = gameWidth_ - paddleWidth_;
        }
        
        // Score
        if (ballPos_.x < 0) {
            rightScore_++;
            resetBall();
        } else if (ballPos_.x > gameWidth_) {
            leftScore_++;
            resetBall();
        }
    }
    
    void updateAI(float deltaTime) {
        float targetY = ballPos_.y - paddleHeight_ / 2;
        if (rightPaddleY_ < targetY) {
            rightPaddleY_ = std::min(gameHeight_ - paddleHeight_, 
                                   rightPaddleY_ + paddleSpeed_ * deltaTime * 0.7f);
        } else {
            rightPaddleY_ = std::max(0.0f, rightPaddleY_ - paddleSpeed_ * deltaTime * 0.7f);
        }
    }
    
    void renderGame() {
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 canvas_pos = ImGui::GetCursorScreenPos();
        
        // Draw field
        draw_list->AddRect(canvas_pos, 
                          ImVec2(canvas_pos.x + gameWidth_, canvas_pos.y + gameHeight_),
                          IM_COL32(255, 255, 255, 255));
        
        // Draw center line
        draw_list->AddLine(ImVec2(canvas_pos.x + gameWidth_/2, canvas_pos.y),
                          ImVec2(canvas_pos.x + gameWidth_/2, canvas_pos.y + gameHeight_),
                          IM_COL32(255, 255, 255, 100));
        
        // Draw paddles
        draw_list->AddRectFilled(
            ImVec2(canvas_pos.x, canvas_pos.y + leftPaddleY_),
            ImVec2(canvas_pos.x + paddleWidth_, canvas_pos.y + leftPaddleY_ + paddleHeight_),
            IM_COL32(255, 255, 255, 255)
        );
        
        draw_list->AddRectFilled(
            ImVec2(canvas_pos.x + gameWidth_ - paddleWidth_, canvas_pos.y + rightPaddleY_),
            ImVec2(canvas_pos.x + gameWidth_, canvas_pos.y + rightPaddleY_ + paddleHeight_),
            IM_COL32(255, 255, 255, 255)
        );
        
        // Draw ball
        draw_list->AddCircleFilled(
            ImVec2(canvas_pos.x + ballPos_.x, canvas_pos.y + ballPos_.y),
            5.0f, IM_COL32(255, 255, 255, 255)
        );
        
        ImGui::Dummy(ImVec2(gameWidth_, gameHeight_));
    }
    
    void resetBall() {
        ballPos_ = {gameWidth_/2, gameHeight_/2};
        ballVel_.x = (ballVel_.x > 0) ? -150.0f : 150.0f;
        ballVel_.y = (rand() % 2 == 0) ? 100.0f : -100.0f;
    }
    
    void resetGame() {
        leftScore_ = 0;
        rightScore_ = 0;
        leftPaddleY_ = gameHeight_/2 - paddleHeight_/2;
        rightPaddleY_ = gameHeight_/2 - paddleHeight_/2;
        resetBall();
    }
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
