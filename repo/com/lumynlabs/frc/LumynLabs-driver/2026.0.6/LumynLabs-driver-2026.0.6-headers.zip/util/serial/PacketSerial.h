#pragma once

#include <iostream>
#include <functional>
#include "domain/transmission/Transmission.h"
#include "domain/transmission/Packet.h"
#include "util/serial/IEncoder.h"
#include <hal/Types.h>
#include <hal/SerialPort.h>
#include <thread>
#include <atomic>

namespace lumyn::internal
{

  class PacketSerial
  {
  public:
    PacketSerial(IEncoder *encoder, HAL_SerialPort port, uint32_t bufferSize = 4096);

    ~PacketSerial();

    void startReading();
    void stopReading();

    void send(Packet &packet);

    void setOnOverflow(std::function<void()> onOverflow)
    {
      this->onOverflow = onOverflow;
    }

    void setOnPacketOverflow(std::function<void()> onPacketOverflow)
    {
      this->onPacketOverflow = onPacketOverflow;
    }

    void setOnNewPacket(std::function<void(Packet &)> onNewPacket)
    {
      this->onNewPacket = onNewPacket;
    }

  private:
    IEncoder *_encoder;
    uint8_t _port;
    uint8_t *_buffer;
    uint32_t _bufferSize;
    size_t _receiveBufferIndex;
    uint8_t _receiveReadIndex;
    size_t _tmpPacketIndex;
    uint8_t _readBuffer[MAX_PACKET_SIZE];
    HAL_SerialPortHandle _portHandle;

    std::function<void()> onOverflow;
    std::function<void()> onPacketOverflow;
    std::function<void(Packet &)> onNewPacket;

    std::thread _readThread;
    std::atomic<bool> _reading;
  };
} // namespace lumyn::internal