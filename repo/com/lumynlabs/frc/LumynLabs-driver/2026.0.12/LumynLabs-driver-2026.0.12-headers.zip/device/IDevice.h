#pragma once

#include <hal/SerialPort.h>

#include "domain/response/Response.h"

#include <memory>
#include <optional>

namespace lumyn::internal
{
  class IDevice
  {
  public:
    virtual bool Connect(HAL_SerialPort) = 0;
    virtual bool IsConnected(void) = 0;
    virtual Eventing::Status GetCurrentStatus(void) = 0;
    virtual std::optional<Eventing::Event> GetLatestEvent(void) = 0;

  protected:
    virtual bool Initialize(void) = 0;
    virtual std::optional<Response::ResponseHandshakeInfo> GetLatestHandshake(void) = 0;
  };
}