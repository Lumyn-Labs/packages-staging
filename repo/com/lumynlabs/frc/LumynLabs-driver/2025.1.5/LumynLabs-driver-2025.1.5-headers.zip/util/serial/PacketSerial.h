#pragma once

#include <iostream>
#include <functional>
#include "domain/transmission/Transmission.h"
#include "domain/transmission/Packet.h"
#include "util/serial/IEncoder.h"
#include <hal/Types.h>
#include <hal/SerialPort.h>
#include <thread>
#include <atomic>

namespace lumyn::internal
{

  class PacketSerial
  {
  public:
    PacketSerial(IEncoder *encoder, HAL_SerialPort port, uint32_t bufferSize = 4096);

    ~PacketSerial();

    void startReading();
    void stopReading();

    void send(Packet &packet);

    void setOnOverflow(std::function<void()> onOverflow)
    {
      if (onOverflow == nullptr)
      {
        lumyn::internal::consoleLogger.getInstance().logError("PacketSerial", std::string("onOverflow is null!"));
        return;
      }
      this->onOverflow = onOverflow;
    }

    void setOnPacketOverflow(std::function<void()> onPacketOverflow)
    {
      if (onPacketOverflow == nullptr)
      {
        lumyn::internal::consoleLogger.getInstance().logError("PacketSerial", std::string("onPacketOverflow is null!"));
        return;
      }
      this->onPacketOverflow = onPacketOverflow;
    }

    void setOnNewPacket(std::function<void(Packet &)> onNewPacket)
    {
      if (onNewPacket == nullptr)
      {
        lumyn::internal::consoleLogger.getInstance().logError("PacketSerial", std::string("onNewPacket is null!"));
        return;
      }
      this->onNewPacket = onNewPacket;
    }

  private:
    IEncoder *_encoder;
    uint8_t _port;
    uint8_t *_buffer;
    char *_readBuffer;
    uint32_t _bufferSize;
    size_t _receiveBufferIndex;
    uint8_t _receiveReadIndex;
    size_t _tmpPacketIndex;
    HAL_SerialPortHandle _portHandle;

    uint32_t _readBufferSize = 1024;

    std::function<void()> onOverflow;
    std::function<void()> onPacketOverflow;
    std::function<void(Packet &)> onNewPacket;

    std::thread _readThread;
    std::atomic<bool> _reading;
  };
} // namespace lumyn::internal