#pragma once

#include "./ConnectorX.h"
// for development only to enable intellisense, remove before building
// #define DESKTOP

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include <wpi/print.h>
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, HAL_SerialPort);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr);

    // If modules are enabled for the variant...
    bool cx_GetLatestData(ConnectorX_int *, const char *, std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                    units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP
  // Desktop-specific implementation
  inline void init_sim() {
    std::cout << "[Lumyn] init_sim hooking simgui" << std::endl;
    
    // State variables for simulator
    static std::vector<ImColor> ledColors;
    static int ledCount = 60; // 60 LEDs total
    static char textBuffer[128] = "";
    static float scrollSpeed[3] = {0.5f, 0.5f, 0.5f}; // Speed for each zone
    static int animationSelector[3] = {0, 0, 0}; // Animation type for each zone
    static ImVec4 colorPicker[3] = { 
        ImVec4(1.0f, 0.0f, 0.0f, 1.0f), // Red default for zone 1
        ImVec4(0.0f, 1.0f, 0.0f, 1.0f), // Green default for zone 2
        ImVec4(0.0f, 0.0f, 1.0f, 1.0f)  // Blue default for zone 3
    };
    static bool animationRunning[3] = {false, false, false}; // Animation state for each zone
    static float animationTime = 0.0f;
    static int selectedZoneId = 0;
    static const char* zoneNames[] = {"Zone-1 (LEDs 0-19)", "Zone-2 (LEDs 20-39)", "Zone-3 (LEDs 40-59)"};
    static std::string status = "Connected"; // Default to connected for demo
    static std::vector<std::string> eventLog;
    
    // Initialize LED colors if empty
    if (ledColors.empty()) {
      ledColors.resize(ledCount, ImColor(30, 30, 30, 255)); // Default dark LEDs
    }

    HAL_RegisterExtensionListener(nullptr, [](void*, const char* name, void* data) {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<vendor::AddGuiLateExecuteFn>(data)([] {
          ImGui::Begin("Lumyn ConnectorX Simulator");
          
          // Status indicator only - no checkbox
          ImGui::Text("Status: %s", status.c_str());
          
          // LED strip visualization
          ImGui::Separator();
          ImGui::Text("LED Strip Visualization");
          
          ImDrawList* draw_list = ImGui::GetWindowDrawList();
          const ImVec2 p = ImGui::GetCursorScreenPos();
          
          // LED strip area
          float stripWidth = 600.0f; // Wider to accommodate more LEDs
          float stripHeight = 40.0f;
          ImVec2 stripMin = ImVec2(p.x + 10, p.y + 10);
          ImVec2 stripMax = ImVec2(p.x + 10 + stripWidth, p.y + 10 + stripHeight);
          
          // Strip background
          draw_list->AddRectFilled(stripMin, stripMax, IM_COL32(20, 20, 20, 255), 3.0f);
          
          // Zone separators
          float zoneWidth = stripWidth / 3;
          for (int z = 1; z < 3; z++) {
            float x = stripMin.x + z * zoneWidth;
            draw_list->AddLine(
                ImVec2(x, stripMin.y), 
                ImVec2(x, stripMax.y),
                IM_COL32(100, 100, 100, 255), 
                1.0f);
          }
          
          // Animate LED strip
          float ledSpacing = stripWidth / ledCount;
          animationTime += ImGui::GetIO().DeltaTime;
          
          // Update LED colors based on animation for each zone
          for (int i = 0; i < ledCount; i++) {
            float x = stripMin.x + i * ledSpacing + ledSpacing/2;
            float y = stripMin.y + stripHeight/2;
            float radius = ledSpacing/2 - 1;
            
            // Determine which zone this LED belongs to
            int zoneIndex = i / 20; // 20 LEDs per zone
            
            if (animationRunning[zoneIndex]) {
              // Different animation patterns
              switch (animationSelector[zoneIndex]) {
                case 0: // Rainbow
                  {
                    float hue = (float)(i % 20) / 20 + animationTime * 0.3f;
                    hue = hue - floorf(hue);
                    ImColor color = ImColor::HSV(hue, 1.0f, 1.0f);
                    ledColors[i] = color;
                  }
                  break;
                case 1: // Chase
                  {
                    int zoneStartLed = zoneIndex * 20;
                    int pos = zoneStartLed + (int)(animationTime * 5) % 20;
                    ledColors[i] = (i == pos) ? ImColor(colorPicker[zoneIndex]) : ImColor(30, 30, 30, 255);
                  }
                  break;
                case 2: // Breathe
                  {
                    float brightness = 0.5f + 0.5f * sinf(animationTime * 3.0f);
                    ledColors[i] = ImColor(
                        colorPicker[zoneIndex].x * brightness,
                        colorPicker[zoneIndex].y * brightness,
                        colorPicker[zoneIndex].z * brightness,
                        1.0f);
                  }
                  break;
                case 3: // Text scroll
                  {
                    // Simple simulation of text scrolling with blinking
                    int zoneStartLed = zoneIndex * 20;
                    int zonePos = i - zoneStartLed;
                    int scrollPos = (int)(animationTime * scrollSpeed[zoneIndex] * 5) % 40;
                    bool isVisible = (zonePos >= scrollPos - 3 && zonePos <= scrollPos + 3) % 20;
                    ledColors[i] = isVisible ? ImColor(colorPicker[zoneIndex]) : ImColor(10, 10, 10, 255);
                  }
                  break;
              }
            }
            
            // Draw LED
            draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors[i]);
            draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
          }
          
          ImGui::Dummy(ImVec2(stripWidth + 20, stripHeight + 20));
          
          // Controls section
          ImGui::Separator();
          
          // Zone selection
          if (ImGui::Combo("Active Zone", &selectedZoneId, zoneNames, IM_ARRAYSIZE(zoneNames))) {
            // Log zone change
            if (eventLog.size() < 20) {
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            }
          }
          
          ImGui::Text("Controls for %s", zoneNames[selectedZoneId]);
          
          // Animations dropdown for selected zone
          const char* animations[] = { "Rainbow", "Chase", "Breathe", "Text Scroll" };
          if (ImGui::Combo("Animation##zone", &animationSelector[selectedZoneId], animations, IM_ARRAYSIZE(animations))) {
            // Log the animation change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            }
          }
          
          // Color picker for selected zone
          if (ImGui::ColorEdit3("Color##zone", (float*)&colorPicker[selectedZoneId])) {
            // Log the color change
            char colorStr[64];
            snprintf(colorStr, sizeof(colorStr), "Zone %d color set to RGB(%.0f, %.0f, %.0f)", 
                selectedZoneId+1,
                colorPicker[selectedZoneId].x * 255, 
                colorPicker[selectedZoneId].y * 255, 
                colorPicker[selectedZoneId].z * 255);
                
            if (eventLog.size() < 20) {
              eventLog.push_back(colorStr);
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(colorStr);
            }
          }
          
          // Text display (shared across zones)
          if (ImGui::InputText("Text for scroll animation", textBuffer, IM_ARRAYSIZE(textBuffer))) {
            // Log text change
            if (eventLog.size() < 20) {
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            }
          }
          
          // Speed control for animations for selected zone
          ImGui::SliderFloat("Animation Speed##zone", &scrollSpeed[selectedZoneId], 0.1f, 2.0f);
          
          // Start/Stop button for selected zone
          if (ImGui::Button(animationRunning[selectedZoneId] ? 
                           "Stop Animation for Zone" : 
                           "Start Animation for Zone")) {
            animationRunning[selectedZoneId] = !animationRunning[selectedZoneId];
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            }
          }
          
          ImGui::SameLine();
          
          // Start/Stop all button
          if (ImGui::Button("Start/Stop All Zones")) {
            bool anyRunning = animationRunning[0] || animationRunning[1] || animationRunning[2];
            
            // Toggle all animations to the opposite of the current majority state
            animationRunning[0] = animationRunning[1] = animationRunning[2] = !anyRunning;
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            }
          }
          
          // Event log section
          ImGui::Separator();
          ImGui::Text("Event Log");
          
          if (ImGui::BeginListBox("##eventlog", ImVec2(-1, 100))) {
            for (const auto& evt : eventLog) {
              ImGui::TextWrapped("%s", evt.c_str());
            }
            if (!eventLog.empty()) {
              // Auto-scroll to the latest entry
              ImGui::SetScrollHereY(1.0f);
            }
            ImGui::EndListBox();
          }
          
          ImGui::End();
        });
      }
    });
  }
#endif
} // namespace lumyn::internal::c_ConnectorX