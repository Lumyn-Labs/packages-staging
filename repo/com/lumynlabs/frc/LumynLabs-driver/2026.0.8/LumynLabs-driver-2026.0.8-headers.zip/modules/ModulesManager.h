#pragma once

#include "domain/module/ModuleData.h"
#include "util/CircularBuffer.h"

#include <string_view>
#include <optional>
#include <functional>
#include <unordered_map>
#include <mutex>
#include <memory>

namespace lumyn::internal
{
  class ModulesManager
  {
  public:
    std::optional<std::vector<ModuleData::NewDataInfo>> GetLatestData(std::string_view moduleID);
    void AddDataEntry(ModuleData::NewDataInfo &data);

  private:
    std::unordered_map<uint16_t, std::unique_ptr<CircularBuffer<ModuleData::NewDataInfo>>> _moduleData;
    std::mutex _lock;
  };
}