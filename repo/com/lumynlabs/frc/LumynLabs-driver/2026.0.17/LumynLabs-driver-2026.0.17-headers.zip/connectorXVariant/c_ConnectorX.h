#pragma once

#include "./ConnectorX.h"
// for development only to enable intellisense, remove before building
// #define DESKTOP

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include <wpi/print.h>
#include <algorithm>
#include <vector>
#include <ctime>
#include <cstdlib>
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, HAL_SerialPort);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr);

    // If modules are enabled for the variant...
    bool cx_GetLatestData(ConnectorX_int *, const char *, std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                    units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP

  // Desktop-specific implementation
  inline void init_sim()
  {
    std::cout << "[Lumyn] init_sim hooking simgui" << std::endl;

    // State variables for ConnectorX simulator
    static std::vector<ImColor> ledColors;
    static int ledCount = 60; // 60 LEDs total
    static char textBuffer[128] = "";
    static float scrollSpeed[3] = {0.5f, 0.5f, 0.5f}; // Speed for each zone
    static int animationSelector[3] = {0, 0, 0};      // Animation type for each zone
    static ImVec4 colorPicker[3] = {
        ImVec4(1.0f, 0.0f, 0.0f, 1.0f), // Red default for zone 1
        ImVec4(0.0f, 1.0f, 0.0f, 1.0f), // Green default for zone 2
        ImVec4(0.0f, 0.0f, 1.0f, 1.0f)  // Blue default for zone 3
    };
    static bool animationRunning[3] = {false, false, false}; // Animation state for each zone
    // ConnectorX simulation variables
    static float connectorAnimTime = 0.0f; // For ConnectorX animation
    static int selectedZoneId = 0;
    static const char *zoneNames[] = {"Zone-1 (LEDs 0-19)", "Zone-2 (LEDs 20-39)", "Zone-3 (LEDs 40-59)"};
    static std::string status = "Connected"; // Default to connected for demo
    static std::vector<std::string> eventLog;
    
    // Snake game variables
    static bool snakeGameActive = false;
    static int snakeGridWidth = 20;
    static int snakeGridHeight = 15;
    static float snakeGameTime = 0.0f;
    static float snakeUpdateInterval = 0.30f; // Snake movement speed (lower = faster)
    static float snakeLastUpdateTime = 0.0f;
    static int snakeDirection = 2; // 0=up, 1=right, 2=down, 3=left
    static int snakeNextDirection = 2;
    static int snakeScore = 0;
    static bool snakeGameOver = false;
    struct SnakeSegment { int x, y; };
    static std::vector<SnakeSegment> snakeBody;
    static SnakeSegment snakeFood = {0, 0};

    // Pong game variables
    static bool pongGameActive = false;
    static int pongGridWidth = 30;
    static int pongGridHeight = 20;
    static float pongGameTime = 0.0f;
    static float pongUpdateInterval = 0.03f;
    static float pongLastUpdateTime = 0.0f;
    static int pongPlayerScore = 0;
    static int pongAIScore = 0;
    static bool pongGameOver = false;
    static int pongWinningScore = 5;
    struct PongPaddle { float y; float height = 4.0f; float speed = 0.3f; };
    struct PongBall { float x, y; float dx, dy; float speed = 0.2f; };
    static PongPaddle pongPlayerPaddle = {(float)pongGridHeight / 2 - 2, 4.0f, 0.3f};
    static PongPaddle pongAIPaddle = {(float)pongGridHeight / 2 - 2, 4.0f, 0.25f};
    static PongBall pongBall = {(float)pongGridWidth / 2, (float)pongGridHeight / 2, 0.2f, 0.15f, 0.2f};

    // Initialize LED colors if empty
    if (ledColors.empty())
    {
      ledColors.resize(ledCount, ImColor(30, 30, 30, 255)); // Default dark LEDs
    }

    HAL_RegisterExtensionListener(nullptr, [](void *, const char *name, void *data)
                                  {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<vendor::AddGuiLateExecuteFn>(data)([=] {
          // Function to initialize the snake game
          auto initializeSnakeGame = []() {
            snakeBody.clear();
            snakeBody.push_back({snakeGridWidth / 2, snakeGridHeight / 2}); // Head
            snakeBody.push_back({snakeGridWidth / 2 - 1, snakeGridHeight / 2}); // Initial body
            snakeBody.push_back({snakeGridWidth / 2 - 2, snakeGridHeight / 2}); // Initial body
            
            // Place food at a random position not occupied by snake
            std::srand(static_cast<unsigned int>(std::time(nullptr)));
            do {
              snakeFood.x = std::rand() % snakeGridWidth;
              snakeFood.y = std::rand() % snakeGridHeight;
            } while (std::any_of(snakeBody.begin(), snakeBody.end(), 
                              [](const SnakeSegment& seg) { return seg.x == snakeFood.x && seg.y == snakeFood.y; }));
            
            snakeDirection = 1; // Start moving right
            snakeNextDirection = 1;
            snakeScore = 0;
            snakeGameOver = false;
            snakeGameActive = true;
          };
          // Render the ConnectorX Simulator
          ImGui::Begin("Lumyn ConnectorX Simulator");
          
          // Status indicator only - no checkbox
          ImGui::Text("Status: %s", status.c_str());
          
          // LED strip visualization
          ImGui::Separator();
          ImGui::Text("LED Strip Visualization");
          
          ImDrawList* draw_list = ImGui::GetWindowDrawList();
          const ImVec2 p = ImGui::GetCursorScreenPos();
          
          // LED strip area
          float stripWidth = 600.0f; // Wider to accommodate more LEDs
          float stripHeight = 40.0f;
          ImVec2 stripMin = ImVec2(p.x + 10, p.y + 10);
          ImVec2 stripMax = ImVec2(p.x + 10 + stripWidth, p.y + 10 + stripHeight);
          
          // Strip background
          draw_list->AddRectFilled(stripMin, stripMax, IM_COL32(20, 20, 20, 255), 3.0f);
          
          // Zone separators
          float zoneWidth = stripWidth / 3;
          for (int z = 1; z < 3; z++) {
            float x = stripMin.x + z * zoneWidth;
            draw_list->AddLine(
                ImVec2(x, stripMin.y), 
                ImVec2(x, stripMax.y),
                IM_COL32(100, 100, 100, 255), 
                1.0f);
          }
          
          // Animate LED strip
          float ledSpacing = stripWidth / ledCount;
          connectorAnimTime += ImGui::GetIO().DeltaTime;
          
          // Update LED colors based on animation for each zone
          for (int i = 0; i < ledCount; i++) {
            float x = stripMin.x + i * ledSpacing + ledSpacing/2;
            float y = stripMin.y + stripHeight/2;
            float radius = ledSpacing/2 - 1;
            
            // Determine which zone this LED belongs to
            int zoneIndex = i / 20; // 20 LEDs per zone
            
            if (animationRunning[zoneIndex]) {
              // Different animation patterns
              switch (animationSelector[zoneIndex]) {
                case 0: // Rainbow
                  {
                    float hue = (float)(i % 20) / 20 + connectorAnimTime * 0.3f;
                    hue = hue - floorf(hue);
                    ImColor color = ImColor::HSV(hue, 1.0f, 1.0f);
                    ledColors[i] = color;
                  }
                  break;
                case 1: // Chase
                  {
                    int zoneStartLed = zoneIndex * 20;
                    int pos = zoneStartLed + (int)(connectorAnimTime * 5) % 20;
                    ledColors[i] = (i == pos) ? ImColor(colorPicker[zoneIndex]) : ImColor(30, 30, 30, 255);
                  }
                  break;
                case 2: // Breathe
                  {
                    float brightness = 0.5f + 0.5f * sinf(connectorAnimTime * 3.0f);
                    ledColors[i] = ImColor(
                        colorPicker[zoneIndex].x * brightness,
                        colorPicker[zoneIndex].y * brightness,
                        colorPicker[zoneIndex].z * brightness,
                        1.0f);
                  }
                  break;
                case 3: // Text scroll
                  {
                    // Simple simulation of text scrolling with blinking
                    int zoneStartLed = zoneIndex * 20;
                    int zonePos = i - zoneStartLed;
                    int scrollPos = (int)(connectorAnimTime * scrollSpeed[zoneIndex] * 5) % 40;
                    bool isVisible = (zonePos >= scrollPos - 3 && zonePos <= scrollPos + 3) % 20;
                    ledColors[i] = isVisible ? ImColor(colorPicker[zoneIndex]) : ImColor(10, 10, 10, 255);
                  }
                  break;
              }
            }
            
            // Draw LED
            draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors[i]);
            draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
          }
          
          ImGui::Dummy(ImVec2(stripWidth + 20, stripHeight + 20));
          
          // Controls section
          ImGui::Separator();
          
          // Zone selection
          if (ImGui::Combo("Active Zone", &selectedZoneId, zoneNames, IM_ARRAYSIZE(zoneNames))) {
            // Log zone change
            if (eventLog.size() < 20) {
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            }
          }
          
          ImGui::Text("Controls for %s", zoneNames[selectedZoneId]);
          
          // Animations dropdown for selected zone
          const char* animations[] = { "Rainbow", "Chase", "Breathe", "Text Scroll" };
          if (ImGui::Combo("Animation##zone", &animationSelector[selectedZoneId], animations, IM_ARRAYSIZE(animations))) {
            // Log the animation change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            }
          }
          
          // Color picker for selected zone
          if (ImGui::ColorEdit3("Color##zone", (float*)&colorPicker[selectedZoneId])) {
            // Log the color change
            char colorStr[64];
            snprintf(colorStr, sizeof(colorStr), "Zone %d color set to RGB(%.0f, %.0f, %.0f)", 
                selectedZoneId+1,
                colorPicker[selectedZoneId].x * 255, 
                colorPicker[selectedZoneId].y * 255, 
                colorPicker[selectedZoneId].z * 255);
                
            if (eventLog.size() < 20) {
              eventLog.push_back(colorStr);
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(colorStr);
            }
          }
          
          // Text display (shared across zones)
          if (ImGui::InputText("Text for scroll animation", textBuffer, IM_ARRAYSIZE(textBuffer))) {
            // Log text change
            if (eventLog.size() < 20) {
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            }
          }
          
          // Speed control for animations for selected zone
          ImGui::SliderFloat("Animation Speed##zone", &scrollSpeed[selectedZoneId], 0.1f, 2.0f);
          
          // Start/Stop button for selected zone
          if (ImGui::Button(animationRunning[selectedZoneId] ? 
                           "Stop Animation for Zone" : 
                           "Start Animation for Zone")) {
            animationRunning[selectedZoneId] = !animationRunning[selectedZoneId];
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            }
          }
          
          ImGui::SameLine();
          
          // Start/Stop all button
          if (ImGui::Button("Start/Stop All Zones")) {
            bool anyRunning = animationRunning[0] || animationRunning[1] || animationRunning[2];
            
            // Toggle all animations to the opposite of the current majority state
            animationRunning[0] = animationRunning[1] = animationRunning[2] = !anyRunning;
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            }
          }
          
          // Event log section
          ImGui::Separator();
          ImGui::Text("Event Log");
          
          if (ImGui::BeginListBox("##eventlog", ImVec2(-1, 100))) {
            for (const auto& evt : eventLog) {
              ImGui::TextWrapped("%s", evt.c_str());
            }
            if (!eventLog.empty()) {
              // Auto-scroll to the latest entry
              ImGui::SetScrollHereY(1.0f);
            }
            ImGui::EndListBox();
          }
          
          ImGui::Separator();
          ImGui::Text("Lumyn Snake Game");
          
          // Initialize snake game if not active
          if (!snakeGameActive && !snakeGameOver) {
            initializeSnakeGame();
          }
          
          // Snake game
          {
            // Fixed width for game layout to prevent shifting
            ImVec2 gameSize(snakeGridWidth * 20.0f + 40, snakeGridHeight * 20.0f + 120);
            ImGui::BeginChild("SnakeGameArea", gameSize, false);
            
            // Game controls explanation
            ImGui::Text("Controls: Arrow keys or WASD to move");
            ImGui::Text("Score: %d", snakeScore);
            
            if (snakeGameOver) {
              ImGui::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "GAME OVER! Press spacebar to restart");
              
              // Check for spacebar to restart
              if (ImGui::IsKeyPressed(ImGuiKey_Space)) {
                initializeSnakeGame();
              }
              
              // Keep the Restart button (same size as Pause button) for mouse users
              float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
              ImGui::SetCursorPosX((gameSize.x - buttonWidth) * 0.5f);
              if (ImGui::Button("Restart Game", ImVec2(buttonWidth, 0))) {
                initializeSnakeGame();
              }
            }
            
            // Pause/Resume button - center it
            if (!snakeGameOver) {
              float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
              ImGui::SetCursorPosX((gameSize.x - buttonWidth) * 0.5f);
              if (ImGui::Button(snakeGameActive ? "Pause Game" : "Resume Game", ImVec2(buttonWidth, 0))) {
                snakeGameActive = !snakeGameActive;
              }
            }
            
            // Process inputs for both arrow keys and WASD
            if (!snakeGameOver && snakeGameActive) {
              // Up: Arrow Up or W
              if ((ImGui::IsKeyPressed(ImGuiKey_UpArrow) || ImGui::IsKeyPressed(ImGuiKey_W)) && snakeDirection != 2)
                snakeNextDirection = 0;
              // Right: Arrow Right or D
              else if ((ImGui::IsKeyPressed(ImGuiKey_RightArrow) || ImGui::IsKeyPressed(ImGuiKey_D)) && snakeDirection != 3)
                snakeNextDirection = 1;
              // Down: Arrow Down or S
              else if ((ImGui::IsKeyPressed(ImGuiKey_DownArrow) || ImGui::IsKeyPressed(ImGuiKey_S)) && snakeDirection != 0)
                snakeNextDirection = 2;
              // Left: Arrow Left or A
              else if ((ImGui::IsKeyPressed(ImGuiKey_LeftArrow) || ImGui::IsKeyPressed(ImGuiKey_A)) && snakeDirection != 1)
                snakeNextDirection = 3;
            }
            
            // Game area
            const float gridSize = 20.0f;
            const ImVec2 boardPos = ImGui::GetCursorScreenPos();
            ImDrawList* draw_list = ImGui::GetWindowDrawList();
            
            // Draw board background
            ImVec2 boardSize(snakeGridWidth * gridSize, snakeGridHeight * gridSize);
            draw_list->AddRectFilled(
                boardPos,
                ImVec2(boardPos.x + boardSize.x, boardPos.y + boardSize.y),
                IM_COL32(20, 20, 20, 255));
            
            // Draw grid lines
            for (int i = 0; i <= snakeGridWidth; i++) {
              draw_list->AddLine(
                  ImVec2(boardPos.x + i * gridSize, boardPos.y),
                  ImVec2(boardPos.x + i * gridSize, boardPos.y + boardSize.y),
                  IM_COL32(50, 50, 50, 255));
            }
            for (int i = 0; i <= snakeGridHeight; i++) {
              draw_list->AddLine(
                  ImVec2(boardPos.x, boardPos.y + i * gridSize),
                  ImVec2(boardPos.x + boardSize.x, boardPos.y + i * gridSize),
                  IM_COL32(50, 50, 50, 255));
            }
            
            // Game logic update
            snakeGameTime += ImGui::GetIO().DeltaTime;
            if (snakeGameActive && !snakeGameOver && snakeGameTime - snakeLastUpdateTime >= snakeUpdateInterval) {
              snakeLastUpdateTime = snakeGameTime;
              
              // Update direction
              snakeDirection = snakeNextDirection;
              
              // Calculate new head position
              SnakeSegment newHead = snakeBody.front();
              switch (snakeDirection) {
                case 0: newHead.y--; break; // Up
                case 1: newHead.x++; break; // Right
                case 2: newHead.y++; break; // Down
                case 3: newHead.x--; break; // Left
              }
              
              // Check for collisions with walls
              if (newHead.x < 0 || newHead.x >= snakeGridWidth || 
                  newHead.y < 0 || newHead.y >= snakeGridHeight) {
                snakeGameOver = true;
              } 
              else {
                // Check for collisions with self (except tail which will move)
                for (size_t i = 0; i < snakeBody.size() - 1; i++) {
                  if (newHead.x == snakeBody[i].x && newHead.y == snakeBody[i].y) {
                    snakeGameOver = true;
                    break;
                  }
                }
                
                if (!snakeGameOver) {
                  // Check if eating food
                  bool growing = (newHead.x == snakeFood.x && newHead.y == snakeFood.y);
                  
                  if (growing) {
                    snakeScore += 10;
                    
                    // Make game faster as score increases but at a much slower rate
                    snakeUpdateInterval = std::max(0.1f, 0.30f - (snakeScore / 2000.0f));
                    
                    // Generate new food position
                    do {
                      snakeFood.x = std::rand() % snakeGridWidth;
                      snakeFood.y = std::rand() % snakeGridHeight;
                    } while (std::any_of(snakeBody.begin(), snakeBody.end(), 
                                      [&](const SnakeSegment& seg) { return seg.x == snakeFood.x && seg.y == snakeFood.y; }));
                  }
                  
                  // Move snake: add new head
                  snakeBody.insert(snakeBody.begin(), newHead);
                  
                  // Remove tail only if not growing
                  if (!growing) {
                    snakeBody.pop_back();
                  }
                }
              }
            }
            
            // Draw food
            draw_list->AddRectFilled(
                ImVec2(boardPos.x + snakeFood.x * gridSize + 2, boardPos.y + snakeFood.y * gridSize + 2),
                ImVec2(boardPos.x + (snakeFood.x + 1) * gridSize - 2, boardPos.y + (snakeFood.y + 1) * gridSize - 2),
                IM_COL32(255, 0, 0, 255));
            
            // Draw snake
            for (size_t i = 0; i < snakeBody.size(); i++) {
              const auto& segment = snakeBody[i];
              ImU32 snakeColor = (i == 0) ? 
                  IM_COL32(0, 255, 0, 255) : // Head (green)
                  IM_COL32(0, 200, 0, 255);  // Body (darker green)
                  
              draw_list->AddRectFilled(
                  ImVec2(boardPos.x + segment.x * gridSize + 1, boardPos.y + segment.y * gridSize + 1),
                  ImVec2(boardPos.x + (segment.x + 1) * gridSize - 1, boardPos.y + (segment.y + 1) * gridSize - 1),
                  snakeColor);
            }
            
            // Reserve space for the board in ImGui layout
            ImGui::Dummy(ImVec2(boardSize.x, boardSize.y));
            
            ImGui::EndChild(); // End the fixed-size game area
          }
          
          ImGui::Separator();
          ImGui::Text("Lumyn Pong Game");

          // Function to initialize/reset the pong game
          auto initializePongGame = []() {
            pongPlayerPaddle.y = (float)pongGridHeight / 2 - 2;
            pongAIPaddle.y = (float)pongGridHeight / 2 - 2;
            pongBall.x = (float)pongGridWidth / 2;
            pongBall.y = (float)pongGridHeight / 2;
            pongBall.dx = (std::rand() % 2 == 0) ? 0.2f : -0.2f;
            pongBall.dy = ((std::rand() % 200) - 100) / 500.0f;
            pongPlayerScore = 0;
            pongAIScore = 0;
            pongGameOver = false;
            pongGameActive = true;
          };

          if (!pongGameActive && !pongGameOver) {
            initializePongGame();
          }

          {
            ImVec2 pongGameSize(pongGridWidth * 15.0f + 40, pongGridHeight * 15.0f + 120);
            ImGui::BeginChild("PongGameArea", pongGameSize, false);
            ImGui::Text("Controls: W/S or Up/Down arrows to move paddle");
            ImGui::Text("Player: %d  |  AI: %d  |  First to %d wins", pongPlayerScore, pongAIScore, pongWinningScore);
            if (pongGameOver) {
              bool playerWon = pongPlayerScore >= pongWinningScore;
              ImGui::TextColored(
                  playerWon ? ImVec4(0.3f, 1.0f, 0.3f, 1.0f) : ImVec4(1.0f, 0.3f, 0.3f, 1.0f),
                  "%s! Press spacebar to restart",
                  playerWon ? "YOU WIN" : "AI WINS");
              if (ImGui::IsKeyPressed(ImGuiKey_Space)) {
                initializePongGame();
              }
              float buttonWidth = ImGui::CalcTextSize("Restart Game").x + 20;
              ImGui::SetCursorPosX((pongGameSize.x - buttonWidth) * 0.5f);
              if (ImGui::Button("Restart Game", ImVec2(buttonWidth, 0))) {
                initializePongGame();
              }
            }
            if (!pongGameOver) {
              float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
              ImGui::SetCursorPosX((pongGameSize.x - buttonWidth) * 0.5f);
              if (ImGui::Button(pongGameActive ? "Pause Game" : "Resume Game", ImVec2(buttonWidth, 0))) {
                pongGameActive = !pongGameActive;
              }
            }
            if (!pongGameOver && pongGameActive) {
              if ((ImGui::IsKeyDown(ImGuiKey_W) || ImGui::IsKeyDown(ImGuiKey_UpArrow))) {
                pongPlayerPaddle.y -= pongPlayerPaddle.speed;
                if (pongPlayerPaddle.y < 0) pongPlayerPaddle.y = 0;
              }
              if ((ImGui::IsKeyDown(ImGuiKey_S) || ImGui::IsKeyDown(ImGuiKey_DownArrow))) {
                pongPlayerPaddle.y += pongPlayerPaddle.speed;
                if (pongPlayerPaddle.y + pongPlayerPaddle.height > pongGridHeight)
                  pongPlayerPaddle.y = pongGridHeight - pongPlayerPaddle.height;
              }
            }
            const float pongGridSize = 15.0f;
            const ImVec2 pongBoardPos = ImGui::GetCursorScreenPos();
            ImDrawList* pong_draw_list = ImGui::GetWindowDrawList();
            ImVec2 pongBoardSize(pongGridWidth * pongGridSize, pongGridHeight * pongGridSize);
            pong_draw_list->AddRectFilled(
                pongBoardPos,
                ImVec2(pongBoardPos.x + pongBoardSize.x, pongBoardPos.y + pongBoardSize.y),
                IM_COL32(10, 10, 30, 255));
            float centerX = pongBoardPos.x + pongBoardSize.x / 2;
            for (int i = 0; i < pongGridHeight; i += 2) {
              pong_draw_list->AddRectFilled(
                  ImVec2(centerX - 1, pongBoardPos.y + i * pongGridSize),
                  ImVec2(centerX + 1, pongBoardPos.y + (i + 1) * pongGridSize),
                  IM_COL32(100, 100, 100, 255));
            }
            pongGameTime += ImGui::GetIO().DeltaTime;
            if (pongGameActive && !pongGameOver && pongGameTime - pongLastUpdateTime >= pongUpdateInterval) {
              pongLastUpdateTime = pongGameTime;
              // AI paddle follows ball with a bit of lag
              float aiCurrentY = pongAIPaddle.y + pongAIPaddle.height / 2;
              if (aiCurrentY < pongBall.y - 0.5f) {
                pongAIPaddle.y += pongAIPaddle.speed;
              } else if (aiCurrentY > pongBall.y + 0.5f) {
                pongAIPaddle.y -= pongAIPaddle.speed;
              }
              if (pongAIPaddle.y < 0) pongAIPaddle.y = 0;
              if (pongAIPaddle.y + pongAIPaddle.height > pongGridHeight)
                pongAIPaddle.y = pongGridHeight - pongAIPaddle.height;
              pongBall.x += pongBall.dx;
              pongBall.y += pongBall.dy;
              if (pongBall.y <= 0 || pongBall.y >= pongGridHeight) {
                pongBall.dy = -pongBall.dy;
                pongBall.y = std::max(0.0f, std::min((float)pongGridHeight, pongBall.y));
              }
              if (pongBall.x <= 1.5f && pongBall.dx < 0) {
                if (pongBall.y >= pongPlayerPaddle.y && pongBall.y <= pongPlayerPaddle.y + pongPlayerPaddle.height) {
                  pongBall.dx = -pongBall.dx;
                  float hitPos = (pongBall.y - (pongPlayerPaddle.y + pongPlayerPaddle.height / 2)) / (pongPlayerPaddle.height / 2);
                  pongBall.dy += hitPos * 0.1f;
                  pongBall.x = 1.5f;
                }
              }
              if (pongBall.x >= pongGridWidth - 1.5f && pongBall.dx > 0) {
                if (pongBall.y >= pongAIPaddle.y && pongBall.y <= pongAIPaddle.y + pongAIPaddle.height) {
                  pongBall.dx = -pongBall.dx;
                  float hitPos = (pongBall.y - (pongAIPaddle.y + pongAIPaddle.height / 2)) / (pongAIPaddle.height / 2);
                  pongBall.dy += hitPos * 0.1f;
                  pongBall.x = pongGridWidth - 1.5f;
                }
              }
              if (pongBall.x < 0) {
                pongAIScore++;
                if (pongAIScore >= pongWinningScore) {
                  pongGameOver = true;
                } else {
                  pongBall.x = (float)pongGridWidth / 2;
                  pongBall.y = (float)pongGridHeight / 2;
                  pongBall.dx = 0.2f;
                  pongBall.dy = ((std::rand() % 200) - 100) / 500.0f;
                }
              }
              if (pongBall.x > pongGridWidth) {
                pongPlayerScore++;
                if (pongPlayerScore >= pongWinningScore) {
                  pongGameOver = true;
                } else {
                  pongBall.x = (float)pongGridWidth / 2;
                  pongBall.y = (float)pongGridHeight / 2;
                  pongBall.dx = -0.2f;
                  pongBall.dy = ((std::rand() % 200) - 100) / 500.0f;
                }
              }
              pongBall.dy = std::max(-0.4f, std::min(0.4f, pongBall.dy));
            }
            pong_draw_list->AddRectFilled(
                ImVec2(pongBoardPos.x + 5, pongBoardPos.y + pongPlayerPaddle.y * pongGridSize),
                ImVec2(pongBoardPos.x + 15, pongBoardPos.y + (pongPlayerPaddle.y + pongPlayerPaddle.height) * pongGridSize),
                IM_COL32(0, 150, 255, 255));
            pong_draw_list->AddRectFilled(
                ImVec2(pongBoardPos.x + pongBoardSize.x - 15, pongBoardPos.y + pongAIPaddle.y * pongGridSize),
                ImVec2(pongBoardPos.x + pongBoardSize.x - 5, pongBoardPos.y + (pongAIPaddle.y + pongAIPaddle.height) * pongGridSize),
                IM_COL32(255, 100, 100, 255));
            float ballRadius = pongGridSize * 0.3f;
            pong_draw_list->AddCircleFilled(
                ImVec2(pongBoardPos.x + pongBall.x * pongGridSize, pongBoardPos.y + pongBall.y * pongGridSize),
                ballRadius,
                IM_COL32(255, 255, 255, 255));
            ImGui::Dummy(ImVec2(pongBoardSize.x, pongBoardSize.y));
            ImGui::EndChild();
          }
          ImGui::End();
        });
      } });
  }
#endif
} // namespace lumyn::internal::c_ConnectorX