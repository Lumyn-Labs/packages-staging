#pragma once

#include <cinttypes>

#include "FileType.h"
#include "packed.h"

namespace lumyn::internal::Files
{
  PACK(struct FileTransferInfoHeader {
    char path[32];
  });

  PACK(struct SendConfigInfoHeader{});

struct __attribute__((packed)) SetZonePixelBuffer {
  uint16_t zoneId;
  // Added for extra safety; the size MUST be 3 * zoneLength (r, g, b)
  uint16_t zoneLength;
};

struct FilesHeader {
    FileType type;
    union
    {
    FileTransferInfoHeader fileTransfer;
    SendConfigInfoHeader sendConfig;
    SetZonePixelBuffer setZoneBuffer;
  };
  uint16_t md5;
  uint32_t fileSize;
};

  PACK(struct Files {
    FilesHeader header;
    uint8_t *bytes;
  });
} // namespace lumyn::internal::Files