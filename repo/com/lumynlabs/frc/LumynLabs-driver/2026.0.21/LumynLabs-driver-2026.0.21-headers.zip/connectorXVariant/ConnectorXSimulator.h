#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>
#include <vector>
#include <string>
#include <cstring>
#include <cmath>

namespace lumyn::internal::c_ConnectorX {

class ConnectorXSimulator {
public:
    ConnectorXSimulator() : ledCount_(60), connectorAnimTime_(0.0f), selectedZoneId_(0), status_("Connected") {
        zoneNames_[0] = "Zone-1 (LEDs 0-19)";
        zoneNames_[1] = "Zone-2 (LEDs 20-39)"; 
        zoneNames_[2] = "Zone-3 (LEDs 40-59)";
        std::strcpy(textBuffer_, "Hello World");
        std::strcpy(matrixTextBuffer_, "Matrix Text");
        initializeLEDs();
        initializeMatrix();
    }
    
    ~ConnectorXSimulator() = default;

    void update(float deltaTime) {
        connectorAnimTime_ += deltaTime;
        updateLEDAnimations();
        updateMatrixAnimations();
    }
    
    void render() {
        if (ImGui::Begin("Lumyn ConnectorX Simulator")) {
            // Status indicator only - no checkbox
            ImGui::Text("Status: %s", status_.c_str());
            
            renderLEDStrip();
            renderMatrixDisplay();
            renderControls();
            renderEventLog();
        }
        ImGui::End();
    }

private:
    // LED simulation variables
    std::vector<ImColor> ledColors_;
    int ledCount_;
    char textBuffer_[128];
    float scrollSpeed_[3];
    int animationSelector_[3];
    ImVec4 colorPicker_[3];
    bool animationRunning_[3];
    
    // Matrix simulation variables
    static constexpr int matrixWidth_ = 16;
    static constexpr int matrixHeight_ = 8;
    std::vector<std::vector<ImColor>> matrixColors_;
    int matrixAnimationSelector_;
    bool matrixAnimationRunning_;
    float matrixScrollSpeed_;
    ImVec4 matrixColorPicker_;
    char matrixTextBuffer_[64];
    int matrixBitmapSelector_;
    
    // Animation and control variables
    float connectorAnimTime_;
    int selectedZoneId_;
    const char* zoneNames_[3];
    std::string status_;
    std::vector<std::string> eventLog_;

    void initializeLEDs() {
        ledColors_.resize(ledCount_, ImColor(30, 30, 30, 255)); // Default dark LEDs
        for (int i = 0; i < 3; i++) {
            scrollSpeed_[i] = 0.5f;
            animationSelector_[i] = 0;
            // Zone 0: Red, Zone 1: Green, Zone 2: Blue
            if (i == 0) {
                colorPicker_[i] = ImVec4(1.0f, 0.0f, 0.0f, 1.0f); // Red
            } else if (i == 1) {
                colorPicker_[i] = ImVec4(0.0f, 1.0f, 0.0f, 1.0f); // Green
            } else {
                colorPicker_[i] = ImVec4(0.0f, 0.0f, 1.0f, 1.0f); // Blue
            }
            animationRunning_[i] = false;
        }
    }
    
    void initializeMatrix() {
        matrixColors_.resize(matrixHeight_);
        for (int y = 0; y < matrixHeight_; y++) {
            matrixColors_[y].resize(matrixWidth_, ImColor(20, 20, 20, 255));
        }
        matrixAnimationSelector_ = 0;
        matrixAnimationRunning_ = false;
        matrixScrollSpeed_ = 1.0f;
        matrixColorPicker_ = ImVec4(1.0f, 1.0f, 0.0f, 1.0f); // Yellow default
        matrixBitmapSelector_ = 0;
    }
    
    void updateLEDAnimations() {
        // Update LED colors based on animation for each zone
        for (int i = 0; i < ledCount_; i++) {
            // Determine which zone this LED belongs to
            int zoneIndex = i / 20; // 20 LEDs per zone
            
            if (animationRunning_[zoneIndex]) {
                // Different animation patterns
                switch (animationSelector_[zoneIndex]) {
                    case 0: // Rainbow
                    {
                        float hue = (float)(i % 20) / 20 + connectorAnimTime_ * 0.3f;
                        hue = hue - std::floor(hue);
                        ledColors_[i] = ImColor::HSV(hue, 1.0f, 1.0f);
                    }
                    break;
                    case 1: // Chase
                    {
                        int zoneStartLed = zoneIndex * 20;
                        int pos = zoneStartLed + (int)(connectorAnimTime_ * 5) % 20;
                        ledColors_[i] = (i == pos) ? ImColor(colorPicker_[zoneIndex]) : ImColor(30, 30, 30, 255);
                    }
                    break;
                    case 2: // Breathe
                    {
                        float brightness = 0.5f + 0.5f * std::sin(connectorAnimTime_ * 3.0f);
                        ledColors_[i] = ImColor(
                            colorPicker_[zoneIndex].x * brightness,
                            colorPicker_[zoneIndex].y * brightness,
                            colorPicker_[zoneIndex].z * brightness,
                            1.0f);
                    }
                    break;
                    case 3: // Text scroll
                    {
                        // Simple simulation of text scrolling with blinking
                        int zoneStartLed = zoneIndex * 20;
                        int zonePos = i - zoneStartLed;
                        int scrollPos = (int)(connectorAnimTime_ * scrollSpeed_[zoneIndex] * 5) % 40;
                        bool isVisible = (zonePos >= scrollPos - 3 && zonePos <= scrollPos + 3) % 20;
                        ledColors_[i] = isVisible ? ImColor(colorPicker_[zoneIndex]) : ImColor(10, 10, 10, 255);
                    }
                    break;
                }
            } else {
                // Show static zone color with dim brightness when not animating
                ledColors_[i] = ImColor(
                    colorPicker_[zoneIndex].x * 0.3f,
                    colorPicker_[zoneIndex].y * 0.3f,
                    colorPicker_[zoneIndex].z * 0.3f,
                    1.0f);
            }
        }
    }
    
    void updateMatrixAnimations() {
        if (matrixAnimationRunning_) {
            switch (matrixAnimationSelector_) {
                case 0: // Scrolling Text
                {
                    // Clear matrix
                    for (int y = 0; y < matrixHeight_; y++) {
                        for (int x = 0; x < matrixWidth_; x++) {
                            matrixColors_[y][x] = ImColor(20, 20, 20, 255);
                        }
                    }
                    
                    // Simple text scroll simulation
                    int textLen = strlen(matrixTextBuffer_);
                    int scrollPos = (int)(connectorAnimTime_ * matrixScrollSpeed_ * 3) % (textLen * 6 + matrixWidth_);
                    
                    for (int i = 0; i < textLen; i++) {
                        int charX = scrollPos - i * 6;
                        if (charX >= -5 && charX < matrixWidth_) {
                            drawCharacter(matrixTextBuffer_[i], charX, 1, ImColor(matrixColorPicker_));
                        }
                    }
                }
                break;
                case 1: // Heart Beat
                {
                    float pulse = 0.5f + 0.5f * std::sin(connectorAnimTime_ * 4.0f);
                    ImColor heartColor = ImColor(
                        matrixColorPicker_.x * pulse,
                        matrixColorPicker_.y * pulse,
                        matrixColorPicker_.z * pulse,
                        1.0f
                    );
                    
                    // Clear matrix
                    for (int y = 0; y < matrixHeight_; y++) {
                        for (int x = 0; x < matrixWidth_; x++) {
                            matrixColors_[y][x] = ImColor(20, 20, 20, 255);
                        }
                    }
                    
                    drawHeart(heartColor);
                }
                break;
                case 2: // Arrow Animation
                {
                    // Clear matrix
                    for (int y = 0; y < matrixHeight_; y++) {
                        for (int x = 0; x < matrixWidth_; x++) {
                            matrixColors_[y][x] = ImColor(20, 20, 20, 255);
                        }
                    }
                    
                    float brightness = 0.7f + 0.3f * std::sin(connectorAnimTime_ * 2.0f);
                    ImColor arrowColor = ImColor(
                        matrixColorPicker_.x * brightness,
                        matrixColorPicker_.y * brightness,
                        matrixColorPicker_.z * brightness,
                        1.0f
                    );
                    
                    drawArrow(arrowColor);
                }
                break;
                case 3: // Rain Effect
                {
                    // Fade existing pixels
                    for (int y = 0; y < matrixHeight_; y++) {
                        for (int x = 0; x < matrixWidth_; x++) {
                            ImU32 color = matrixColors_[y][x];
                            int r = ((color >> 0) & 0xFF) * 0.9f;
                            int g = ((color >> 8) & 0xFF) * 0.9f;
                            int b = ((color >> 16) & 0xFF) * 0.9f;
                            matrixColors_[y][x] = IM_COL32(r, g, b, 255);
                        }
                    }
                    
                    // Add new rain drops
                    if ((int)(connectorAnimTime_ * 10) % 3 == 0) {
                        for (int x = 0; x < matrixWidth_; x += 2) {
                            if (rand() % 4 == 0) {
                                matrixColors_[0][x] = ImColor(matrixColorPicker_);
                            }
                        }
                    }
                    
                    // Move rain down
                    for (int y = matrixHeight_ - 1; y > 0; y--) {
                        for (int x = 0; x < matrixWidth_; x++) {
                            matrixColors_[y][x] = matrixColors_[y-1][x];
                        }
                    }
                }
                break;
            }
        } else {
            // Show static pattern when not animating
            for (int y = 0; y < matrixHeight_; y++) {
                for (int x = 0; x < matrixWidth_; x++) {
                    if ((x + y) % 4 == 0) {
                        matrixColors_[y][x] = ImColor(
                            matrixColorPicker_.x * 0.3f,
                            matrixColorPicker_.y * 0.3f,
                            matrixColorPicker_.z * 0.3f,
                            1.0f
                        );
                    } else {
                        matrixColors_[y][x] = ImColor(20, 20, 20, 255);
                    }
                }
            }
        }
    }
    
    void renderLEDStrip() {
        // LED strip visualization
        ImGui::Separator();
        ImGui::Text("LED Strip Visualization");
        
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        const ImVec2 p = ImGui::GetCursorScreenPos();
        
        // LED strip area
        float stripWidth = 600.0f; // Wider to accommodate more LEDs
        float stripHeight = 40.0f;
        ImVec2 stripMin = ImVec2(p.x + 10, p.y + 10);
        ImVec2 stripMax = ImVec2(p.x + 10 + stripWidth, p.y + 10 + stripHeight);
        
        // Strip background
        draw_list->AddRectFilled(stripMin, stripMax, IM_COL32(20, 20, 20, 255), 3.0f);
        
        // Zone separators and labels
        float zoneWidth = stripWidth / 3;
        for (int z = 1; z < 3; z++) {
            float x = stripMin.x + z * zoneWidth;
            draw_list->AddLine(
                ImVec2(x, stripMin.y), 
                ImVec2(x, stripMax.y),
                IM_COL32(100, 100, 100, 255), 
                1.0f);
        }
        
        // Zone labels
        const char* zoneLabels[] = {"Zone 1", "Zone 2", "Zone 3"};
        ImU32 zoneLabelColors[] = {
            IM_COL32(255, 100, 100, 255), // Red tint
            IM_COL32(100, 255, 100, 255), // Green tint
            IM_COL32(100, 100, 255, 255)  // Blue tint
        };
        
        for (int z = 0; z < 3; z++) {
            float zoneCenter = stripMin.x + z * zoneWidth + zoneWidth / 2;
            ImVec2 textPos = ImVec2(zoneCenter - 20, stripMin.y - 15);
            draw_list->AddText(textPos, zoneLabelColors[z], zoneLabels[z]);
        }
        
        // Draw LEDs
        float ledSpacing = stripWidth / ledCount_;
        for (int i = 0; i < ledCount_; i++) {
            float x = stripMin.x + i * ledSpacing + ledSpacing/2;
            float y = stripMin.y + stripHeight/2;
            float radius = ledSpacing/2 - 1;
            
            // Draw LED with slight glow effect for brighter LEDs
            ImU32 ledColor = ledColors_[i];
            draw_list->AddCircleFilled(ImVec2(x, y), radius + 1, 
                IM_COL32((ledColor >> 0) & 0xFF, (ledColor >> 8) & 0xFF, (ledColor >> 16) & 0xFF, 50));
            draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors_[i]);
            draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
        }
        
        ImGui::Dummy(ImVec2(stripWidth + 20, stripHeight + 30));
    }
    
    void renderMatrixDisplay() {
        ImGui::Separator();
        ImGui::Text("LED Matrix Display (%dx%d)", matrixWidth_, matrixHeight_);
        
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        const ImVec2 p = ImGui::GetCursorScreenPos();
        
        float pixelSize = 15.0f;
        float matrixDisplayWidth = matrixWidth_ * pixelSize;
        float matrixDisplayHeight = matrixHeight_ * pixelSize;
        
        ImVec2 matrixMin = ImVec2(p.x + 10, p.y + 10);
        ImVec2 matrixMax = ImVec2(p.x + 10 + matrixDisplayWidth, p.y + 10 + matrixDisplayHeight);
        
        // Matrix background
        draw_list->AddRectFilled(matrixMin, matrixMax, IM_COL32(10, 10, 10, 255), 2.0f);
        
        // Draw matrix border
        draw_list->AddRect(matrixMin, matrixMax, IM_COL32(80, 80, 80, 255), 2.0f);
        
        // Draw matrix pixels
        for (int y = 0; y < matrixHeight_; y++) {
            for (int x = 0; x < matrixWidth_; x++) {
                ImVec2 pixelMin = ImVec2(
                    matrixMin.x + x * pixelSize + 1,
                    matrixMin.y + y * pixelSize + 1
                );
                ImVec2 pixelMax = ImVec2(
                    matrixMin.x + (x + 1) * pixelSize - 1,
                    matrixMin.y + (y + 1) * pixelSize - 1
                );
                
                // Add slight glow for brighter pixels
                ImU32 pixelColor = matrixColors_[y][x];
                if (((pixelColor >> 0) & 0xFF) > 50 || 
                    ((pixelColor >> 8) & 0xFF) > 50 || 
                    ((pixelColor >> 16) & 0xFF) > 50) {
                    draw_list->AddRectFilled(
                        ImVec2(pixelMin.x - 1, pixelMin.y - 1),
                        ImVec2(pixelMax.x + 1, pixelMax.y + 1),
                        IM_COL32(
                            ((pixelColor >> 0) & 0xFF) / 4,
                            ((pixelColor >> 8) & 0xFF) / 4,
                            ((pixelColor >> 16) & 0xFF) / 4,
                            100
                        ),
                        1.0f
                    );
                }
                
                draw_list->AddRectFilled(pixelMin, pixelMax, pixelColor, 1.0f);
            }
        }
        
        ImGui::Dummy(ImVec2(matrixDisplayWidth + 20, matrixDisplayHeight + 20));
        
        // Matrix controls
        ImGui::Separator();
        ImGui::Text("Matrix Controls");
        
        const char* matrixAnimationNames[] = {"Scrolling Text", "Heart Beat", "Arrow", "Rain Effect"};
        if (ImGui::BeginCombo("Matrix Animation", matrixAnimationNames[matrixAnimationSelector_])) {
            for (int i = 0; i < 4; i++) {
                bool isSelected = (matrixAnimationSelector_ == i);
                if (ImGui::Selectable(matrixAnimationNames[i], isSelected)) {
                    matrixAnimationSelector_ = i;
                    logEvent("Matrix animation changed to " + std::string(matrixAnimationNames[i]));
                }
                if (isSelected) {
                    ImGui::SetItemDefaultFocus();
                }
            }
            ImGui::EndCombo();
        }
        
        ImGui::ColorEdit3("Matrix Color", (float*)&matrixColorPicker_);
        
        if (matrixAnimationSelector_ == 0) { // Text scroll
            ImGui::InputText("Matrix Text", matrixTextBuffer_, sizeof(matrixTextBuffer_));
            ImGui::SliderFloat("Scroll Speed", &matrixScrollSpeed_, 0.5f, 3.0f);
        }
        
        if (ImGui::Button(matrixAnimationRunning_ ? "Stop Matrix Animation" : "Start Matrix Animation")) {
            matrixAnimationRunning_ = !matrixAnimationRunning_;
            logEvent(std::string("Matrix animation ") + 
                    (matrixAnimationRunning_ ? "started" : "stopped"));
        }
    }
    
    void drawCharacter(char c, int startX, int startY, ImColor color) {
        // For simplicity, just draw a basic pattern for any character
        for (int y = 0; y < 7 && startY + y < matrixHeight_; y++) {
            for (int x = 0; x < 5 && startX + x >= 0 && startX + x < matrixWidth_; x++) {
                if (startX + x >= 0 && startY + y >= 0) {
                    // Simple pattern - make letters recognizable
                    bool pixel = false;
                    if (c >= 'A' && c <= 'Z') {
                        // Draw a simple letter pattern
                        pixel = (x == 0 || x == 4 || y == 0 || y == 3 || y == 6) && 
                               !(x == 0 && y == 0) && !(x == 4 && y == 0);
                    } else if (c >= '0' && c <= '9') {
                        // Draw a simple number pattern
                        pixel = (x == 0 || x == 4 || y == 0 || y == 6) || 
                               (y == 3 && (x == 1 || x == 3));
                    } else {
                        // Default pattern for other characters
                        pixel = (x + y) % 2 == 0;
                    }
                    
                    if (pixel) {
                        matrixColors_[startY + y][startX + x] = color;
                    }
                }
            }
        }
    }
    
    void drawHeart(ImColor color) {
        // Heart pattern on 16x8 matrix
        const bool heartPattern[8][16] = {
            {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
            {0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0},
            {0,1,1,1,1,0,0,0,0,0,1,1,1,1,0,0},
            {1,1,1,1,1,1,0,0,0,1,1,1,1,1,1,0},
            {1,1,1,1,1,1,1,0,1,1,1,1,1,1,1,0},
            {0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
            {0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0},
            {0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0}
        };
        
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 16; x++) {
                if (heartPattern[y][x]) {
                    matrixColors_[y][x] = color;
                }
            }
        }
    }
    
    void drawArrow(ImColor color) {
        // Right arrow pattern on 16x8 matrix
        const bool arrowPattern[8][16] = {
            {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0},
            {1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0},
            {1,1,1,1,1,1,1,1,1,1,1,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0},
            {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0}
        };
        
        for (int y = 0; y < 8; y++) {
            for (int x = 0; x < 16; x++) {
                if (arrowPattern[y][x]) {
                    matrixColors_[y][x] = color;
                }
            }
        }
    }
    
    void logEvent(const std::string& event) {
        eventLog_.push_back(event);
        if (eventLog_.size() > 10) {
            eventLog_.erase(eventLog_.begin());
        }
    }
    
    void renderEventLog() {
        ImGui::Separator();
        ImGui::Text("Event Log");
        ImGui::BeginChild("EventLog", ImVec2(0, 100), true);
        for (const auto& event : eventLog_) {
            ImGui::TextWrapped("%s", event.c_str());
        }
        ImGui::EndChild();
    }
    
    void renderControls() {
        ImGui::Separator();
        
        // Zone selection with arrow dropdown
        ImGui::PushStyleColor(ImGuiCol_Header, IM_COL32(50, 50, 100, 255));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered, IM_COL32(70, 70, 120, 255));
        ImGui::PushStyleColor(ImGuiCol_HeaderActive, IM_COL32(90, 90, 140, 255));
        if (ImGui::CollapsingHeader(zoneNames_[selectedZoneId_], ImGuiTreeNodeFlags_DefaultOpen)) {
            ImGui::PopStyleColor(3);
            
            // "Active Zone" label on the right
            float windowWidth = ImGui::GetWindowWidth();
            ImGui::SameLine(windowWidth - 100);
            ImGui::TextDisabled("Active Zone");
            
            ImGui::Text("Controls for %s", zoneNames_[selectedZoneId_]);
            
            // Animation selection
            const char* animationNames[] = {"Rainbow", "Chase", "Breathe", "Text Scroll"};
            if (ImGui::BeginCombo("Animation", animationNames[animationSelector_[selectedZoneId_]])) {
                for (int i = 0; i < 4; i++) {
                    bool isSelected = (animationSelector_[selectedZoneId_] == i);
                    if (ImGui::Selectable(animationNames[i], isSelected)) {
                        animationSelector_[selectedZoneId_] = i;
                        logEvent("Zone " + std::to_string(selectedZoneId_ + 1) + " animation changed to " + animationNames[i]);
                    }
                    if (isSelected) {
                        ImGui::SetItemDefaultFocus();
                    }
                }
                ImGui::EndCombo();
            }
            
            // Color picker
            ImGui::PushItemWidth(100);
            ImGui::Text("R: %.0f", colorPicker_[selectedZoneId_].x * 255.0f);
            ImGui::SameLine(120); 
            ImGui::Text("G: %.0f", colorPicker_[selectedZoneId_].y * 255.0f); 
            ImGui::SameLine(240);
            ImGui::Text("B: %.0f", colorPicker_[selectedZoneId_].z * 255.0f);
            ImGui::SameLine();
            ImGui::ColorButton("Color", colorPicker_[selectedZoneId_], 0, ImVec2(20, 20));
            ImGui::PopItemWidth();
            
            // Show text input only for text scroll animation
            if (animationSelector_[selectedZoneId_] == 3) { // Text Scroll
                ImGui::Text("Text for scroll animation");
                ImGui::InputText("##Text", textBuffer_, sizeof(textBuffer_));
            }
            
            // Animation speed slider
            ImGui::Text("Animation Speed");
            ImGui::SliderFloat("##Speed", &scrollSpeed_[selectedZoneId_], 0.1f, 2.0f, "%.3f");
            
            // Control buttons
            if (ImGui::Button(animationRunning_[selectedZoneId_] ? 
                             "Stop Animation for Zone" : 
                             "Start Animation for Zone", ImVec2(200, 0))) {
                animationRunning_[selectedZoneId_] = !animationRunning_[selectedZoneId_];
                logEvent(std::string("Zone ") + std::to_string(selectedZoneId_ + 1) + 
                        (animationRunning_[selectedZoneId_] ? " animation started" : " animation stopped"));
            }
            
            ImGui::SameLine();
            if (ImGui::Button("Start/Stop All Zones", ImVec2(200, 0))) {
                bool someRunning = false;
                for (int i = 0; i < 3; i++) {
                    if (animationRunning_[i]) {
                        someRunning = true;
                        break;
                    }
                }
                
                for (int i = 0; i < 3; i++) {
                    animationRunning_[i] = !someRunning;
                }
                
                logEvent(someRunning ? "All animations stopped" : "All animations started");
            }
        } else {
            ImGui::PopStyleColor(3);
        }
        
        // Allow selecting a different zone
        ImGui::Separator();
        for (int i = 0; i < 3; i++) {
            if (i > 0) ImGui::SameLine();
            if (ImGui::Button(zoneNames_[i], ImVec2((ImGui::GetWindowWidth() - 20) / 3, 0))) {
                selectedZoneId_ = i;
                logEvent(std::string("Selected zone: ") + zoneNames_[i]);
            }
        }
    }
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
