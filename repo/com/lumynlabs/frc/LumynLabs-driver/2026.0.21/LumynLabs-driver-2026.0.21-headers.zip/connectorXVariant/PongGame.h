#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>
#include <algorithm>

namespace lumyn::internal::c_ConnectorX {

class PongGame {
public:
    PongGame() : showWindow_(false), gameWidth_(400.0f), gameHeight_(300.0f),
                 ballPos_{200.0f, 150.0f}, ballVel_{150.0f, 100.0f},
                 paddleHeight_(60.0f), paddleWidth_(10.0f),
                 leftPaddleY_(120.0f), rightPaddleY_(120.0f),
                 leftScore_(0), rightScore_(0), paddleSpeed_(200.0f) {}
    
    ~PongGame() = default;

    void update(float deltaTime) {
        if (!showWindow_) return;
        
        handleInput(deltaTime);
        updateBall(deltaTime);
        updateAI(deltaTime);
    }
    
    void render() {
        if (!showWindow_) return;
        
        if (ImGui::Begin("Pong Game", &showWindow_)) {
            // Score display with colors
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(0, 255, 100, 255));
            ImGui::Text("Player: %d", leftScore_);
            ImGui::PopStyleColor();
            
            ImGui::SameLine();
            ImGui::Text(" - ");
            ImGui::SameLine();
            
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 100, 100, 255));
            ImGui::Text("AI: %d", rightScore_);
            ImGui::PopStyleColor();
            
            renderGame();
            
            ImGui::Separator();
            ImGui::Text("Controls: W/S to move left paddle (green)");
            ImGui::Text("First to 10 points wins!");
            
            if (ImGui::Button("Reset Game")) {
                resetGame();
            }
            
            // Display winner
            if (leftScore_ >= 10) {
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(0, 255, 100, 255));
                ImGui::Text("PLAYER WINS!");
                ImGui::PopStyleColor();
            } else if (rightScore_ >= 10) {
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 100, 100, 255));
                ImGui::Text("AI WINS!");
                ImGui::PopStyleColor();
            }
        }
        ImGui::End();
    }
    
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    bool showWindow_;
    float gameWidth_, gameHeight_;
    ImVec2 ballPos_, ballVel_;
    float paddleHeight_, paddleWidth_;
    float leftPaddleY_, rightPaddleY_;
    int leftScore_, rightScore_;
    float paddleSpeed_;

    void handleInput(float deltaTime) {
        if (ImGui::IsKeyDown(ImGuiKey_W)) {
            leftPaddleY_ = std::max(0.0f, leftPaddleY_ - paddleSpeed_ * deltaTime);
        }
        if (ImGui::IsKeyDown(ImGuiKey_S)) {
            leftPaddleY_ = std::min(gameHeight_ - paddleHeight_, leftPaddleY_ + paddleSpeed_ * deltaTime);
        }
    }
    
    void updateBall(float deltaTime) {
        ballPos_.x += ballVel_.x * deltaTime;
        ballPos_.y += ballVel_.y * deltaTime;
        
        // Top/bottom collision
        if (ballPos_.y <= 6 || ballPos_.y >= gameHeight_ - 6) {
            ballVel_.y = -ballVel_.y;
            ballPos_.y = std::clamp(ballPos_.y, 6.0f, gameHeight_ - 6.0f);
        }
        
        // Left paddle collision
        if (ballPos_.x <= 15 + paddleWidth_ && ballPos_.x >= 5 && 
            ballPos_.y >= leftPaddleY_ - 6 && ballPos_.y <= leftPaddleY_ + paddleHeight_ + 6) {
            if (ballVel_.x < 0) { // Only if ball is moving towards paddle
                ballVel_.x = std::abs(ballVel_.x) * 1.05f; // Slight speed increase
                // Add some vertical spin based on where ball hits paddle
                float hitPos = (ballPos_.y - leftPaddleY_) / paddleHeight_ - 0.5f;
                ballVel_.y += hitPos * 100.0f;
                ballPos_.x = 15 + paddleWidth_;
            }
        }
        
        // Right paddle collision
        if (ballPos_.x >= gameWidth_ - 15 - paddleWidth_ && ballPos_.x <= gameWidth_ - 5 && 
            ballPos_.y >= rightPaddleY_ - 6 && ballPos_.y <= rightPaddleY_ + paddleHeight_ + 6) {
            if (ballVel_.x > 0) { // Only if ball is moving towards paddle
                ballVel_.x = -std::abs(ballVel_.x) * 1.05f; // Slight speed increase
                // Add some vertical spin based on where ball hits paddle
                float hitPos = (ballPos_.y - rightPaddleY_) / paddleHeight_ - 0.5f;
                ballVel_.y += hitPos * 100.0f;
                ballPos_.x = gameWidth_ - 15 - paddleWidth_;
            }
        }
        
        // Clamp ball velocity to reasonable limits
        ballVel_.x = std::clamp(ballVel_.x, -300.0f, 300.0f);
        ballVel_.y = std::clamp(ballVel_.y, -200.0f, 200.0f);
        
        // Score
        if (ballPos_.x < 0) {
            rightScore_++;
            resetBall();
        } else if (ballPos_.x > gameWidth_) {
            leftScore_++;
            resetBall();
        }
    }
    
    void updateAI(float deltaTime) {
        float targetY = ballPos_.y - paddleHeight_ / 2;
        if (rightPaddleY_ < targetY) {
            rightPaddleY_ = std::min(gameHeight_ - paddleHeight_, 
                                   rightPaddleY_ + paddleSpeed_ * deltaTime * 0.7f);
        } else {
            rightPaddleY_ = std::max(0.0f, rightPaddleY_ - paddleSpeed_ * deltaTime * 0.7f);
        }
    }
    
    void renderGame() {
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        ImVec2 canvas_pos = ImGui::GetCursorScreenPos();
        
        // Draw field background
        draw_list->AddRectFilled(canvas_pos, 
                          ImVec2(canvas_pos.x + gameWidth_, canvas_pos.y + gameHeight_),
                          IM_COL32(20, 20, 40, 255)); // Dark blue background
        
        // Draw field border
        draw_list->AddRect(canvas_pos, 
                          ImVec2(canvas_pos.x + gameWidth_, canvas_pos.y + gameHeight_),
                          IM_COL32(80, 100, 200, 255), 0.0f, 0, 2.0f);
        
        // Draw center line
        for (int y = 0; y < gameHeight_; y += 10) {
            draw_list->AddRectFilled(
                ImVec2(canvas_pos.x + gameWidth_/2 - 1, canvas_pos.y + y),
                ImVec2(canvas_pos.x + gameWidth_/2 + 1, canvas_pos.y + y + 5),
                IM_COL32(100, 150, 250, 150)
            );
        }
        
        // Draw left paddle (player - green)
        draw_list->AddRectFilled(
            ImVec2(canvas_pos.x + 5, canvas_pos.y + leftPaddleY_),
            ImVec2(canvas_pos.x + 5 + paddleWidth_, canvas_pos.y + leftPaddleY_ + paddleHeight_),
            IM_COL32(0, 220, 100, 255)
        );
        
        // Draw right paddle (AI - red)
        draw_list->AddRectFilled(
            ImVec2(canvas_pos.x + gameWidth_ - paddleWidth_ - 5, canvas_pos.y + rightPaddleY_),
            ImVec2(canvas_pos.x + gameWidth_ - 5, canvas_pos.y + rightPaddleY_ + paddleHeight_),
            IM_COL32(220, 60, 60, 255)
        );
        
        // Draw ball with glow effect
        float ballRadius = 6.0f;
        ImVec2 ballCenter = ImVec2(canvas_pos.x + ballPos_.x, canvas_pos.y + ballPos_.y);
        
        // Ball glow
        draw_list->AddCircleFilled(ballCenter, ballRadius + 4, IM_COL32(255, 220, 40, 30));
        draw_list->AddCircleFilled(ballCenter, ballRadius + 2, IM_COL32(255, 220, 40, 60));
        
        // Ball core
        draw_list->AddCircleFilled(ballCenter, ballRadius, IM_COL32(255, 220, 40, 255));
        
        ImGui::Dummy(ImVec2(gameWidth_, gameHeight_));
    }
    
    void resetBall() {
        ballPos_ = {gameWidth_/2, gameHeight_/2};
        ballVel_.x = (ballVel_.x > 0) ? -150.0f : 150.0f;
        ballVel_.y = (rand() % 2 == 0) ? 100.0f : -100.0f;
    }
    
    void resetGame() {
        leftScore_ = 0;
        rightScore_ = 0;
        leftPaddleY_ = gameHeight_/2 - paddleHeight_/2;
        rightPaddleY_ = gameHeight_/2 - paddleHeight_/2;
        resetBall();
    }
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
