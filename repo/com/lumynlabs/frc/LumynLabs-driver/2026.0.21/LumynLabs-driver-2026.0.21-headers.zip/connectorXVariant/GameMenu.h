#pragma once

#ifdef DESKTOP
#ifdef HALSIMGUI_EXT_ADDGUILATEEXECUTE
#include <imgui.h>

namespace lumyn::internal::c_ConnectorX {

// Forward declarations
class SnakeGame;
class PongGame;

class GameMenu {
public:
    GameMenu() : showWindow_(false) {}
    ~GameMenu() = default;

    void render(SnakeGame& snakeGame, PongGame& pongGame) {
        if (!showWindow_) return;
        
        ImGui::SetNextWindowSize(ImVec2(300, 280), ImGuiCond_FirstUseEver);
        if (ImGui::Begin("Lumyn Games Menu", &showWindow_)) {
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(120, 180, 255, 255));
            ImGui::Text("Available Games");
            ImGui::PopStyleColor();
            ImGui::Separator();
            
            // Game buttons with color styling
            ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(20, 80, 20, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(40, 140, 40, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(60, 180, 60, 255));
            if (ImGui::Button("Snake Game", ImVec2(130, 50))) {
                snakeGame.setWindowOpen(true);
            }
            ImGui::PopStyleColor(3);
            
            ImGui::SameLine();
            
            ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(80, 20, 20, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(140, 40, 40, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(180, 60, 60, 255));
            if (ImGui::Button("Pong Game", ImVec2(130, 50))) {
                pongGame.setWindowOpen(true);
            }
            ImGui::PopStyleColor(3);
            
            ImGui::Spacing();
            ImGui::Separator();
            
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(180, 220, 255, 255));
            ImGui::Text("Game Controls:");
            ImGui::PopStyleColor();
            
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(180, 255, 180, 255));
            ImGui::Text("Snake:");
            ImGui::PopStyleColor();
            ImGui::Indent(20);
            ImGui::BulletText("Use WASD keys to navigate");
            ImGui::BulletText("Collect food to grow longer");
            ImGui::BulletText("Avoid hitting walls and yourself");
            ImGui::Unindent(20);
            
            ImGui::Spacing();
            
            ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 180, 180, 255));
            ImGui::Text("Pong:");
            ImGui::PopStyleColor();
            ImGui::Indent(20);
            ImGui::BulletText("Use W/S keys to move left paddle");
            ImGui::BulletText("Beat the computer AI to win");
            ImGui::BulletText("First to 10 points wins");
            ImGui::Unindent(20);
            
            ImGui::Spacing();
            ImGui::Separator();
            
            ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(60, 60, 120, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(80, 80, 160, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonActive, IM_COL32(100, 100, 200, 255));
            if (ImGui::Button("Close All Games", ImVec2(-1, 0))) {
                snakeGame.setWindowOpen(false);
                pongGame.setWindowOpen(false);
            }
            ImGui::PopStyleColor(3);
        }
        ImGui::End();
    }
    
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    bool showWindow_;
};

} // namespace lumyn::internal::c_ConnectorX

#endif // HALSIMGUI_EXT_ADDGUILATEEXECUTE
#endif // DESKTOP
