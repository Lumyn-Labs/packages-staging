#ifdef DESKTOP
#include "ConnectorXSimulator.h"
#include <algorithm>
#include <cmath>
#include <cstdio>

namespace lumyn::internal::c_ConnectorX {

ConnectorXSimulator::ConnectorXSimulator()
    : ledCount_(60)
    , scrollSpeed_{0.5f, 0.5f, 0.5f}
    , animationSelector_{0, 0, 0}
    , colorPicker_{
        ImVec4(1.0f, 0.0f, 0.0f, 1.0f), // Red default for zone 1
        ImVec4(0.0f, 1.0f, 0.0f, 1.0f), // Green default for zone 2
        ImVec4(0.0f, 0.0f, 1.0f, 1.0f)  // Blue default for zone 3
    }
    , animationRunning_{false, false, false}
    , connectorAnimTime_(0.0f)
    , selectedZoneId_(0)
    , zoneNames_{"Zone-1 (LEDs 0-19)", "Zone-2 (LEDs 20-39)", "Zone-3 (LEDs 40-59)"}
    , status_("Connected")
    , matrixAnimationSelector_(0)
    , matrixAnimationRunning_(false)
    , matrixScrollSpeed_(1.0f)
    , matrixColorPicker_(ImVec4(1.0f, 1.0f, 0.0f, 1.0f))
    , matrixBitmapSelector_(0)
{
    strcpy(textBuffer_, "");
    strcpy(matrixTextBuffer_, "Matrix Text");
    initializeLEDs();
    initializeMatrix();
}

void ConnectorXSimulator::initializeLEDs() {
    if (ledColors_.empty()) {
        ledColors_.resize(ledCount_, ImColor(30, 30, 30, 255)); // Default dark LEDs
    }
}

void ConnectorXSimulator::initializeMatrix() {
    matrixColors_.resize(matrixHeight_);
    for (int y = 0; y < matrixHeight_; y++) {
        matrixColors_[y].resize(matrixWidth_, ImColor(20, 20, 20, 255));
    }
    matrixAnimationSelector_ = 0;
    matrixAnimationRunning_ = false;
    matrixScrollSpeed_ = 1.0f;
    matrixColorPicker_ = ImVec4(1.0f, 1.0f, 0.0f, 1.0f); // Yellow default
    matrixBitmapSelector_ = 0;
}

void ConnectorXSimulator::update(float deltaTime) {
    connectorAnimTime_ += deltaTime;
    updateLEDAnimations();
    updateMatrixAnimations();
}

void ConnectorXSimulator::updateLEDAnimations() {
    // Update LED colors based on animation for each zone
    for (int i = 0; i < ledCount_; i++) {
        // Determine which zone this LED belongs to
        int zoneIndex = i / 20; // 20 LEDs per zone
        
        if (animationRunning_[zoneIndex]) {
            // Different animation patterns
            switch (animationSelector_[zoneIndex]) {
                case 0: // Rainbow
                {
                    float hue = (float)(i % 20) / 20 + connectorAnimTime_ * 0.3f;
                    hue = hue - floorf(hue);
                    ImColor color = ImColor::HSV(hue, 1.0f, 1.0f);
                    ledColors_[i] = color;
                }
                break;
                case 1: // Chase
                {
                    int zoneStartLed = zoneIndex * 20;
                    int pos = zoneStartLed + (int)(connectorAnimTime_ * 5) % 20;
                    ledColors_[i] = (i == pos) ? ImColor(colorPicker_[zoneIndex]) : ImColor(30, 30, 30, 255);
                }
                break;
                case 2: // Breathe
                {
                    float brightness = 0.5f + 0.5f * sinf(connectorAnimTime_ * 3.0f);
                    ledColors_[i] = ImColor(
                        colorPicker_[zoneIndex].x * brightness,
                        colorPicker_[zoneIndex].y * brightness,
                        colorPicker_[zoneIndex].z * brightness,
                        1.0f);
                }
                break;
                case 3: // Text scroll
                {
                    // Simple simulation of text scrolling with blinking
                    int zoneStartLed = zoneIndex * 20;
                    int zonePos = i - zoneStartLed;
                    int scrollPos = (int)(connectorAnimTime_ * scrollSpeed_[zoneIndex] * 5) % 40;
                    bool isVisible = (zonePos >= scrollPos - 3 && zonePos <= scrollPos + 3) % 20;
                    ledColors_[i] = isVisible ? ImColor(colorPicker_[zoneIndex]) : ImColor(10, 10, 10, 255);
                }
                break;
            }
        }
    }
}

void ConnectorXSimulator::updateMatrixAnimations() {
    if (!matrixAnimationRunning_) return;
    
    // Clear matrix
    for (int y = 0; y < matrixHeight_; y++) {
        for (int x = 0; x < matrixWidth_; x++) {
            matrixColors_[y][x] = ImColor(20, 20, 20, 255);
        }
    }
    
    switch (matrixAnimationSelector_) {
        case 0: // Text scroll
        {
            std::string text = matrixTextBuffer_;
            if (text.empty()) text = "Matrix";
            
            int scrollOffset = (int)(connectorAnimTime_ * matrixScrollSpeed_ * 8) % (text.length() * 6 + matrixWidth_);
            
            for (size_t i = 0; i < text.length(); i++) {
                char c = text[i];
                int charX = matrixWidth_ - scrollOffset + i * 6;
                
                // Simple 5x7 character rendering for common characters
                drawCharacter(c, charX, 1, ImColor(matrixColorPicker_));
            }
        }
        break;
        
        case 1: // Bitmap pattern - Smiley face
        {
            // Simple smiley face pattern
            if (matrixBitmapSelector_ == 0) {
                // Eyes
                if (matrixWidth_ >= 16 && matrixHeight_ >= 8) {
                    matrixColors_[2][4] = ImColor(matrixColorPicker_);
                    matrixColors_[2][5] = ImColor(matrixColorPicker_);
                    matrixColors_[2][10] = ImColor(matrixColorPicker_);
                    matrixColors_[2][11] = ImColor(matrixColorPicker_);
                    
                    // Mouth
                    for (int x = 5; x <= 10; x++) {
                        matrixColors_[6][x] = ImColor(matrixColorPicker_);
                    }
                    matrixColors_[5][5] = ImColor(matrixColorPicker_);
                    matrixColors_[5][10] = ImColor(matrixColorPicker_);
                }
            } else if (matrixBitmapSelector_ == 1) {
                // Heart pattern
                drawHeart(ImColor(matrixColorPicker_));
            } else if (matrixBitmapSelector_ == 2) {
                // Arrow pattern
                drawArrow(ImColor(matrixColorPicker_));
            }
        }
        break;
        
        case 2: // Wave animation
        {
            for (int x = 0; x < matrixWidth_; x++) {
                float wave = sin((x * 0.5f) + (connectorAnimTime_ * 3.0f)) * 2.0f + 3.5f;
                int y = (int)wave;
                if (y >= 0 && y < matrixHeight_) {
                    matrixColors_[y][x] = ImColor(matrixColorPicker_);
                }
            }
        }
        break;
        
        case 3: // Rain animation
        {
            // Simple falling rain effect
            for (int x = 0; x < matrixWidth_; x++) {
                float drop = fmod(connectorAnimTime_ * matrixScrollSpeed_ * 3.0f + x * 0.7f, matrixHeight_ + 3);
                int y = (int)drop;
                if (y >= 0 && y < matrixHeight_) {
                    float brightness = 1.0f - (drop - y); // Fade effect
                    matrixColors_[y][x] = ImColor(
                        matrixColorPicker_.x * brightness,
                        matrixColorPicker_.y * brightness,
                        matrixColorPicker_.z * brightness,
                        1.0f);
                }
            }
        }
        break;
    }
}

void ConnectorXSimulator::render() {
    ImGui::Begin("Lumyn ConnectorX Simulator");
    
    // Status indicator
    ImGui::Text("Status: %s", status_.c_str());
    
    renderLEDStrip();
    renderMatrixDisplay();
    renderControls();
    renderEventLog();
    
    ImGui::Separator();
    ImGui::Text("Lumyn Games");
    
    ImGui::End();
}

void ConnectorXSimulator::renderLEDStrip() {
    // LED strip visualization
    ImGui::Separator();
    ImGui::Text("LED Strip Visualization");
    
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    
    // LED strip area
    float stripWidth = 600.0f; // Wider to accommodate more LEDs
    float stripHeight = 40.0f;
    ImVec2 stripMin = ImVec2(p.x + 10, p.y + 10);
    ImVec2 stripMax = ImVec2(p.x + 10 + stripWidth, p.y + 10 + stripHeight);
    
    // Strip background
    draw_list->AddRectFilled(stripMin, stripMax, IM_COL32(20, 20, 20, 255), 3.0f);
    
    // Zone separators
    float zoneWidth = stripWidth / 3;
    for (int z = 1; z < 3; z++) {
        float x = stripMin.x + z * zoneWidth;
        draw_list->AddLine(
            ImVec2(x, stripMin.y), 
            ImVec2(x, stripMax.y),
            IM_COL32(100, 100, 100, 255), 
            1.0f);
    }
    
    // Draw LEDs
    float ledSpacing = stripWidth / ledCount_;
    for (int i = 0; i < ledCount_; i++) {
        float x = stripMin.x + i * ledSpacing + ledSpacing/2;
        float y = stripMin.y + stripHeight/2;
        float radius = ledSpacing/2 - 1;
        
        // Draw LED
        draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors_[i]);
        draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
    }
    
    ImGui::Dummy(ImVec2(stripWidth + 20, stripHeight + 20));
}

void ConnectorXSimulator::renderMatrixDisplay() {
    ImGui::Separator();
    ImGui::Text("LED Matrix Display (16x8)");
    
    ImDrawList* draw_list = ImGui::GetWindowDrawList();
    const ImVec2 p = ImGui::GetCursorScreenPos();
    
    // Matrix area
    float pixelSize = 20.0f;
    float spacing = 2.0f;
    float matrixDisplayWidth = matrixWidth_ * (pixelSize + spacing) - spacing;
    float matrixDisplayHeight = matrixHeight_ * (pixelSize + spacing) - spacing;
    
    ImVec2 matrixMin = ImVec2(p.x + 10, p.y + 10);
    ImVec2 matrixMax = ImVec2(matrixMin.x + matrixDisplayWidth, matrixMin.y + matrixDisplayHeight);
    
    // Matrix background
    draw_list->AddRectFilled(matrixMin, matrixMax, IM_COL32(10, 10, 10, 255), 3.0f);
    
    // Draw matrix pixels
    for (int y = 0; y < matrixHeight_; y++) {
        for (int x = 0; x < matrixWidth_; x++) {
            float pixelX = matrixMin.x + x * (pixelSize + spacing);
            float pixelY = matrixMin.y + y * (pixelSize + spacing);
            
            ImVec2 pixelMin = ImVec2(pixelX, pixelY);
            ImVec2 pixelMax = ImVec2(pixelX + pixelSize, pixelY + pixelSize);
            
            // Draw pixel with slight glow effect
            ImU32 pixelColor = matrixColors_[y][x];
            float brightness = ((pixelColor >> 0) & 0xFF) + ((pixelColor >> 8) & 0xFF) + ((pixelColor >> 16) & 0xFF);
            
            if (brightness > 60) {
                // Add glow for bright pixels
                draw_list->AddRectFilled(
                    ImVec2(pixelX - 1, pixelY - 1),
                    ImVec2(pixelX + pixelSize + 1, pixelY + pixelSize + 1),
                    IM_COL32((pixelColor >> 0) & 0xFF, (pixelColor >> 8) & 0xFF, (pixelColor >> 16) & 0xFF, 30),
                    2.0f);
            }
            
            draw_list->AddRectFilled(pixelMin, pixelMax, pixelColor, 1.0f);
            draw_list->AddRect(pixelMin, pixelMax, IM_COL32(50, 50, 50, 100), 1.0f);
        }
    }
    
    ImGui::Dummy(ImVec2(matrixDisplayWidth + 20, matrixDisplayHeight + 20));
    
    // Matrix controls
    ImGui::Separator();
    ImGui::Text("Matrix Controls");
    
    // Animation selection
    const char* matrixAnimations[] = {"Text Scroll", "Bitmap", "Wave", "Rain"};
    if (ImGui::Combo("Matrix Animation", &matrixAnimationSelector_, matrixAnimations, IM_ARRAYSIZE(matrixAnimations))) {
        logEvent("Matrix animation changed to " + std::string(matrixAnimations[matrixAnimationSelector_]));
    }
    
    // Color picker for matrix
    if (ImGui::ColorEdit3("Matrix Color", (float*)&matrixColorPicker_)) {
        logEvent("Matrix color changed");
    }
    
    // Text input for text scroll
    if (matrixAnimationSelector_ == 0) {
        ImGui::Text("Text for scrolling:");
        if (ImGui::InputText("##MatrixText", matrixTextBuffer_, sizeof(matrixTextBuffer_))) {
            logEvent("Matrix text changed to: " + std::string(matrixTextBuffer_));
        }
    }
    
    // Bitmap selector for bitmap animation
    if (matrixAnimationSelector_ == 1) {
        const char* bitmaps[] = {"Smiley", "Heart", "Arrow"};
        if (ImGui::Combo("Bitmap", &matrixBitmapSelector_, bitmaps, IM_ARRAYSIZE(bitmaps))) {
            logEvent("Matrix bitmap changed to " + std::string(bitmaps[matrixBitmapSelector_]));
        }
    }
    
    // Speed control
    if (ImGui::SliderFloat("Matrix Speed", &matrixScrollSpeed_, 0.1f, 3.0f, "%.2f")) {
        logEvent("Matrix speed changed");
    }
    
    // Start/Stop button
    if (ImGui::Button(matrixAnimationRunning_ ? "Stop Matrix Animation" : "Start Matrix Animation", ImVec2(200, 0))) {
        matrixAnimationRunning_ = !matrixAnimationRunning_;
        logEvent(matrixAnimationRunning_ ? "Matrix animation started" : "Matrix animation stopped");
    }
}

void ConnectorXSimulator::renderControls() {
    // Controls section
    ImGui::Separator();
    
    // Zone selection
    if (ImGui::Combo("Active Zone", &selectedZoneId_, zoneNames_, IM_ARRAYSIZE(zoneNames_))) {
        logEvent("Selected zone: " + std::string(zoneNames_[selectedZoneId_]));
    }
    
    ImGui::Text("Controls for %s", zoneNames_[selectedZoneId_]);
    
    // Animations dropdown for selected zone
    const char* animations[] = { "Rainbow", "Chase", "Breathe", "Text Scroll" };
    if (ImGui::Combo("Animation##zone", &animationSelector_[selectedZoneId_], animations, IM_ARRAYSIZE(animations))) {
        logEvent("Zone " + std::to_string(selectedZoneId_+1) + " animation changed to " + 
                std::string(animations[animationSelector_[selectedZoneId_]]));
    }
    
    // Color picker for selected zone
    if (ImGui::ColorEdit3("Color##zone", (float*)&colorPicker_[selectedZoneId_])) {
        char colorStr[64];
        snprintf(colorStr, sizeof(colorStr), "Zone %d color set to RGB(%.0f, %.0f, %.0f)", 
            selectedZoneId_+1,
            colorPicker_[selectedZoneId_].x * 255, 
            colorPicker_[selectedZoneId_].y * 255, 
            colorPicker_[selectedZoneId_].z * 255);
        logEvent(colorStr);
    }
    
    // Text display (shared across zones)
    if (ImGui::InputText("Text for scroll animation", textBuffer_, IM_ARRAYSIZE(textBuffer_))) {
        logEvent("Text changed to: " + std::string(textBuffer_));
    }
    
    // Speed control for animations for selected zone
    ImGui::SliderFloat("Animation Speed##zone", &scrollSpeed_[selectedZoneId_], 0.1f, 2.0f);
    
    // Start/Stop button for selected zone
    if (ImGui::Button(animationRunning_[selectedZoneId_] ? 
                     "Stop Animation for Zone" : 
                     "Start Animation for Zone")) {
        animationRunning_[selectedZoneId_] = !animationRunning_[selectedZoneId_];
        logEvent("Zone " + std::to_string(selectedZoneId_+1) + 
               (animationRunning_[selectedZoneId_] ? " animation started" : " animation stopped"));
    }
    
    ImGui::SameLine();
    
    // Start/Stop all button
    if (ImGui::Button("Start/Stop All Zones")) {
        bool anyRunning = animationRunning_[0] || animationRunning_[1] || animationRunning_[2];
        
        // Toggle all animations to the opposite of the current majority state
        animationRunning_[0] = animationRunning_[1] = animationRunning_[2] = !anyRunning;
        
        logEvent(anyRunning ? "All animations stopped" : "All animations started");
    }
}

void ConnectorXSimulator::renderEventLog() {
    // Event log section
    ImGui::Separator();
    ImGui::Text("Event Log");
    
    if (ImGui::BeginListBox("##eventlog", ImVec2(-1, 100))) {
        for (const auto& evt : eventLog_) {
            ImGui::TextWrapped("%s", evt.c_str());
        }
        if (!eventLog_.empty()) {
            // Auto-scroll to the latest entry
            ImGui::SetScrollHereY(1.0f);
        }
        ImGui::EndListBox();
    }
}

void ConnectorXSimulator::logEvent(const std::string& event) {
    if (eventLog_.size() < 20) {
        eventLog_.push_back(event);
    } else {
        eventLog_.erase(eventLog_.begin());
        eventLog_.push_back(event);
    }
}

void ConnectorXSimulator::drawCharacter(char c, int startX, int startY, ImColor color) {
    // Simple 5x7 bitmap font for basic characters
    static const bool charMap[128][7][5] = {
        // Simplified character bitmaps for A-Z, 0-9, and some symbols
        ['A'] = {
            {0,1,1,1,0},
            {1,0,0,0,1},
            {1,0,0,0,1},
            {1,1,1,1,1},
            {1,0,0,0,1},
            {1,0,0,0,1},
            {0,0,0,0,0}
        },
        ['M'] = {
            {1,0,0,0,1},
            {1,1,0,1,1},
            {1,0,1,0,1},
            {1,0,0,0,1},
            {1,0,0,0,1},
            {1,0,0,0,1},
            {0,0,0,0,0}
        },
        ['a'] = {
            {0,0,0,0,0},
            {0,1,1,1,0},
            {0,0,0,0,1},
            {0,1,1,1,1},
            {1,0,0,0,1},
            {0,1,1,1,1},
            {0,0,0,0,0}
        },
        ['t'] = {
            {0,0,1,0,0},
            {0,1,1,1,0},
            {0,0,1,0,0},
            {0,0,1,0,0},
            {0,0,1,0,0},
            {0,0,0,1,1},
            {0,0,0,0,0}
        },
        ['r'] = {
            {0,0,0,0,0},
            {1,0,1,1,0},
            {1,1,0,0,1},
            {1,0,0,0,0},
            {1,0,0,0,0},
            {1,0,0,0,0},
            {0,0,0,0,0}
        },
        ['i'] = {
            {0,0,1,0,0},
            {0,0,0,0,0},
            {0,1,1,0,0},
            {0,0,1,0,0},
            {0,0,1,0,0},
            {0,1,1,1,0},
            {0,0,0,0,0}
        },
        ['x'] = {
            {0,0,0,0,0},
            {0,0,0,0,0},
            {1,0,0,0,1},
            {0,1,0,1,0},
            {0,0,1,0,0},
            {0,1,0,1,0},
            {1,0,0,0,1}
        },
        [' '] = {
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0}
        }
    };
    
    if (c < 0 || c >= 128) return;
    
    for (int y = 0; y < 7; y++) {
        for (int x = 0; x < 5; x++) {
            int matrixX = startX + x;
            int matrixY = startY + y;
            
            if (matrixX >= 0 && matrixX < matrixWidth_ && 
                matrixY >= 0 && matrixY < matrixHeight_ && 
                charMap[c][y][x]) {
                matrixColors_[matrixY][matrixX] = color;
            }
        }
    }
}

void ConnectorXSimulator::drawHeart(ImColor color) {
    // Simple heart pattern
    static const bool heartPattern[8][16] = {
        {0,0,0,1,1,0,0,0,0,0,1,1,0,0,0,0},
        {0,0,1,1,1,1,0,0,0,1,1,1,1,0,0,0},
        {0,1,1,1,1,1,1,0,1,1,1,1,1,1,0,0},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0},
        {0,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
        {0,0,1,1,1,1,1,1,1,1,1,1,1,0,0,0},
        {0,0,0,1,1,1,1,1,1,1,1,1,0,0,0,0}
    };
    
    for (int y = 0; y < 8 && y < matrixHeight_; y++) {
        for (int x = 0; x < 16 && x < matrixWidth_; x++) {
            if (heartPattern[y][x]) {
                matrixColors_[y][x] = color;
            }
        }
    }
}

void ConnectorXSimulator::drawArrow(ImColor color) {
    // Simple right arrow pattern
    static const bool arrowPattern[8][16] = {
        {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
        {1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0},
        {0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0},
        {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0}
    };
    
    for (int y = 0; y < 8 && y < matrixHeight_; y++) {
        for (int x = 0; x < 16 && x < matrixWidth_; x++) {
            if (arrowPattern[y][x]) {
                matrixColors_[y][x] = color;
            }
        }
    }
}

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
