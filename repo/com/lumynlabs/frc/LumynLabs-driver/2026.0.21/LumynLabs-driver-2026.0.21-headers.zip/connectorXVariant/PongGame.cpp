#ifdef DESKTOP
#include "PongGame.h"
#include <algorithm>
#include <ctime>
#include <cstdlib>

namespace lumyn::internal::c_ConnectorX {

PongGame::PongGame()
    : showWindow_(false)
    , gameActive_(false)
    , gridWidth_(30)
    , gridHeight_(20)
    , gameTime_(0.0f)
    , updateInterval_(0.03f)
    , lastUpdateTime_(0.0f)
    , playerScore_(0)
    , aiScore_(0)
    , gameOver_(false)
    , winningScore_(5)
    , aiReactionDelay_(0.15f)
    , aiLastReactionTime_(0.0f)
    , aiTargetY_(0.0f)
    , playerPaddle_{(float)gridHeight_ / 2 - 2, 4.0f, 0.3f}
    , aiPaddle_{(float)gridHeight_ / 2 - 2, 4.0f, 0.2f}
    , ball_{(float)gridWidth_ / 2, (float)gridHeight_ / 2, 0.2f, 0.15f, 0.2f}
{
}

void PongGame::update(float deltaTime) {
    if (!showWindow_ || (!gameActive_ && !gameOver_)) {
        return;
    }

    gameTime_ += deltaTime;
    aiLastReactionTime_ += deltaTime;
    
    if (gameActive_ && !gameOver_ && gameTime_ - lastUpdateTime_ >= updateInterval_) {
        updateGameLogic();
    }
}

void PongGame::render() {
    if (!showWindow_) {
        return;
    }

    ImGui::Begin("Lumyn Pong Game", &showWindow_);

    if (!gameActive_ && !gameOver_) {
        initialize();
    }

    ImVec2 pongGameSize(gridWidth_ * GRID_SIZE + 40, gridHeight_ * GRID_SIZE + 120);
    ImGui::BeginChild("PongGameArea", pongGameSize, false);
    
    ImGui::Text("Controls: W/S or Up/Down arrows to move paddle");
    ImGui::Text("Player: %d  |  AI: %d  |  First to %d wins", playerScore_, aiScore_, winningScore_);
    
    if (gameOver_) {
        bool playerWon = playerScore_ >= winningScore_;
        ImGui::TextColored(
            playerWon ? ImVec4(0.3f, 1.0f, 0.3f, 1.0f) : ImVec4(1.0f, 0.3f, 0.3f, 1.0f),
            "%s! Press spacebar to restart",
            playerWon ? "YOU WIN" : "AI WINS");
        if (ImGui::IsKeyPressed(ImGuiKey_Space)) {
            initialize();
        }
        float buttonWidth = ImGui::CalcTextSize("Restart Game").x + 20;
        ImGui::SetCursorPosX((pongGameSize.x - buttonWidth) * 0.5f);
        if (ImGui::Button("Restart Game", ImVec2(buttonWidth, 0))) {
            initialize();
        }
    }
    
    if (!gameOver_) {
        float buttonWidth = ImGui::CalcTextSize("Pause Game").x + 20;
        ImGui::SetCursorPosX((pongGameSize.x - buttonWidth) * 0.5f);
        if (ImGui::Button(gameActive_ ? "Pause Game" : "Resume Game", ImVec2(buttonWidth, 0))) {
            gameActive_ = !gameActive_;
        }
    }
    
    processInput();
    renderGame();
    
    ImGui::EndChild();
    ImGui::End(); // End Pong Game window
}

void PongGame::initialize() {
    playerPaddle_.y = (float)gridHeight_ / 2 - 2;
    aiPaddle_.y = (float)gridHeight_ / 2 - 2;
    ball_.x = (float)gridWidth_ / 2;
    ball_.y = (float)gridHeight_ / 2;
    ball_.dx = (std::rand() % 2 == 0) ? 0.2f : -0.2f;
    ball_.dy = ((std::rand() % 200) - 100) / 500.0f;
    playerScore_ = 0;
    aiScore_ = 0;
    gameOver_ = false;
    gameActive_ = true;
    gameTime_ = 0.0f;
    lastUpdateTime_ = 0.0f;
    aiLastReactionTime_ = 0.0f;
}

void PongGame::processInput() {
    if (!gameOver_ && gameActive_) {
        if ((ImGui::IsKeyDown(ImGuiKey_W) || ImGui::IsKeyDown(ImGuiKey_UpArrow))) {
            playerPaddle_.y -= playerPaddle_.speed;
            if (playerPaddle_.y < 0) playerPaddle_.y = 0;
        }
        if ((ImGui::IsKeyDown(ImGuiKey_S) || ImGui::IsKeyDown(ImGuiKey_DownArrow))) {
            playerPaddle_.y += playerPaddle_.speed;
            if (playerPaddle_.y + playerPaddle_.height > gridHeight_)
                playerPaddle_.y = gridHeight_ - playerPaddle_.height;
        }
    }
}

void PongGame::updateGameLogic() {
    lastUpdateTime_ = gameTime_;
    
    updateAI();
    
    // Update ball position
    ball_.x += ball_.dx;
    ball_.y += ball_.dy;
    
    // Ball collision with top/bottom walls
    if (ball_.y <= 0 || ball_.y >= gridHeight_) {
        ball_.dy = -ball_.dy;
        ball_.y = std::max(0.0f, std::min((float)gridHeight_, ball_.y));
    }
    
    // Ball collision with player paddle
    if (ball_.x <= 1.5f && ball_.dx < 0) {
        if (ball_.y >= playerPaddle_.y && ball_.y <= playerPaddle_.y + playerPaddle_.height) {
            ball_.dx = -ball_.dx;
            float hitPos = (ball_.y - (playerPaddle_.y + playerPaddle_.height / 2)) / (playerPaddle_.height / 2);
            ball_.dy += hitPos * 0.1f;
            ball_.x = 1.5f;
        }
    }
    
    // Ball collision with AI paddle
    if (ball_.x >= gridWidth_ - 1.5f && ball_.dx > 0) {
        if (ball_.y >= aiPaddle_.y && ball_.y <= aiPaddle_.y + aiPaddle_.height) {
            ball_.dx = -ball_.dx;
            float hitPos = (ball_.y - (aiPaddle_.y + aiPaddle_.height / 2)) / (aiPaddle_.height / 2);
            ball_.dy += hitPos * 0.1f;
            ball_.x = gridWidth_ - 1.5f;
        }
    }
    
    // Score events
    if (ball_.x < 0) {
        aiScore_++;
        if (aiScore_ >= winningScore_) {
            gameOver_ = true;
        } else {
            resetBall(false);
        }
    }
    
    if (ball_.x > gridWidth_) {
        playerScore_++;
        if (playerScore_ >= winningScore_) {
            gameOver_ = true;
        } else {
            resetBall(true);
        }
    }
    
    // Limit ball vertical speed
    ball_.dy = std::max(-0.4f, std::min(0.4f, ball_.dy));
}

void PongGame::updateAI() {
    // AI paddle movement with deliberate imperfection to make it beatable
    aiReactionDelay_ = 0.25f; // Slower reaction time
    
    if (aiLastReactionTime_ >= aiReactionDelay_) {
        aiLastReactionTime_ = 0.0f;
        // Add some randomness and error to AI movement
        float ballPrediction = ball_.y + (std::rand() % 3 - 1); // Add -1, 0, or 1 error
        float aiCenterY = aiPaddle_.y + aiPaddle_.height / 2;
        
        // Only move if ball is moving toward AI and there's a significant difference
        if (ball_.dx > 0 && std::abs(aiCenterY - ballPrediction) > 1.0f) {
            if (aiCenterY < ballPrediction - 1.0f) {
                aiPaddle_.y += aiPaddle_.speed * 0.7f; // 70% of full speed
            } else if (aiCenterY > ballPrediction + 1.0f) {
                aiPaddle_.y -= aiPaddle_.speed * 0.7f;
            }
        }
    }
    
    // Keep AI paddle in bounds
    if (aiPaddle_.y < 0) aiPaddle_.y = 0;
    if (aiPaddle_.y + aiPaddle_.height > gridHeight_)
        aiPaddle_.y = gridHeight_ - aiPaddle_.height;
}

void PongGame::renderGame() {
    const ImVec2 pongBoardPos = ImGui::GetCursorScreenPos();
    ImDrawList* pong_draw_list = ImGui::GetWindowDrawList();
    ImVec2 pongBoardSize(gridWidth_ * GRID_SIZE, gridHeight_ * GRID_SIZE);
    
    // Draw board background
    pong_draw_list->AddRectFilled(
        pongBoardPos,
        ImVec2(pongBoardPos.x + pongBoardSize.x, pongBoardPos.y + pongBoardSize.y),
        IM_COL32(10, 10, 30, 255));
    
    // Draw center line
    float centerX = pongBoardPos.x + pongBoardSize.x / 2;
    for (int i = 0; i < gridHeight_; i += 2) {
        pong_draw_list->AddRectFilled(
            ImVec2(centerX - 1, pongBoardPos.y + i * GRID_SIZE),
            ImVec2(centerX + 1, pongBoardPos.y + (i + 1) * GRID_SIZE),
            IM_COL32(100, 100, 100, 255));
    }
    
    // Draw player paddle
    pong_draw_list->AddRectFilled(
        ImVec2(pongBoardPos.x + 5, pongBoardPos.y + playerPaddle_.y * GRID_SIZE),
        ImVec2(pongBoardPos.x + 15, pongBoardPos.y + (playerPaddle_.y + playerPaddle_.height) * GRID_SIZE),
        IM_COL32(0, 150, 255, 255));
    
    // Draw AI paddle
    pong_draw_list->AddRectFilled(
        ImVec2(pongBoardPos.x + pongBoardSize.x - 15, pongBoardPos.y + aiPaddle_.y * GRID_SIZE),
        ImVec2(pongBoardPos.x + pongBoardSize.x - 5, pongBoardPos.y + (aiPaddle_.y + aiPaddle_.height) * GRID_SIZE),
        IM_COL32(255, 100, 100, 255));
    
    // Draw ball
    float ballRadius = GRID_SIZE * 0.3f;
    pong_draw_list->AddCircleFilled(
        ImVec2(pongBoardPos.x + ball_.x * GRID_SIZE, pongBoardPos.y + ball_.y * GRID_SIZE),
        ballRadius,
        IM_COL32(255, 255, 255, 255));
    
    ImGui::Dummy(ImVec2(pongBoardSize.x, pongBoardSize.y));
}

void PongGame::resetBall(bool playerScored) {
    ball_.x = (float)gridWidth_ / 2;
    ball_.y = (float)gridHeight_ / 2;
    ball_.dx = playerScored ? -0.2f : 0.2f;
    ball_.dy = ((std::rand() % 200) - 100) / 500.0f;
}

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
