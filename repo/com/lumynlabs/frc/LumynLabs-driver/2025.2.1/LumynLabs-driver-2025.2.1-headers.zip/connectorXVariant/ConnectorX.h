#pragma once

#include "./BaseConnectorXVariant.h"
#include "modules/ModulesManager.h"
#include "led/LEDCommander.h"
#include "led/MatrixCommander.h"
#include "util/CircularBuffer.h"

namespace lumyn::internal
{
  class ConnectorX : public BaseConnectorXVariant
  {
  public:
    ConnectorX() : BaseConnectorXVariant()
    {
      _leds = std::make_unique<LEDCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
      _matrix = std::make_unique<MatrixCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
      _events = std::make_unique<CircularBuffer<Eventing::Event>>(100);
    }

    // TODO: Add the variant definition

    std::vector<lumyn::internal::Eventing::Event> GetEvents(void)
    {
      std::vector<lumyn::internal::Eventing::Event> ret;
      ret.reserve(_events->size());

      while (_events->size())
      {
        ret.push_back(_events->front());
        _events->pop();
      }

      return ret;
    }

    ModulesManager &modules()
    {
      return _modules;
    }

    LEDCommander &leds()
    {
      return *_leds;
    }

    MatrixCommander &matrix()
    {
      return *_matrix;
    }

  protected:
    void HandleNewModuleData(ModuleData::ModuleData &data) override;
    void HandleEvent(const Eventing::Event &) override;

  private:
    void SendLEDCommand(Command::LED::LEDCommand &ledCmd)
    {
      Command::Command cmd = {
          .type = Command::APIGroupType::LED,
          .led = ledCmd};
      _portListener->SendCommand(cmd);
    }

    ModulesManager _modules;
    std::unique_ptr<LEDCommander> _leds;
    std::unique_ptr<MatrixCommander> _matrix;
    std::unique_ptr<CircularBuffer<Eventing::Event>> _events;
  };
}