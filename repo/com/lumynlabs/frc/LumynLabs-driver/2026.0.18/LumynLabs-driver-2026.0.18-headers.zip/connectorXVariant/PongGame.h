#pragma once

#ifdef DESKTOP
#include <imgui.h>

namespace lumyn::internal::c_ConnectorX {

class PongGame {
public:
    struct PongPaddle { 
        float y; 
        float height = 4.0f; 
        float speed = 0.3f; 
    };
    
    struct PongBall { 
        float x, y; 
        float dx, dy; 
        float speed = 0.2f; 
    };

    PongGame();
    ~PongGame() = default;

    void update(float deltaTime);
    void render();
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    // Game state variables
    bool showWindow_;
    bool gameActive_;
    int gridWidth_;
    int gridHeight_;
    float gameTime_;
    float updateInterval_;
    float lastUpdateTime_;
    int playerScore_;
    int aiScore_;
    bool gameOver_;
    int winningScore_;
    
    // AI variables
    float aiReactionDelay_;
    float aiLastReactionTime_;
    float aiTargetY_;
    
    // Game objects
    PongPaddle playerPaddle_;
    PongPaddle aiPaddle_;
    PongBall ball_;

    // Constants
    static constexpr float GRID_SIZE = 15.0f;

    // Helper methods
    void initialize();
    void processInput();
    void updateGameLogic();
    void updateAI();
    void renderGame();
    void resetBall(bool playerScored);
};

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
