#pragma once

#ifdef DESKTOP
#include <imgui.h>
#include <vector>
#include <string>

namespace lumyn::internal::c_ConnectorX {

class ConnectorXSimulator {
public:
    ConnectorXSimulator();
    ~ConnectorXSimulator() = default;

    void update(float deltaTime);
    void render();

private:
    // LED simulation variables
    std::vector<ImColor> ledColors_;
    int ledCount_;
    char textBuffer_[128];
    float scrollSpeed_[3];
    int animationSelector_[3];
    ImVec4 colorPicker_[3];
    bool animationRunning_[3];
    
    // Animation and control variables
    float connectorAnimTime_;
    int selectedZoneId_;
    const char* zoneNames_[3];
    std::string status_;
    std::vector<std::string> eventLog_;

    // Helper methods
    void initializeLEDs();
    void updateLEDAnimations();
    void renderLEDStrip();
    void renderControls();
    void renderEventLog();
    void logEvent(const std::string& event);
};

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
