#pragma once

#ifdef DESKTOP
#include <imgui.h>

namespace lumyn::internal::c_ConnectorX {

// Forward declarations
class SnakeGame;
class PongGame;

class GameMenu {
public:
    GameMenu();
    ~GameMenu() = default;

    void render(SnakeGame& snakeGame, PongGame& pongGame);
    bool isWindowOpen() const { return showMenu_; }
    void setWindowOpen(bool open) { showMenu_ = open; }

private:
    bool showMenu_;
};

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
