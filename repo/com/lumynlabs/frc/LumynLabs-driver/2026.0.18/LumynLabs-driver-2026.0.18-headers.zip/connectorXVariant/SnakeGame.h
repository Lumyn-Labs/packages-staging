#pragma once

#ifdef DESKTOP
#include <imgui.h>
#include <vector>

namespace lumyn::internal::c_ConnectorX {

class SnakeGame {
public:
    struct SnakeSegment { 
        int x, y; 
    };

    SnakeGame();
    ~SnakeGame() = default;

    void update(float deltaTime);
    void render();
    bool isWindowOpen() const { return showWindow_; }
    void setWindowOpen(bool open) { showWindow_ = open; }

private:
    // Game state variables
    bool showWindow_;
    bool gameActive_;
    int gridWidth_;
    int gridHeight_;
    float gameTime_;
    float updateInterval_;
    float lastUpdateTime_;
    int direction_;
    int nextDirection_;
    int score_;
    bool gameOver_;
    
    // Game objects
    std::vector<SnakeSegment> snakeBody_;
    SnakeSegment food_;

    // Constants
    static constexpr float GRID_SIZE = 20.0f;

    // Helper methods
    void initialize();
    void processInput();
    void updateGameLogic();
    void renderGame();
    void generateFood();
    bool isFoodPosition(int x, int y) const;
};

} // namespace lumyn::internal::c_ConnectorX

#endif // DESKTOP
