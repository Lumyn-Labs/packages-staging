#pragma once

#include "./ConnectorX.h"
// for development only to enable intellisense, remove before building
// #define DESKTOP

#ifdef DESKTOP
#include <imgui.h>
#include "HALSimExt.h"
#include "hal/Extensions.h"
#include <wpi/print.h>
#endif

namespace lumyn::internal::c_ConnectorX
{
  class ConnectorX_int
  {
  public:
    ConnectorX &GetInner()
    {
      if (!_inst)
      {
        _inst = new ConnectorX();
      }

      return *_inst;
    }

    ~ConnectorX_int()
    {
      if (_inst)
      {
        delete _inst;
      }
    }

  private:
    ConnectorX *_inst;
  };

#ifdef __cplusplus
  extern "C"
  {
#endif
    /**
     * MUST BE DELETED
     */
    ConnectorX_int *cx_CreateInstance(void);

    bool cx_Connect(ConnectorX_int *, HAL_SerialPort);
    bool cx_IsConnected(ConnectorX_int *);
    Eventing::Status cx_GetCurrentStatus(ConnectorX_int *);
    bool cx_GetLatestEvent(ConnectorX_int *, Eventing::Event *);

    int cx_GetEvents(ConnectorX_int *inst, lumyn::internal::Eventing::Event *arr);

    // If modules are enabled for the variant...
    bool cx_GetLatestData(ConnectorX_int *, const char *, std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> &);

    // If LEDs are enabled for the variant...
    void cx_SetColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetGroupColor(ConnectorX_int *, const char *, Command::LED::AnimationColor);
    void cx_SetAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                         units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetGroupAnimation(ConnectorX_int *, const char *, led::Animation, Command::LED::AnimationColor,
                              units::millisecond_t, bool reversed = false, bool oneShot = false);
    void cx_SetAnimationSequence(ConnectorX_int *, const char *, const char *);
    void cx_SetGroupAnimationSequence(ConnectorX_int *, const char *, const char *);

    void cx_SetBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                      bool setColor = false, bool oneShot = false);
    void cx_SetGroupBitmap(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                           bool setColor = false, bool oneShot = false);
    void cx_SetText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                    Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                    units::millisecond_t delayMs = 500_ms, bool oneShot = false);
    void cx_SetGroupText(ConnectorX_int *, const char *, const char *, Command::LED::AnimationColor,
                         Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);

#ifdef __cplusplus
  }
#endif

#ifdef DESKTOP
  // Chrome Dino game implementation
  namespace DinoGame {
    // Game state
    struct Obstacle {
        float x;
        float width;
        float height;
    };

    struct GameState {
        bool isRunning = true;
        bool isGameOver = false;
        float dinoX = 50.0f;
        float dinoY = 0.0f;
        float dinoWidth = 30.0f;
        float dinoHeight = 50.0f;
        float jumpVelocity = 0.0f;
        float gravity = 30.0f;         // Gravity in units/second² (adjusted for delta time)
        float groundY = 0.0f;
        std::vector<Obstacle> obstacles;
        float obstacleSpeed = 180.0f;  // Speed in units/second (adjusted for delta time)
        float obstacleSpawnRate = 0.004f;    // Significantly reduced spawn rate to make game more playable
        float screenWidth = 600.0f;    // Default screen width for obstacle spawning
        float animationTime = 0.0f;    // Animation time for rendering effects
        int score = 0;
        std::chrono::time_point<std::chrono::steady_clock> lastUpdateTime;
        bool isJumping = false;
    };

    static GameState gameState;

    inline void resetGame() {
        gameState.isRunning = true;
        gameState.isGameOver = false;
        gameState.dinoY = 0.0f;
        gameState.jumpVelocity = 0.0f;
        gameState.obstacles.clear();
        gameState.obstacleSpeed = 180.0f; // Speed in units/second (adjusted for delta time)
        gameState.score = 0;
        gameState.lastUpdateTime = std::chrono::steady_clock::now();
        gameState.isJumping = false;
        gameState.animationTime = 0.0f; // Reset animation time to ensure proper animations
    }

    inline void update() {
        if (gameState.isGameOver) {
            if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Space))) {
                resetGame();
            }
            return;
        }

        auto currentTime = std::chrono::steady_clock::now();
        float deltaTime = std::chrono::duration<float>(currentTime - gameState.lastUpdateTime).count();
        gameState.lastUpdateTime = currentTime;
        
        // Update score
        gameState.score += static_cast<int>(deltaTime * 10);
        
        // Increase game speed over time (already using delta time correctly)
        gameState.obstacleSpeed += deltaTime * 0.6f;
        
        // Handle jumping
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Space)) && gameState.dinoY <= 0.1f) {
            gameState.jumpVelocity = 400.0f;  // Jump velocity in units/second (adjusted for delta time)
            gameState.isJumping = true;
        }
        
        // Apply gravity with proper delta time scaling
        gameState.dinoY += gameState.jumpVelocity * deltaTime;
        gameState.jumpVelocity -= gameState.gravity * deltaTime;
        
        // Ground collision
        if (gameState.dinoY < 0) {
            gameState.dinoY = 0;
            gameState.jumpVelocity = 0;
            gameState.isJumping = false;
        }
        
        // Update obstacles using delta time for consistent movement
        for (auto& obstacle : gameState.obstacles) {
            obstacle.x -= gameState.obstacleSpeed * deltaTime;
        }
        
        // Remove obstacles that have gone off-screen
        gameState.obstacles.erase(
            std::remove_if(gameState.obstacles.begin(), gameState.obstacles.end(),
                [](const Obstacle& o) { return o.x < -50.0f; }),
            gameState.obstacles.end());
        
        // Spawn new obstacles with minimum spacing between them
        static float timeSinceLastObstacle = 0.0f;
        timeSinceLastObstacle += deltaTime;
        
        // Ensure minimum spacing between obstacles (at least 1.5 seconds)
        if (timeSinceLastObstacle > 1.5f && 
            rand() / static_cast<float>(RAND_MAX) < gameState.obstacleSpawnRate * deltaTime * 60) {
            
            float height = 20.0f + (rand() % 50);  // More diverse obstacle heights
            float width = 15.0f + (rand() % 15);   // Slightly wider obstacles
            
            // Spawn at the right edge of the screen
            Obstacle newObstacle;
            newObstacle.x = gameState.screenWidth;
            newObstacle.width = width;
            newObstacle.height = height;
            gameState.obstacles.push_back(newObstacle);
            
            // Reset timer
            timeSinceLastObstacle = 0.0f;
        }
        
        // Update animation time
        gameState.animationTime += deltaTime;
        
        // Collision detection
        for (const auto& obstacle : gameState.obstacles) {
            bool xCollision = (gameState.dinoX + gameState.dinoWidth > obstacle.x) && 
                              (gameState.dinoX < obstacle.x + obstacle.width);
            
            bool yCollision = (gameState.dinoY < obstacle.height);
            
            if (xCollision && yCollision) {
                gameState.isGameOver = true;
                break;
            }
        }
    }

    inline void render() {
        // Set initial window size and position for better gameplay
        ImGui::SetNextWindowSize(ImVec2(600, 300), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowPos(ImVec2(50, 50), ImGuiCond_FirstUseEver);
        
        ImGui::Begin("Chrome Dino Game Clone");
        
        ImVec2 windowPos = ImGui::GetWindowPos();
        ImVec2 windowSize = ImGui::GetWindowSize();
        ImDrawList* draw_list = ImGui::GetWindowDrawList();
        
        // Update screen width for obstacle spawning
        gameState.screenWidth = windowSize.x;
        
        // Calculate ground level here to have it in scope for all drawing
        float groundLevel = windowPos.y + windowSize.y - 50.0f;
        
        // Draw sky background
        draw_list->AddRectFilled(
            ImVec2(windowPos.x, windowPos.y),
            ImVec2(windowPos.x + windowSize.x, groundLevel),
            IM_COL32(180, 220, 255, 255)
        );
        
        // Draw clouds in background
        static float cloudX[5] = {100.0f, 250.0f, 400.0f, 550.0f, 700.0f}; // Cloud positions
        
        for (int i = 0; i < 5; i++) {
            // Move clouds from right to left using delta time
            cloudX[i] -= gameState.obstacleSpeed * 0.2f * ImGui::GetIO().DeltaTime;
            // If cloud is off-screen, reset it to the right
            if (cloudX[i] < -50.0f) {
                cloudX[i] = windowSize.x + 50.0f;
            }
            
            // Draw a simple cloud shape
            float cloudY = windowPos.y + 30 + (i * 15) % 50;
            float cloudSize = 20.0f + (i * 5);
            
            // Cloud puffs
            draw_list->AddCircleFilled(
                ImVec2(windowPos.x + cloudX[i], cloudY),
                cloudSize,
                IM_COL32(240, 240, 240, 200)
            );
            draw_list->AddCircleFilled(
                ImVec2(windowPos.x + cloudX[i] + cloudSize*0.8f, cloudY - cloudSize*0.2f),
                cloudSize*0.8f,
                IM_COL32(240, 240, 240, 200)
            );
            draw_list->AddCircleFilled(
                ImVec2(windowPos.x + cloudX[i] + cloudSize*0.5f, cloudY + cloudSize*0.3f),
                cloudSize*0.7f,
                IM_COL32(240, 240, 240, 200)
            );
        }
        
        // Draw ground
        draw_list->AddRectFilled(
            ImVec2(windowPos.x, groundLevel),
            ImVec2(windowPos.x + windowSize.x, windowPos.y + windowSize.y),
            IM_COL32(210, 180, 140, 255)
        );
        
        // Draw ground line
        draw_list->AddLine(
            ImVec2(windowPos.x, groundLevel),
            ImVec2(windowPos.x + windowSize.x, groundLevel),
            IM_COL32(120, 100, 80, 255), 
            2.0f
        );
        
        // Draw ground details (small dots)
        for (int i = 0; i < 40; i++) {
            // Using animation time which already accumulates delta time correctly
            float x = (i * 20 - static_cast<int>(gameState.animationTime * 50) % 20);
            if (x < windowSize.x) {
                draw_list->AddCircleFilled(
                    ImVec2(windowPos.x + x, groundLevel + 10 + (i % 3) * 5),
                    1.0f,
                    IM_COL32(130, 100, 60, 255)
                );
            }
        }
        
        // Draw dino (T-Rex style)
        float dinoYPos = groundLevel - gameState.dinoY - gameState.dinoHeight;
        
        // Body - main rectangle
        draw_list->AddRectFilled(
            ImVec2(windowPos.x + gameState.dinoX, dinoYPos + 10),
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth - 5, 
                  groundLevel - gameState.dinoY),
            IM_COL32(50, 150, 50, 255)
        );
        
        // Head
        draw_list->AddRectFilled(
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth - 15, dinoYPos),
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth + 5, 
                  dinoYPos + 20),
            IM_COL32(50, 150, 50, 255)
        );
        
        // Eye
        draw_list->AddCircleFilled(
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth - 5, 
                  dinoYPos + 7),
            2.5f,
            IM_COL32(255, 255, 255, 255)
        );
        
        // Legs - animated based on movement (animationTime already uses delta time)
        float legOffset = (gameState.isJumping) ? 0 : (sin(gameState.animationTime * 10) * 5);
        
        // Front leg
        draw_list->AddRectFilled(
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth - 10, 
                  groundLevel - gameState.dinoY - 15 + legOffset),
            ImVec2(windowPos.x + gameState.dinoX + gameState.dinoWidth - 5, 
                  groundLevel - gameState.dinoY),
            IM_COL32(40, 120, 40, 255)
        );
        
        // Back leg
        draw_list->AddRectFilled(
            ImVec2(windowPos.x + gameState.dinoX + 5, 
                  groundLevel - gameState.dinoY - 15 - legOffset),
            ImVec2(windowPos.x + gameState.dinoX + 10, 
                  groundLevel - gameState.dinoY),
            IM_COL32(40, 120, 40, 255)
        );
        
        // Tail
        draw_list->AddTriangleFilled(
            ImVec2(windowPos.x + gameState.dinoX, dinoYPos + 15),
            ImVec2(windowPos.x + gameState.dinoX - 10, dinoYPos + 25),
            ImVec2(windowPos.x + gameState.dinoX, dinoYPos + 35),
            IM_COL32(50, 150, 50, 255)
        );
        
        // Draw obstacles (cactus style)
        for (const auto& obstacle : gameState.obstacles) {
            // Main stem
            draw_list->AddRectFilled(
                ImVec2(windowPos.x + obstacle.x + obstacle.width/2 - 5, groundLevel - obstacle.height),
                ImVec2(windowPos.x + obstacle.x + obstacle.width/2 + 5, groundLevel),
                IM_COL32(0, 100, 0, 255)
            );
            
            // Arms - if obstacle is tall enough
            if (obstacle.height > 30) {
                // Left arm
                draw_list->AddRectFilled(
                    ImVec2(windowPos.x + obstacle.x, groundLevel - obstacle.height + obstacle.height/3),
                    ImVec2(windowPos.x + obstacle.x + obstacle.width/2 - 2, groundLevel - obstacle.height + obstacle.height/3 + 8),
                    IM_COL32(0, 100, 0, 255)
                );
                
                // Right arm
                draw_list->AddRectFilled(
                    ImVec2(windowPos.x + obstacle.x + obstacle.width/2 + 2, groundLevel - obstacle.height + obstacle.height/2),
                    ImVec2(windowPos.x + obstacle.x + obstacle.width, groundLevel - obstacle.height + obstacle.height/2 + 8),
                    IM_COL32(0, 100, 0, 255)
                );
                
                // Small thorns
                for (int i = 0; i < 5; i++) {
                    float thornHeight = groundLevel - obstacle.height + (i * obstacle.height/5);
                    draw_list->AddLine(
                        ImVec2(windowPos.x + obstacle.x + obstacle.width/2 + 5, thornHeight),
                        ImVec2(windowPos.x + obstacle.x + obstacle.width/2 + 10, thornHeight),
                        IM_COL32(0, 120, 0, 255),
                        1.5f
                    );
                }
            }
        }
        
        // Display score with better styling
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.1f, 0.1f, 0.1f, 1.0f));
        ImGui::SetCursorPos(ImVec2(windowSize.x - 120, 10));
        ImGui::Text("Score: %d", gameState.score);
        
        // Add instructions
        if (!gameState.isGameOver && gameState.score < 100) {
            ImGui::SetCursorPos(ImVec2(10, 10));
            ImGui::Text("Press SPACE to jump!");
        }
        
        // Game over message with improved visibility
        if (gameState.isGameOver) {
            // Semi-transparent background for better text legibility
            ImVec2 textSize = ImGui::CalcTextSize("GAME OVER - Press SPACE to restart");
            float padding = 20.0f;
            
            // Background panel
            draw_list->AddRectFilled(
                ImVec2((windowSize.x - textSize.x) * 0.5f - padding, (windowSize.y - textSize.y) * 0.5f - padding),
                ImVec2((windowSize.x + textSize.x) * 0.5f + padding, (windowSize.y + textSize.y) * 0.5f + 40.0f),
                IM_COL32(0, 0, 0, 180),
                10.0f
            );
            
            // Border around the panel
            draw_list->AddRect(
                ImVec2((windowSize.x - textSize.x) * 0.5f - padding, (windowSize.y - textSize.y) * 0.5f - padding),
                ImVec2((windowSize.x + textSize.x) * 0.5f + padding, (windowSize.y + textSize.y) * 0.5f + 40.0f),
                IM_COL32(255, 255, 255, 100),
                10.0f,
                0,
                2.0f
            );
            
            // Larger "GAME OVER" heading
            ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.2f, 0.2f, 1.0f));
            textSize = ImGui::CalcTextSize("GAME OVER");
            ImGui::SetCursorPos(ImVec2((windowSize.x - textSize.x) * 0.5f, (windowSize.y - textSize.y) * 0.5f - 10.0f));
            ImGui::Text("GAME OVER");
            ImGui::PopStyleColor();
            ImGui::PopFont();
            
            // Instructions text
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
            textSize = ImGui::CalcTextSize("Press SPACE to restart");
            ImGui::SetCursorPos(ImVec2((windowSize.x - textSize.x) * 0.5f, (windowSize.y - textSize.y) * 0.5f + 15.0f));
            ImGui::Text("Press SPACE to restart");
            ImGui::PopStyleColor();
            
            // Show final score with bright color
            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 0.8f, 0.2f, 1.0f)); // Gold color for score
            char scoreText[32];
            snprintf(scoreText, sizeof(scoreText), "Final Score: %d", gameState.score);
            textSize = ImGui::CalcTextSize(scoreText);
            ImGui::SetCursorPos(ImVec2((windowSize.x - textSize.x) * 0.5f, (windowSize.y - textSize.y) * 0.5f + 35.0f));
            ImGui::Text("%s", scoreText);
            ImGui::PopStyleColor();
        }
        ImGui::PopStyleColor(); // Pop the text style
        
        update();
        
        ImGui::End();
    }
  } // namespace DinoGame

  // Desktop-specific implementation
  inline void init_sim() {
    std::cout << "[Lumyn] init_sim hooking simgui" << std::endl;
    
    // Initialize Chrome Dino game
    DinoGame::gameState.lastUpdateTime = std::chrono::steady_clock::now();
    
    // State variables for ConnectorX simulator
    static std::vector<ImColor> ledColors;
    static int ledCount = 60; // 60 LEDs total
    static char textBuffer[128] = "";
    static float scrollSpeed[3] = {0.5f, 0.5f, 0.5f}; // Speed for each zone
    static int animationSelector[3] = {0, 0, 0}; // Animation type for each zone
    static ImVec4 colorPicker[3] = { 
        ImVec4(1.0f, 0.0f, 0.0f, 1.0f), // Red default for zone 1
        ImVec4(0.0f, 1.0f, 0.0f, 1.0f), // Green default for zone 2
        ImVec4(0.0f, 0.0f, 1.0f, 1.0f)  // Blue default for zone 3
    };
    static bool animationRunning[3] = {false, false, false}; // Animation state for each zone
    // ConnectorX simulation variables
    static float connectorAnimTime = 0.0f; // For ConnectorX animation
    static int selectedZoneId = 0;
    static const char* zoneNames[] = {"Zone-1 (LEDs 0-19)", "Zone-2 (LEDs 20-39)", "Zone-3 (LEDs 40-59)"};
    static std::string status = "Connected"; // Default to connected for demo
    static std::vector<std::string> eventLog;
    
    // Initialize LED colors if empty
    if (ledColors.empty()) {
      ledColors.resize(ledCount, ImColor(30, 30, 30, 255)); // Default dark LEDs
    }

    HAL_RegisterExtensionListener(nullptr, [](void*, const char* name, void* data) {
      if (std::string_view{name} == HALSIMGUI_EXT_ADDGUILATEEXECUTE) {
        reinterpret_cast<vendor::AddGuiLateExecuteFn>(data)([] {
          // Render the Chrome Dino Game
          DinoGame::render();
          
          // Render the ConnectorX Simulator
          ImGui::Begin("Lumyn ConnectorX Simulator");
          
          // Status indicator only - no checkbox
          ImGui::Text("Status: %s", status.c_str());
          
          // LED strip visualization
          ImGui::Separator();
          ImGui::Text("LED Strip Visualization");
          
          ImDrawList* draw_list = ImGui::GetWindowDrawList();
          const ImVec2 p = ImGui::GetCursorScreenPos();
          
          // LED strip area
          float stripWidth = 600.0f; // Wider to accommodate more LEDs
          float stripHeight = 40.0f;
          ImVec2 stripMin = ImVec2(p.x + 10, p.y + 10);
          ImVec2 stripMax = ImVec2(p.x + 10 + stripWidth, p.y + 10 + stripHeight);
          
          // Strip background
          draw_list->AddRectFilled(stripMin, stripMax, IM_COL32(20, 20, 20, 255), 3.0f);
          
          // Zone separators
          float zoneWidth = stripWidth / 3;
          for (int z = 1; z < 3; z++) {
            float x = stripMin.x + z * zoneWidth;
            draw_list->AddLine(
                ImVec2(x, stripMin.y), 
                ImVec2(x, stripMax.y),
                IM_COL32(100, 100, 100, 255), 
                1.0f);
          }
          
          // Animate LED strip
          float ledSpacing = stripWidth / ledCount;
          connectorAnimTime += ImGui::GetIO().DeltaTime;
          
          // Update LED colors based on animation for each zone
          for (int i = 0; i < ledCount; i++) {
            float x = stripMin.x + i * ledSpacing + ledSpacing/2;
            float y = stripMin.y + stripHeight/2;
            float radius = ledSpacing/2 - 1;
            
            // Determine which zone this LED belongs to
            int zoneIndex = i / 20; // 20 LEDs per zone
            
            if (animationRunning[zoneIndex]) {
              // Different animation patterns
              switch (animationSelector[zoneIndex]) {
                case 0: // Rainbow
                  {
                    float hue = (float)(i % 20) / 20 + connectorAnimTime * 0.3f;
                    hue = hue - floorf(hue);
                    ImColor color = ImColor::HSV(hue, 1.0f, 1.0f);
                    ledColors[i] = color;
                  }
                  break;
                case 1: // Chase
                  {
                    int zoneStartLed = zoneIndex * 20;
                    int pos = zoneStartLed + (int)(connectorAnimTime * 5) % 20;
                    ledColors[i] = (i == pos) ? ImColor(colorPicker[zoneIndex]) : ImColor(30, 30, 30, 255);
                  }
                  break;
                case 2: // Breathe
                  {
                    float brightness = 0.5f + 0.5f * sinf(connectorAnimTime * 3.0f);
                    ledColors[i] = ImColor(
                        colorPicker[zoneIndex].x * brightness,
                        colorPicker[zoneIndex].y * brightness,
                        colorPicker[zoneIndex].z * brightness,
                        1.0f);
                  }
                  break;
                case 3: // Text scroll
                  {
                    // Simple simulation of text scrolling with blinking
                    int zoneStartLed = zoneIndex * 20;
                    int zonePos = i - zoneStartLed;
                    int scrollPos = (int)(connectorAnimTime * scrollSpeed[zoneIndex] * 5) % 40;
                    bool isVisible = (zonePos >= scrollPos - 3 && zonePos <= scrollPos + 3) % 20;
                    ledColors[i] = isVisible ? ImColor(colorPicker[zoneIndex]) : ImColor(10, 10, 10, 255);
                  }
                  break;
              }
            }
            
            // Draw LED
            draw_list->AddCircleFilled(ImVec2(x, y), radius, ledColors[i]);
            draw_list->AddCircle(ImVec2(x, y), radius, IM_COL32(100, 100, 100, 100));
          }
          
          ImGui::Dummy(ImVec2(stripWidth + 20, stripHeight + 20));
          
          // Controls section
          ImGui::Separator();
          
          // Zone selection
          if (ImGui::Combo("Active Zone", &selectedZoneId, zoneNames, IM_ARRAYSIZE(zoneNames))) {
            // Log zone change
            if (eventLog.size() < 20) {
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Selected zone: " + std::string(zoneNames[selectedZoneId]));
            }
          }
          
          ImGui::Text("Controls for %s", zoneNames[selectedZoneId]);
          
          // Animations dropdown for selected zone
          const char* animations[] = { "Rainbow", "Chase", "Breathe", "Text Scroll" };
          if (ImGui::Combo("Animation##zone", &animationSelector[selectedZoneId], animations, IM_ARRAYSIZE(animations))) {
            // Log the animation change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + " animation changed to " + 
                                std::string(animations[animationSelector[selectedZoneId]]));
            }
          }
          
          // Color picker for selected zone
          if (ImGui::ColorEdit3("Color##zone", (float*)&colorPicker[selectedZoneId])) {
            // Log the color change
            char colorStr[64];
            snprintf(colorStr, sizeof(colorStr), "Zone %d color set to RGB(%.0f, %.0f, %.0f)", 
                selectedZoneId+1,
                colorPicker[selectedZoneId].x * 255, 
                colorPicker[selectedZoneId].y * 255, 
                colorPicker[selectedZoneId].z * 255);
                
            if (eventLog.size() < 20) {
              eventLog.push_back(colorStr);
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(colorStr);
            }
          }
          
          // Text display (shared across zones)
          if (ImGui::InputText("Text for scroll animation", textBuffer, IM_ARRAYSIZE(textBuffer))) {
            // Log text change
            if (eventLog.size() < 20) {
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Text changed to: " + std::string(textBuffer));
            }
          }
          
          // Speed control for animations for selected zone
          ImGui::SliderFloat("Animation Speed##zone", &scrollSpeed[selectedZoneId], 0.1f, 2.0f);
          
          // Start/Stop button for selected zone
          if (ImGui::Button(animationRunning[selectedZoneId] ? 
                           "Stop Animation for Zone" : 
                           "Start Animation for Zone")) {
            animationRunning[selectedZoneId] = !animationRunning[selectedZoneId];
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back("Zone " + std::to_string(selectedZoneId+1) + 
                               (animationRunning[selectedZoneId] ? " animation started" : " animation stopped"));
            }
          }
          
          ImGui::SameLine();
          
          // Start/Stop all button
          if (ImGui::Button("Start/Stop All Zones")) {
            bool anyRunning = animationRunning[0] || animationRunning[1] || animationRunning[2];
            
            // Toggle all animations to the opposite of the current majority state
            animationRunning[0] = animationRunning[1] = animationRunning[2] = !anyRunning;
            
            // Log animation state change
            if (eventLog.size() < 20) {
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            } else {
              eventLog.erase(eventLog.begin());
              eventLog.push_back(anyRunning ? "All animations stopped" : "All animations started");
            }
          }
          
          // Event log section
          ImGui::Separator();
          ImGui::Text("Event Log");
          
          if (ImGui::BeginListBox("##eventlog", ImVec2(-1, 100))) {
            for (const auto& evt : eventLog) {
              ImGui::TextWrapped("%s", evt.c_str());
            }
            if (!eventLog.empty()) {
              // Auto-scroll to the latest entry
              ImGui::SetScrollHereY(1.0f);
            }
            ImGui::EndListBox();
          }
          
          ImGui::End();
        });
      }
    });
  }
#endif
} // namespace lumyn::internal::c_ConnectorX