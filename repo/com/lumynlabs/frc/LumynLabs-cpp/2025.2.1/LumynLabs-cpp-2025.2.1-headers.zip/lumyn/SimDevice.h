
namespace lumyn::device
{

#ifdef IMGUI
#include "imgui.h"
#include "hal/Extensions.h"

int HALSIM_InitExtension(void) {
    std::puts("[Lumyn] Lumyn C++: Initializing extension");
}

#else
void printFailure(void) {
    std::cout << "[Lumyn] Lumyn C++: Failed to load extension" << std::endl;
}
#endif

} // namespace lumyn::device::simdevice