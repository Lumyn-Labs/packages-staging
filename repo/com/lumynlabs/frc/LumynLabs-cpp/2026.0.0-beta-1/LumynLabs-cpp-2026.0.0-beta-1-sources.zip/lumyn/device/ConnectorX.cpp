#include "lumyn/device/ConnectorX.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/configuration/LumynConfigurationParser.h"
#include "lumyn/configuration/LumynConfigurationSerializer.h"
#include "lumyn/device/AnimationBuilder.h"
#include "lumyn/device/ImageSequenceBuilder.h"

#include <chrono>
#include <vector>
#include <fstream>
#include <filesystem>
#include <frc/Filesystem.h>

#include "lumyn/util/logging/ConsoleLogger.h"

using namespace lumyn::internal::c_ConnectorX;

void lumyn::device::ConnectorX::ApplyConfiguration(const lumyn::internal::Configuration::LumynConfiguration& config)
{
  const std::string json = lumyn::config::SerializeConfigToJson(config);
  lumyn::internal::c_ConnectorX::cx_ApplyConfigurationJson(_connectorXInternal, json.c_str(), json.size());
}

std::optional<lumyn::internal::Configuration::LumynConfiguration> lumyn::device::ConnectorX::LoadConfigurationFromDeploy(const std::string& configFileName)
{
  try
  {
    std::filesystem::path deployDir = frc::filesystem::GetDeployDirectory();
    std::filesystem::path configPath = deployDir / configFileName;

    if (!std::filesystem::exists(configPath))
    {
      lumyn::internal::ConsoleLogger::getInstance().logError(
          "ConnectorX", "Config file not found: %s", configPath.string().c_str());
      return std::nullopt;
    }

    std::ifstream file(configPath);
    if (!file.is_open())
    {
      lumyn::internal::ConsoleLogger::getInstance().logError(
          "ConnectorX", "Failed to open config file: %s", configPath.string().c_str());
      return std::nullopt;
    }

    std::string jsonText((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    return lumyn::config::ParseConfig(jsonText);
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorX", "Error loading config from deploy: %s", e.what());
    return std::nullopt;
  }
}

std::optional<lumyn::internal::Configuration::LumynConfiguration> lumyn::device::ConnectorX::RequestConfig()
{
  std::string json;
  if (lumyn::internal::c_ConnectorX::cx_RequestConfig(_connectorXInternal, json))
  {
    auto parsed = nlohmann::json::parse(json);
    return lumyn::config::ParseConfig(parsed);
  }
  return std::nullopt;
}

bool lumyn::device::ConnectorX::GetLatestModuleData(const std::string &moduleID,
                                                    std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out)
{
  return lumyn::internal::c_ConnectorX::cx_GetLatestData(_connectorXInternal, moduleID.c_str(), out);
}

bool lumyn::device::ConnectorX::Connect(lumyn::connection::USBPort port)
{
  try
  {
    const auto deploy = frc::filesystem::GetDeployDirectory();
    lumyn::internal::c_ConnectorX::cx_SetDeployPath(deploy.c_str());
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorX", "Failed to set deploy path: %s", e.what());
  }

#ifdef DESKTOP
  lumyn::internal::ConnectorXSimDevice::GetInstance().SetSku(
      lumyn::internal::ConnectorXSimDevice::SimProductSku::kConnectorX);
#endif
  bool connected = cx_Connect(_connectorXInternal, port);
  if (connected)
  {
    EnsurePollingThread();
  }
  return connected;
}

bool lumyn::device::ConnectorX::Connect(lumyn::connection::UARTPort port, int baud)
{
  try
  {
    const auto deploy = frc::filesystem::GetDeployDirectory();
    lumyn::internal::c_ConnectorX::cx_SetDeployPath(deploy.c_str());
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorX", "Failed to set deploy path: %s", e.what());
  }

#ifdef DESKTOP
  lumyn::internal::ConnectorXSimDevice::GetInstance().SetSku(
      lumyn::internal::ConnectorXSimDevice::SimProductSku::kConnectorX);
#endif
  bool connected = lumyn::internal::c_ConnectorX::cx_ConnectUart(_connectorXInternal, port, baud);
  if (connected)
  {
    EnsurePollingThread();
  }
  return connected;
}

bool lumyn::device::ConnectorX::IsConnected()
{
  return cx_IsConnected(_connectorXInternal);
}

lumyn::internal::Eventing::Status lumyn::device::ConnectorX::GetCurrentStatus()
{
  return cx_GetCurrentStatus(_connectorXInternal);
}

std::optional<lumyn::internal::Eventing::Event> lumyn::device::ConnectorX::GetLatestEvent()
{
  lumyn::internal::Eventing::Event evt;

  if (cx_GetLatestEvent(_connectorXInternal, &evt))
  {
    NotifyEventHandlers(evt);
    return evt;
  }

  return std::nullopt;
}

std::vector<lumyn::internal::Eventing::Event> lumyn::device::ConnectorX::GetEvents()
{
  constexpr int kMaxEvents = 100;
  lumyn::internal::Eventing::Event events[kMaxEvents];
  int ret = cx_GetEvents(_connectorXInternal, events, kMaxEvents);

  std::vector<lumyn::internal::Eventing::Event> eventsVec;
  eventsVec.reserve(ret);

  for (auto i = 0; i < ret; i++)
  {
    eventsVec.push_back(events[i]);
    NotifyEventHandlers(events[i]);
  }

  return eventsVec;
}

void lumyn::device::ConnectorX::RestartDevice(units::millisecond_t delay)
{
  lumyn::internal::c_ConnectorX::cx_RestartDevice(_connectorXInternal, static_cast<uint16_t>(delay.value()));
}

lumyn::device::ConnectorX& lumyn::device::ConnectorX::AddEventHandler(std::function<void(const lumyn::internal::Eventing::Event&)> handler)
{
  if (handler)
  {
    std::lock_guard<std::mutex> lock(_eventHandlersMutex);
    _eventHandlers.emplace_back(std::move(handler));
  }
  return *this;
}

lumyn::device::ConnectorX& lumyn::device::ConnectorX::SetAutoPollEvents(bool enabled)
{
  _autoPollEvents = enabled;
  if (ShouldRunPollingLoop())
  {
    EnsurePollingThread();
  }
  else
  {
    StopPollingThread();
  }
  return *this;
}

void lumyn::device::ConnectorX::PollEvents()
{
  try
  {
    PollEventsOnce();
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorX", "C++: PollEvents encountered an error: %s", e.what());
  }
}

void lumyn::device::ConnectorX::NotifyEventHandlers(const lumyn::internal::Eventing::Event& event)
{
  if (_alertManager)
  {
    _alertManager->handleEvent(event);
  }

  std::vector<std::function<void(const lumyn::internal::Eventing::Event&)>> handlersCopy;
  {
    std::lock_guard<std::mutex> lock(_eventHandlersMutex);
    handlersCopy = _eventHandlers;
  }

  for (auto& handler : handlersCopy)
  {
    if (handler)
    {
      handler(event);
    }
  }
}

void lumyn::device::ConnectorX::RegisterModule(const std::string &moduleID, std::function<void(uint16_t id, const std::vector<uint8_t>& payload)> callback)
{
  std::lock_guard<std::mutex> lock(_callbacksMutex);
  _moduleCallbacks[moduleID] = callback;
  EnsurePollingThread();
}

void lumyn::device::ConnectorX::SetColor(std::string_view zoneID, frc::Color color)
{
  lumyn::internal::c_ConnectorX::cx_SetColor(_connectorXInternal, std::string(zoneID).c_str(), ColorToRGB(color));
}

void lumyn::device::ConnectorX::SetGroupColor(std::string_view groupID, frc::Color color)
{
  lumyn::internal::c_ConnectorX::cx_SetGroupColor(_connectorXInternal, std::string(groupID).c_str(), ColorToRGB(color));
}

void lumyn::device::ConnectorX::SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  lumyn::internal::c_ConnectorX::cx_SetAnimation(_connectorXInternal, std::string(zoneID).c_str(), animation, ColorToRGB(color), delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  lumyn::internal::c_ConnectorX::cx_SetGroupAnimation(_connectorXInternal, std::string(groupID).c_str(), animation, ColorToRGB(color), delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  lumyn::internal::c_ConnectorX::cx_SetAnimationSequence(_connectorXInternal, std::string(zoneID).c_str(), std::string(sequenceID).c_str());
}

void lumyn::device::ConnectorX::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  lumyn::internal::c_ConnectorX::cx_SetGroupAnimationSequence(_connectorXInternal, std::string(groupID).c_str(), std::string(sequenceID).c_str());
}

void lumyn::device::ConnectorX::SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  lumyn::internal::c_ConnectorX::cx_SetBitmap(_connectorXInternal, std::string(zoneID).c_str(), std::string(sequenceID).c_str(), ColorToRGB(color), setColor, oneShot);
}

void lumyn::device::ConnectorX::SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  lumyn::internal::c_ConnectorX::cx_SetGroupBitmap(_connectorXInternal, std::string(groupID).c_str(), std::string(sequenceID).c_str(), ColorToRGB(color), setColor, oneShot);
}

void lumyn::device::ConnectorX::SetText(std::string_view zoneID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction, units::millisecond_t delayMs, bool oneShot) {
  lumyn::internal::c_ConnectorX::cx_SetText(_connectorXInternal, std::string(zoneID).c_str(), std::string(text).c_str(), ColorToRGB(color), direction, delayMs, oneShot);
}

void lumyn::device::ConnectorX::SetGroupText(std::string_view groupID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction, units::millisecond_t delayMs, bool oneShot) {
  lumyn::internal::c_ConnectorX::cx_SetGroupText(_connectorXInternal, std::string(groupID).c_str(), std::string(text).c_str(), ColorToRGB(color), direction, delayMs, oneShot);
}

lumyn::device::AnimationBuilder<lumyn::device::ConnectorX> lumyn::device::ConnectorX::SetAnimation(lumyn::led::Animation animation)
{
  return AnimationBuilder<ConnectorX>(this, animation);
}

lumyn::device::ImageSequenceBuilder<lumyn::device::ConnectorX> lumyn::device::ConnectorX::SetImageSequence(std::string_view sequenceId)
{
  return ImageSequenceBuilder<ConnectorX>(this, sequenceId);
}

lumyn::device::MatrixTextBuilder<lumyn::device::ConnectorX> lumyn::device::ConnectorX::SetText(std::string_view text)
{
  return MatrixTextBuilder<ConnectorX>(this, text);
}

void lumyn::device::ConnectorX::PollingLoop()
{
  try
  {
    while (_pollingRunning)
    {
      PollModulesOnce();
      if (_autoPollEvents)
      {
        PollEventsOnce();
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(22));
    }
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorX", "C++: Polling thread encountered an error: %s", e.what());
  }
}

void lumyn::device::ConnectorX::PollModulesOnce()
{
  std::lock_guard<std::mutex> lock(_callbacksMutex);
  for (const auto &[moduleID, callback] : _moduleCallbacks)
  {
    if (!callback)
      continue;

    std::vector<std::pair<uint16_t, std::vector<uint8_t>>> newData;
    bool gotData = lumyn::internal::c_ConnectorX::cx_GetLatestData(_connectorXInternal, moduleID.c_str(), newData);

    if (gotData && !newData.empty())
    {
      for (const auto &dataInfo : newData)
      {
        callback(dataInfo.first, dataInfo.second);
      }
    }
  }
}

void lumyn::device::ConnectorX::PollEventsOnce()
{
  constexpr int kMaxEvents = 100;
  lumyn::internal::Eventing::Event events[kMaxEvents];
  int eventCount = lumyn::internal::c_ConnectorX::cx_GetEvents(_connectorXInternal, events, kMaxEvents);
  for (int i = 0; i < eventCount; ++i)
  {
    NotifyEventHandlers(events[i]);
  }
}

bool lumyn::device::ConnectorX::ShouldRunPollingLoop()
{
  if (_autoPollEvents)
  {
    return true;
  }
  return HasModuleCallbacks();
}

bool lumyn::device::ConnectorX::HasModuleCallbacks()
{
  std::lock_guard<std::mutex> lock(_callbacksMutex);
  return !_moduleCallbacks.empty();
}

void lumyn::device::ConnectorX::EnsurePollingThread()
{
  if (!IsConnected())
  {
    return;
  }

  if (!ShouldRunPollingLoop())
  {
    return;
  }

  bool expected = false;
  if (_pollingRunning.compare_exchange_strong(expected, true))
  {
    _pollingThread = std::thread([this]() { this->PollingLoop(); });
  }
}

void lumyn::device::ConnectorX::StopPollingThread()
{
  _pollingRunning = false;
  if (_pollingThread.joinable())
  {
    // Wait up to 500ms for thread to finish, then detach if it doesn't
    auto future = std::async(std::launch::async, [this]() {
      if (_pollingThread.joinable()) {
    _pollingThread.join();
      }
    });
    if (future.wait_for(std::chrono::milliseconds(500)) == std::future_status::timeout) {
      _pollingThread.detach();
    } else {
      future.get();
    }
  }
}
