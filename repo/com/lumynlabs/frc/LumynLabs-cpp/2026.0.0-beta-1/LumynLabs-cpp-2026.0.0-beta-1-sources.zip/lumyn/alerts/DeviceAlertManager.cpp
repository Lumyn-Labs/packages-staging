#include "lumyn/alerts/DeviceAlertManager.h"
#include "lumyn/utils/AlertUtils.h"
#include <fmt/format.h>

namespace lumyn::alerts {

DeviceAlertManager::DeviceAlertManager(const std::string& deviceName)
    : DeviceAlertManager(deviceName, kDefaultGroup) {}

DeviceAlertManager::DeviceAlertManager(const std::string& deviceName, const std::string& alertGroup)
    : m_deviceName(deviceName), m_alertGroup(alertGroup) {
  
  m_connectionAlert = std::make_unique<frc::Alert>(
    m_alertGroup,
    fmt::format("{} Connection Lost", m_deviceName),
    frc::Alert::AlertType::kError);
  
  m_deviceErrorAlert = std::make_unique<frc::Alert>(
    m_alertGroup,
    fmt::format("{} Device Error", m_deviceName),
    frc::Alert::AlertType::kWarning);
  
  m_fatalErrorAlert = std::make_unique<frc::Alert>(
    m_alertGroup,
    fmt::format("{} Fatal Error", m_deviceName),
    frc::Alert::AlertType::kError);
    
  m_disabledAlert = std::make_unique<frc::Alert>(
    m_alertGroup,
    fmt::format("{} Device Disabled", m_deviceName),
    frc::Alert::AlertType::kWarning);
}

void DeviceAlertManager::handleEvent(const lumyn::internal::Eventing::Event& event) {
  if (!m_alertsEnabled) return;
  
  switch (event.header.type) {
    case lumyn::internal::Eventing::EventType::Connected:
      m_connectionAlert->Set(false);
      m_disabledAlert->Set(false); // Clear disabled alert when device connects
      break;
      
    case lumyn::internal::Eventing::EventType::Disconnected:
      m_connectionAlert->Set(true);
      m_connectionAlert->SetText(fmt::format("{} has lost connection - check USB connection", m_deviceName));
      break;
      
    case lumyn::internal::Eventing::EventType::Enabled:
      m_disabledAlert->Set(false); // Clear disabled alert when device is enabled
      break;
      
    case lumyn::internal::Eventing::EventType::Disabled:
      m_disabledAlert->Set(true);
      m_disabledAlert->SetText(fmt::format("{} disabled: {}", m_deviceName, lumyn::utils::GetDisabledCauseText(event.header.data.disabled.cause)));
      break;
      
    case lumyn::internal::Eventing::EventType::Error:
      m_deviceErrorAlert->Set(true);
      m_deviceErrorAlert->SetText(fmt::format("{} Error ({}): {}", m_deviceName, lumyn::utils::GetErrorTypeText(event.header.data.error.type), event.header.data.error.message));
      break;
      
    case lumyn::internal::Eventing::EventType::FatalError:
      m_fatalErrorAlert->Set(true);
      m_fatalErrorAlert->SetText(fmt::format("{} Fatal Error ({}): {}", m_deviceName, lumyn::utils::GetFatalErrorTypeText(event.header.data.fatalError.type), event.header.data.fatalError.message));
      break;
      
    case lumyn::internal::Eventing::EventType::HeartBeat:
      m_connectionAlert->Set(false);
      // Clear disabled alert if device is enabled
      if (event.header.data.heartBeat.enabled == 1) {
        m_disabledAlert->Set(false);
      }
      if (event.header.data.heartBeat.status == lumyn::internal::Eventing::Status::Error) {
        m_deviceErrorAlert->Set(true);
        m_deviceErrorAlert->SetText(fmt::format("{} reporting error status", m_deviceName));
      } else {
        m_deviceErrorAlert->Set(false);
      }
      break;
      
    default:
      break;
  }
}

void DeviceAlertManager::setAlertsEnabled(bool enabled) {
  m_alertsEnabled = enabled;
  if (!enabled) {
    m_connectionAlert->Set(false);
    m_deviceErrorAlert->Set(false);
    m_fatalErrorAlert->Set(false);
    m_disabledAlert->Set(false);
  }
}

} // namespace lumyn::alerts