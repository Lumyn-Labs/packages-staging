#include "lumyn/device/ConnectorXAnimate.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/device/AnimationBuilder.h"
#include "lumyn/device/ImageSequenceBuilder.h"
#include "lumyn/configuration/LumynConfigurationParser.h"
#include "lumyn/configuration/LumynConfigurationSerializer.h"

#include <chrono>
#include <thread>
#include <vector>
#include <future>
#include <fstream>
#include <filesystem>
#include <nlohmann/json.hpp>
#include <frc/Filesystem.h>

#include "lumyn/util/logging/ConsoleLogger.h"

using namespace lumyn::internal::c_ConnectorX;

lumyn::device::ConnectorXAnimate::ConnectorXAnimate()
{
  _connectorXInternal = lumyn::internal::c_ConnectorX::cx_CreateInstance();
  _alertManager = std::make_unique<lumyn::alerts::DeviceAlertManager>("ConnectorXAnimate");
}

lumyn::device::ConnectorXAnimate::~ConnectorXAnimate()
{
  StopEventPolling();

  if (_connectorXInternal)
  {
    delete _connectorXInternal;
    _connectorXInternal = nullptr;
  }
}

void lumyn::device::ConnectorXAnimate::ApplyConfiguration(const lumyn::internal::Configuration::LumynConfiguration& config)
{
  const std::string json = lumyn::config::SerializeConfigToJson(config);
  lumyn::internal::c_ConnectorX::cx_ApplyConfigurationJson(_connectorXInternal, json.c_str(), json.size());
}

std::optional<lumyn::internal::Configuration::LumynConfiguration> lumyn::device::ConnectorXAnimate::LoadConfigurationFromDeploy(const std::string& configFileName)
{
  try
  {
    std::filesystem::path deployDir = frc::filesystem::GetDeployDirectory();
    std::filesystem::path configPath = deployDir / configFileName;

    if (!std::filesystem::exists(configPath))
    {
      lumyn::internal::ConsoleLogger::getInstance().logError(
          "ConnectorXAnimate", "Config file not found: %s", configPath.string().c_str());
      return std::nullopt;
    }

    std::ifstream file(configPath);
    if (!file.is_open())
    {
      lumyn::internal::ConsoleLogger::getInstance().logError(
          "ConnectorXAnimate", "Failed to open config file: %s", configPath.string().c_str());
      return std::nullopt;
    }

    std::string jsonText((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    file.close();

    return lumyn::config::ParseConfig(jsonText);
  }
  catch (const std::exception &e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorXAnimate", "Error loading config from deploy: %s", e.what());
    return std::nullopt;
  }
}

std::optional<lumyn::internal::Configuration::LumynConfiguration> lumyn::device::ConnectorXAnimate::RequestConfig()
{
  std::string json;
  if (!lumyn::internal::c_ConnectorX::cx_RequestConfig(_connectorXInternal, json))
  {
    return std::nullopt;
  }

  return lumyn::config::ParseConfig(json);
}

void lumyn::device::ConnectorXAnimate::RestartDevice(units::millisecond_t delay)
{
  lumyn::internal::c_ConnectorX::cx_RestartDevice(_connectorXInternal, static_cast<uint16_t>(delay.value()));
}

bool lumyn::device::ConnectorXAnimate::Connect(lumyn::connection::USBPort port)
{
#ifdef DESKTOP
  lumyn::internal::ConnectorXSimDevice::GetInstance().SetSku(
      lumyn::internal::ConnectorXSimDevice::SimProductSku::kConnectorXAnimate);
#endif
  bool connected = cx_Connect(_connectorXInternal, port);
  if (connected)
  {
    EnsureEventPolling();
  }
  return connected;
}

bool lumyn::device::ConnectorXAnimate::IsConnected()
{
  return cx_IsConnected(_connectorXInternal);
}

lumyn::internal::Eventing::Status lumyn::device::ConnectorXAnimate::GetCurrentStatus()
{
  return cx_GetCurrentStatus(_connectorXInternal);
}

std::optional<lumyn::internal::Eventing::Event> lumyn::device::ConnectorXAnimate::GetLatestEvent()
{
  lumyn::internal::Eventing::Event evt;

  if (cx_GetLatestEvent(_connectorXInternal, &evt))
  {
    NotifyEventHandlers(evt);
    return evt;
  }

  return std::nullopt;
}

std::vector<lumyn::internal::Eventing::Event> lumyn::device::ConnectorXAnimate::GetEvents() {
  constexpr int kMaxEvents = 100;
  lumyn::internal::Eventing::Event events[kMaxEvents];
  int ret = cx_GetEvents(_connectorXInternal, events, kMaxEvents);

  std::vector<lumyn::internal::Eventing::Event> eventsVec;
  eventsVec.reserve(ret);

  for (auto i = 0; i < ret; i++)
  {
    eventsVec.push_back(events[i]);
    NotifyEventHandlers(events[i]);
  }

  return eventsVec;
}

lumyn::device::ConnectorXAnimate& lumyn::device::ConnectorXAnimate::AddEventHandler(std::function<void(const lumyn::internal::Eventing::Event&)> handler)
{
  if (handler)
  {
    {
      std::lock_guard<std::mutex> lock(_eventHandlersMutex);
      _eventHandlers.emplace_back(std::move(handler));
    }
    EnsureEventPolling();
  }
  return *this;
}

lumyn::device::ConnectorXAnimate& lumyn::device::ConnectorXAnimate::SetAutoPollEvents(bool enabled)
{
  _autoPollEvents = enabled;
  if (!enabled)
  {
    StopEventPolling();
  }
  else
  {
    EnsureEventPolling();
  }
  return *this;
}

void lumyn::device::ConnectorXAnimate::PollEvents()
{
  constexpr int kMaxEvents = 100;
  lumyn::internal::Eventing::Event events[kMaxEvents];
  int eventCount = lumyn::internal::c_ConnectorX::cx_GetEvents(_connectorXInternal, events, kMaxEvents);
  for (int i = 0; i < eventCount; ++i)
  {
    NotifyEventHandlers(events[i]);
  }
}

void lumyn::device::ConnectorXAnimate::SetColor(std::string_view zoneID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetColor(_connectorXInternal, zoneID.data(), animationColor);
}

void lumyn::device::ConnectorXAnimate::SetGroupColor(std::string_view groupID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupColor(_connectorXInternal, groupID.data(), animationColor);
}

void lumyn::device::ConnectorXAnimate::SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetAnimation(_connectorXInternal, zoneID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupAnimation(_connectorXInternal, groupID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  cx_SetAnimationSequence(_connectorXInternal, zoneID.data(), sequenceID.data());
}

void lumyn::device::ConnectorXAnimate::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  cx_SetGroupAnimationSequence(_connectorXInternal, groupID.data(), sequenceID.data());
}

void lumyn::device::ConnectorXAnimate::SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, zoneID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupBitmap(_connectorXInternal, groupID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetText(std::string_view zoneID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction, units::millisecond_t delayMs, bool oneShot) {
  auto textColor = ColorToRGB(color);
  cx_SetText(_connectorXInternal, zoneID.data(), text.data(), textColor, direction, delayMs, oneShot);
}

void lumyn::device::ConnectorXAnimate::SetGroupText(std::string_view groupID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction, units::millisecond_t delayMs, bool oneShot) {
  auto textColor = ColorToRGB(color);
  cx_SetGroupText(_connectorXInternal, groupID.data(), text.data(), textColor, direction, delayMs, oneShot);
}

void lumyn::device::ConnectorXAnimate::EnsureEventPolling()
{
  if (!_autoPollEvents || !IsConnected())
  {
    return;
  }

  bool expected = false;
  if (_eventPollingRunning.compare_exchange_strong(expected, true))
  {
    _eventPollingThread = std::thread([this]() { this->EventPollingLoop(); });
  }
}

void lumyn::device::ConnectorXAnimate::StopEventPolling()
{
  bool wasRunning = _eventPollingRunning.exchange(false);
  if (wasRunning && _eventPollingThread.joinable())
  {
    // Wait up to 500ms for thread to finish, then detach if it doesn't
    auto future = std::async(std::launch::async, [this]() {
      if (_eventPollingThread.joinable()) {
    _eventPollingThread.join();
      }
    });
    if (future.wait_for(std::chrono::milliseconds(500)) == std::future_status::timeout) {
      _eventPollingThread.detach();
    } else {
      future.get();
    }
  }
}

void lumyn::device::ConnectorXAnimate::EventPollingLoop()
{
  try
  {
    while (_eventPollingRunning)
    {
      PollEvents();

      std::this_thread::sleep_for(std::chrono::milliseconds(22));
    }
  }
  catch (const std::exception& e)
  {
    lumyn::internal::ConsoleLogger::getInstance().logError(
        "ConnectorXAnimate", "C++: Event polling thread encountered an error: %s", e.what());
  }
}

lumyn::device::AnimationBuilder<lumyn::device::ConnectorXAnimate> lumyn::device::ConnectorXAnimate::SetAnimation(lumyn::led::Animation animation)
{
  return AnimationBuilder<ConnectorXAnimate>(this, animation);
}

lumyn::device::ImageSequenceBuilder<lumyn::device::ConnectorXAnimate> lumyn::device::ConnectorXAnimate::SetImageSequence(std::string_view sequenceId)
{
  return ImageSequenceBuilder<ConnectorXAnimate>(this, sequenceId);
}

lumyn::device::MatrixTextBuilder<lumyn::device::ConnectorXAnimate> lumyn::device::ConnectorXAnimate::SetText(std::string_view text)
{
  return MatrixTextBuilder<ConnectorXAnimate>(this, text);
}

void lumyn::device::ConnectorXAnimate::NotifyEventHandlers(const lumyn::internal::Eventing::Event& event)
{
  if (_alertManager)
  {
    _alertManager->handleEvent(event);
  }

  std::vector<std::function<void(const lumyn::internal::Eventing::Event&)>> handlersCopy;
  {
    std::lock_guard<std::mutex> lock(_eventHandlersMutex);
    handlersCopy = _eventHandlers;
  }

  for (auto& handler : handlersCopy)
  {
    if (handler)
    {
      handler(event);
    }
  }
}
