#pragma once

#include <atomic>
#include <chrono>
#include <cstdint>
#include <functional>
#include <memory>
#include <optional>
#include <thread>
#include <utility>
#include <vector>

#include "lumyn/device/ConnectorX.h"
#ifdef DESKTOP
#include "device/ConnectorXSimDevice.h"
#endif
#include "lumyn/domain/module/ModulePayloadDescriptor.h"

namespace lumyn::modules {

template <typename TPayload>
class ModuleBase {
 public:
  ModuleBase(lumyn::device::ConnectorX& device, const char* moduleId)
      : device_(device), moduleId_(moduleId), running_(false), periodMs_(0) {}

  ~ModuleBase() { stop(); }

  bool start() {
    if (running_.load()) return true;
    running_.store(true);
    loop_ = std::thread([this]() { this->runLoop(); });
    return true;
  }

  bool stop() {
    running_.store(false);
    if (loop_.joinable()) {
      loop_.join();
    }
    return true;
  }

  bool setPeriod(std::chrono::milliseconds period) {
    periodMs_ = period.count() > 0 ? period.count() : 0;
    return true;
  }

  std::optional<std::vector<TPayload>> get() {
    std::vector<std::pair<uint16_t, std::vector<uint8_t>>> entries;
    if (!device_.GetLatestModuleData(moduleId_, entries)) {
      return std::vector<TPayload>{};
    }
    std::vector<TPayload> out;
    out.reserve(entries.size());
    for (auto& e : entries) {
      out.emplace_back(parse(e.first, e.second));
    }
    return out;
  }

  void onUpdate(std::function<void(const TPayload&)> cb) { callback_ = std::move(cb); }

 protected:
  virtual TPayload parse(uint16_t id, const std::vector<uint8_t>& bytes) = 0;

 private:
  void runLoop() {
    auto last = std::chrono::steady_clock::now();
    while (running_.load()) {
      if (periodMs_ > 0) {
        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - last).count() >= periodMs_) {
          last = now; // future: issue explicit request if needed
        }
      }

      std::vector<std::pair<uint16_t, std::vector<uint8_t>>> entries;
      if (device_.GetLatestModuleData(moduleId_, entries) && !entries.empty()) {
        for (auto& e : entries) {
          if (callback_) callback_(parse(e.first, e.second));
        }
      }
      std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
  }

  lumyn::device::ConnectorX& device_;
  const char* moduleId_;
  std::atomic<bool> running_;
  std::thread loop_;
  std::atomic<long> periodMs_;
  std::function<void(const TPayload&)> callback_;
#ifdef DESKTOP
  void RegisterDescriptor(const char* moduleType, std::vector<module::ModuleFieldDescriptor> fields) {
    lumyn::internal::ConnectorXSimDevice::GetInstance().RegisterModuleDescriptor(moduleType, std::move(fields));
  }
#endif
};

} // namespace lumyn::modules

