#pragma once

#include <cstdint>
#include <cstring>

#include "lumyn/modules/ModuleBase.h"
#include "lumyn/domain/module/ModulePayloadDescriptor.h"

namespace lumyn::modules {

struct AnalogInputPayload {
  uint16_t rawValue;
  int32_t scaledValue;
};

class AnalogInputModule : public ModuleBase<AnalogInputPayload> {
 public:
  AnalogInputModule(lumyn::device::ConnectorX& device, const char* moduleId)
      : ModuleBase<AnalogInputPayload>(device, moduleId)
  {
#ifdef DESKTOP
    RegisterDescriptor("AnalogInput", {{"rawValue", module::FieldType::kUInt16},
                                      {"scaledValue", module::FieldType::kInt32}});
#endif
  }

 protected:
  AnalogInputPayload parse(uint16_t /*id*/, const std::vector<uint8_t>& bytes) override {
    AnalogInputPayload payload{};
    if (!bytes.empty()) {
      auto copyLen = bytes.size() <= sizeof(payload) ? bytes.size() : sizeof(payload);
      std::memcpy(&payload, bytes.data(), copyLen);
    }
    return payload;
  }
};

} // namespace lumyn::modules
