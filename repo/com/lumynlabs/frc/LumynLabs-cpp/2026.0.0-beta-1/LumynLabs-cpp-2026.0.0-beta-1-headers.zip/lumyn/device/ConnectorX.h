#pragma once

#include <frc/util/Color8Bit.h>
#include <units/time.h>

#include "lumyn/led/Animation.h"
#include "connectorXVariant/c_ConnectorX.h"
#include "lumyn/connection/USBPort.h"
#include "lumyn/connection/UARTPort.h"
#include "lumyn/alerts/DeviceAlertManager.h"
#include "lumyn/configuration/Configuration.h"
#include "lumyn/configuration/LumynConfigurationParser.h"
#include "device/ConnectorXSimDevice.h"
#include "lumyn/device/AnimationBuilder.h"
#include "lumyn/device/ImageSequenceBuilder.h"
#include "lumyn/device/MatrixTextBuilder.h"

#include <thread>
#include <mutex>
#include <functional>
#include <optional>
#include <string>
#include <vector>
#include <algorithm>
#include <cstring>
#include <future>
#include <chrono>
#include <atomic>
#include <unordered_map>

namespace lumyn
{
  namespace device
  {

    class ConnectorX
    {
    public:
      ConnectorX()
      {
        _connectorXInternal = lumyn::internal::c_ConnectorX::cx_CreateInstance();
        _alertManager = std::make_unique<lumyn::alerts::DeviceAlertManager>("ConnectorX");
      }

      ~ConnectorX()
      {
        StopPollingThread();
        if (_connectorXInternal)
        {
          delete _connectorXInternal;
          _connectorXInternal = nullptr;
        }
      }

      ConnectorX(const ConnectorX &other) = delete;
      ConnectorX(ConnectorX &&other) = delete;
      ConnectorX &operator=(const ConnectorX &other) = delete;
      ConnectorX &operator=(ConnectorX &&other) = delete;

      bool Connect(lumyn::connection::USBPort port);
      bool Connect(lumyn::connection::UARTPort port, int baud = 115200);
      bool IsConnected(void);
      lumyn::internal::Eventing::Status GetCurrentStatus(void);
      std::optional<lumyn::internal::Eventing::Event> GetLatestEvent(void);
      std::vector<lumyn::internal::Eventing::Event> GetEvents(void);

      void RegisterModule(const std::string &moduleID,
                          std::function<void(uint16_t id, const std::vector<uint8_t>& payload)> callback);

      template <typename T>
      T ExtractFromPayload(const std::vector<uint8_t> &payloadBytes)
      {
        T payload{};
        if (!payloadBytes.empty())
        {
          const auto copySize = std::min(sizeof(T), payloadBytes.size());
          std::memcpy(&payload, payloadBytes.data(), copySize);
        }
        return payload;
      }

      void SetColor(std::string_view zoneID, frc::Color color);
      void SetGroupColor(std::string_view groupID, frc::Color color);
      
      /**
       * Set an animation on a zone.
       * 
       * @deprecated Use the builder API instead: SetAnimation(Animation).ForZone(...). This method will be removed in 2027.
       */
      [[deprecated("Use the builder API instead: SetAnimation(Animation).ForZone(...)")]]
      void SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);
      
      /**
       * Set an animation on a group of zones.
       * 
       * @deprecated Use the builder API instead: SetAnimation(Animation).ForGroup(...). This method will be removed in 2027.
       */
      [[deprecated("Use the builder API instead: SetAnimation(Animation).ForGroup(...)")]]
      void SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);
      
      void SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID);
      void SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID);
      void SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);
      void SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor = false, bool oneShot = false);
      
      /**
       * Set text on a matrix zone.
       * 
       * @deprecated Use the builder API instead: SetText(text).ForZone(...). This method will be removed in 2027.
       */
      [[deprecated("Use the builder API instead: SetText(text).ForZone(...)")]]
      void SetText(std::string_view zoneID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT, units::millisecond_t delayMs = 500_ms, bool oneShot = false);
      
      /**
       * Set text on a group of matrix zones.
       * 
       * @deprecated Use the builder API instead: SetText(text).ForGroup(...). This method will be removed in 2027.
       */
      [[deprecated("Use the builder API instead: SetText(text).ForGroup(...)")]]
      void SetGroupText(std::string_view groupID, std::string_view text, frc::Color color, lumyn::internal::Command::LED::MatrixTextScrollDirection direction = lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT, units::millisecond_t delayMs = 500_ms, bool oneShot = false);

      /**
       * Start building an animation command with a fluent API.
       * 
       * Usage:
       * ```cpp
       * m_cx.SetAnimation(Animation::Chase)
       *   .ForZone("front")
       *   .WithColor({255, 0, 0})
       *   .WithDelay(40_ms)
       *   .Reverse(false)
       *   .RunOnce(false);
       * ```
       */
      AnimationBuilder<ConnectorX> SetAnimation(lumyn::led::Animation animation);

      /**
       * Start building an image sequence command with a fluent API.
       * 
       * Usage:
       * ```cpp
       * m_cx.SetImageSequence("Emoji_16x16_unknown")
       *   .ForZone("front-matrix")
       *   .WithColor({120, 0, 100})
       *   .Reverse(false)
       *   .RunOnce(false);
       * ```
       */
      ImageSequenceBuilder<ConnectorX> SetImageSequence(std::string_view sequenceId);

      /**
       * Start building a matrix text command with a fluent API.
       * 
       * Usage:
       * ```cpp
       * m_cx.SetText("HELLO")
       *   .ForZone("front-matrix")
       *   .WithColor({255, 0, 0})
       *   .WithDelay(50_ms)
       *   .WithDirection(MatrixTextScrollDirection::LEFT)
       *   .RunOnce(false);
       * ```
       */
      MatrixTextBuilder<ConnectorX> SetText(std::string_view text);

      // Simulation-facing API: apply a configuration (channels + zones) directly to the sim
      void ApplyConfiguration(const lumyn::internal::Configuration::LumynConfiguration& config);

      /**
       * Load configuration from JSON file in the deploy directory.
       * Looks for deploy/lumyn_config.json by default, or a custom filename.
       * 
       * @param configFileName Optional filename (defaults to "lumyn_config.json")
       * @return The loaded configuration channels, or empty vector if file not found or invalid
       */
      std::optional<lumyn::internal::Configuration::LumynConfiguration> LoadConfigurationFromDeploy(const std::string& configFileName = "lumyn_config.json");

      // Requests
      std::optional<lumyn::internal::Configuration::LumynConfiguration> RequestConfig();

      // System
      void RestartDevice(units::millisecond_t delay = 0_ms);

      ConnectorX& AddEventHandler(std::function<void(const lumyn::internal::Eventing::Event&)> handler);
      // Native forwarders for driver shim
      bool GetLatestModuleData(const std::string &moduleID,
                               std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out);

      /**
       * Enable/disable automatic background polling of events. When disabled, call PollEvents()
       * periodically from your own loop to dispatch handlers on the calling thread. Module polling
       * continues independently as long as callbacks are registered.
       */
      ConnectorX& SetAutoPollEvents(bool enabled);

      /**
       * Poll events once and dispatch handlers on the calling thread. Intended for use when
       * auto polling is disabled.
       */
      void PollEvents();

      void SetAlertsEnabled(bool enabled) {
        if (_alertManager) {
          _alertManager->setAlertsEnabled(enabled);
        }
      }

    private:
      inline lumyn::internal::Command::LED::AnimationColor ColorToRGB(const frc::Color &color)
      {
        return {
            .r = static_cast<uint8_t>(color.red * 255),
            .g = static_cast<uint8_t>(color.green * 255),
            .b = static_cast<uint8_t>(color.blue * 255)};
      }

      void PollingLoop();

      lumyn::internal::c_ConnectorX::ConnectorX_int *_connectorXInternal;
      lumyn::internal::ISerialIO* _serial = nullptr;
      std::unordered_map<std::string, std::function<void(uint16_t, const std::vector<uint8_t>&)>> _moduleCallbacks;
      std::mutex _callbacksMutex;
      std::atomic<bool> _pollingRunning{false};
      std::atomic<bool> _autoPollEvents{true};
      std::thread _pollingThread;

      std::unique_ptr<lumyn::alerts::DeviceAlertManager> _alertManager;
      std::vector<std::function<void(const lumyn::internal::Eventing::Event&)>> _eventHandlers;
      std::mutex _eventHandlersMutex;

      void NotifyEventHandlers(const lumyn::internal::Eventing::Event& event);
      void PollModulesOnce();
      void PollEventsOnce();
      void EnsurePollingThread();
      void StopPollingThread();
      bool ShouldRunPollingLoop();
      bool HasModuleCallbacks();
    };

  } // namespace device
} // namespace lumyn
