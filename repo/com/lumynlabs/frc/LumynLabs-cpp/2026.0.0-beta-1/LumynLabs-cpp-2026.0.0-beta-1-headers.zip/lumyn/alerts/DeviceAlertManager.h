#pragma once

#include <frc/Alert.h>
#include <memory>
#include <string>
#include "lumyn/domain/event/Event.h"

namespace lumyn::alerts {

class DeviceAlertManager {
public:
  /** Default alert group name for Lumyn devices. */
  static constexpr const char* kDefaultGroup = "Lumyn";

  /**
   * Creates a DeviceAlertManager with the default "Lumyn" alert group.
   *
   * @param deviceName The name of the device for alert messages.
   */
  explicit DeviceAlertManager(const std::string& deviceName);
  
  /**
   * Creates a DeviceAlertManager with a custom alert group.
   *
   * @param deviceName The name of the device for alert messages.
   * @param alertGroup The alert group name for categorizing alerts in the dashboard.
   */
  DeviceAlertManager(const std::string& deviceName, const std::string& alertGroup);
  
  ~DeviceAlertManager() = default;
  
  void handleEvent(const lumyn::internal::Eventing::Event& event);
  void setAlertsEnabled(bool enabled);
  
private:
  
  std::string m_deviceName;
  std::string m_alertGroup;
  bool m_alertsEnabled = true;
  
  std::unique_ptr<frc::Alert> m_connectionAlert;
  std::unique_ptr<frc::Alert> m_deviceErrorAlert;
  std::unique_ptr<frc::Alert> m_fatalErrorAlert;
  std::unique_ptr<frc::Alert> m_disabledAlert;
};

} // namespace lumyn::alerts