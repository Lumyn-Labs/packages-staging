#pragma once

#include "lumyn/modules/ModuleBase.h"
#include "lumyn/domain/module/ModulePayloadDescriptor.h"

namespace lumyn::modules {

struct DigitalInputPayload {
  uint8_t state;
};

class DigitalInputModule : public ModuleBase<DigitalInputPayload> {
 public:
  DigitalInputModule(lumyn::device::ConnectorX& device, const char* moduleId)
      : ModuleBase<DigitalInputPayload>(device, moduleId)
  {
#ifdef DESKTOP
    RegisterDescriptor("DigitalInput", {{"state", module::FieldType::kUInt8}});
#endif
  }

 protected:
  DigitalInputPayload parse(uint16_t /*id*/, const std::vector<uint8_t>& bytes) override {
    DigitalInputPayload p{};
    p.state = bytes.empty() ? 0 : bytes[0];
    return p;
  }
};

} // namespace lumyn::modules

