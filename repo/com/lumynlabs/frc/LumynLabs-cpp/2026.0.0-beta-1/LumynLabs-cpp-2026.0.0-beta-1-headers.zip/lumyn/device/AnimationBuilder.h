#pragma once

#include <frc/util/Color8Bit.h>
#include <units/time.h>
#include "lumyn/led/Animation.h"
#include <string_view>
#include <optional>
#include <stdexcept>

namespace lumyn
{
  namespace device
  {
    // Forward declarations
    class ConnectorX;
    class ConnectorXAnimate;

    /**
     * Builder for setting LED animations with a fluent API.
     * 
     * Usage with ConnectorX:
     * ```cpp
     * m_cx.SetAnimation(Animation::Chase)
     *   .ForZone("front")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(40_ms)
     *   .Reverse(false)
     *   .RunOnce(false);
     * ```
     * 
     * Usage with ConnectorXAnimate:
     * ```cpp
     * m_animate.SetAnimation(Animation::Chase)
     *   .ForZone("front")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(40_ms)
     *   .Reverse(false)
     *   .RunOnce(false);
     * ```
     */
    template<typename DeviceType>
    class AnimationBuilder
    {
    public:
      AnimationBuilder(DeviceType* device, lumyn::led::Animation animation)
        : _device(device), _animation(animation)
      {
        _color = defaultColor(animation);
        _delay = defaultDelay(animation);
      }

      /**
       * Set the target zone for this animation.
       */
      AnimationBuilder& ForZone(std::string_view zoneId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _zoneId = zoneId;
        _groupId = std::nullopt;
        return *this;
      }

      /**
       * Set the target group for this animation.
       */
      AnimationBuilder& ForGroup(std::string_view groupId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _groupId = groupId;
        _zoneId = std::nullopt;
        return *this;
      }

      /**
       * Set the color for this animation.
       */
      AnimationBuilder& WithColor(frc::Color color)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _color = color;
        return *this;
      }

      /**
       * Set the delay between animation frames.
       */
      AnimationBuilder& WithDelay(units::millisecond_t delay)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _delay = delay;
        return *this;
      }

      /**
       * Set whether the animation should be reversed.
       */
      AnimationBuilder& Reverse(bool reversed)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _reversed = reversed;
        return *this;
      }

      /**
       * Set whether the animation should run once or loop, and execute the command.
       */
      AnimationBuilder& RunOnce(bool oneShot)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _oneShot = oneShot;
        execute();
        return *this;
      }

      /**
       * Execute the animation command.
       */
      void execute()
      {
        if (_executed) {
          return;
        }

        if (!_zoneId.has_value() && !_groupId.has_value()) {
          throw std::runtime_error("Must call ForZone() or ForGroup() before executing");
        }

        // Suppress deprecation warnings - builders intentionally use deprecated methods internally
        #pragma GCC diagnostic push
        #pragma GCC diagnostic ignored "-Wdeprecated-declarations"
        if (_zoneId.has_value()) {
          _device->SetAnimation(_zoneId.value(), _animation, _color, _delay, _reversed, _oneShot);
        } else {
          _device->SetGroupAnimation(_groupId.value(), _animation, _color, _delay, _reversed, _oneShot);
        }
        #pragma GCC diagnostic pop

        _executed = true;
      }

    private:
      DeviceType* _device;
      lumyn::led::Animation _animation;
      std::optional<std::string_view> _zoneId;
      std::optional<std::string_view> _groupId;
      frc::Color _color{1.0, 1.0, 1.0}; // Initialized in ctor
      units::millisecond_t _delay{50_ms}; // Initialized in ctor
      bool _reversed{false};
      bool _oneShot{false};
      bool _executed{false};

      static frc::Color colorFrom8Bit(int r, int g, int b) {
        return frc::Color(r / 255.0, g / 255.0, b / 255.0);
      }

      static frc::Color defaultColor(lumyn::led::Animation animation) {
        switch (animation) {
          case lumyn::led::Animation::None:
            return colorFrom8Bit(0, 0, 0);
          case lumyn::led::Animation::Comet:
            return colorFrom8Bit(138, 43, 226);
          case lumyn::led::Animation::Sparkle:
            return colorFrom8Bit(255, 255, 255);
          case lumyn::led::Animation::Fire:
            return colorFrom8Bit(255, 35, 0);
          case lumyn::led::Animation::Scanner:
            return colorFrom8Bit(255, 0, 0);
          case lumyn::led::Animation::TheaterChase:
            return colorFrom8Bit(255, 0, 255);
          case lumyn::led::Animation::Twinkle:
            return colorFrom8Bit(255, 255, 0);
          case lumyn::led::Animation::Wave:
            return colorFrom8Bit(0, 100, 255);
          case lumyn::led::Animation::Pulse:
            return colorFrom8Bit(255, 20, 147);
          case lumyn::led::Animation::Ripple:
            return colorFrom8Bit(0, 206, 209);
          case lumyn::led::Animation::Confetti:
            return colorFrom8Bit(255, 215, 0);
          case lumyn::led::Animation::Lava:
            return colorFrom8Bit(255, 80, 0);
          case lumyn::led::Animation::Plasma:
            return colorFrom8Bit(75, 0, 130);
          case lumyn::led::Animation::Heartbeat:
            return colorFrom8Bit(255, 0, 0);
          default:
            return colorFrom8Bit(0, 0, 240); // kDefaultAnimationColor
        }
      }

      static units::millisecond_t defaultDelay(lumyn::led::Animation animation) {
        switch (animation) {
          case lumyn::led::Animation::None:
            return units::millisecond_t{65535};
          case lumyn::led::Animation::Fill:
            return 20000_ms;
          case lumyn::led::Animation::Blink:
            return 1000_ms;
          case lumyn::led::Animation::Breathe:
            return 5_ms;
          case lumyn::led::Animation::RainbowRoll:
            return 10_ms;
          case lumyn::led::Animation::SineRoll:
            return 5_ms;
          case lumyn::led::Animation::Chase:
            return 50_ms;
          case lumyn::led::Animation::FadeIn:
          case lumyn::led::Animation::FadeOut:
            return 5_ms;
          case lumyn::led::Animation::RainbowCycle:
            return 10_ms;
          case lumyn::led::Animation::AlternateBreathe:
            return 10_ms;
          case lumyn::led::Animation::GrowingBreathe:
            return 10_ms;
          case lumyn::led::Animation::Comet:
            return 75_ms;
          case lumyn::led::Animation::Sparkle:
            return 150_ms;
          case lumyn::led::Animation::Fire:
            return 40_ms;
          case lumyn::led::Animation::Scanner:
            return 60_ms;
          case lumyn::led::Animation::TheaterChase:
            return 150_ms;
          case lumyn::led::Animation::Twinkle:
            return 20_ms;
          case lumyn::led::Animation::Meteor:
            return 30_ms;
          case lumyn::led::Animation::Wave:
            return 10_ms;
          case lumyn::led::Animation::Pulse:
            return 8_ms;
          case lumyn::led::Animation::Larson:
            return 20_ms;
          case lumyn::led::Animation::Ripple:
            return 75_ms;
          case lumyn::led::Animation::Confetti:
            return 30_ms;
          case lumyn::led::Animation::Lava:
            return 50_ms;
          case lumyn::led::Animation::Plasma:
            return 20_ms;
          case lumyn::led::Animation::Heartbeat:
            return 30_ms;
          default:
            return 250_ms;
        }
      }
    };
  }
}
