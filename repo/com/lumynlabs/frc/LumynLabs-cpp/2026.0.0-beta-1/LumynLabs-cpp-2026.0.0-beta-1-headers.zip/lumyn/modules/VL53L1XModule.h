#pragma once

#include <cstdint>
#include <vector>

#include "lumyn/modules/ModuleBase.h"
#include "lumyn/domain/module/ModulePayloadDescriptor.h"

namespace lumyn::modules {

struct VL53L1XPayload {
  uint8_t valid;
  uint16_t dist; // millimeters
};

class VL53L1XModule : public ModuleBase<VL53L1XPayload> {
 public:
  VL53L1XModule(lumyn::device::ConnectorX& device, const char* moduleId)
      : ModuleBase<VL53L1XPayload>(device, moduleId)
  {
#ifdef DESKTOP
    RegisterDescriptor("VL53L1X", {{"valid", module::FieldType::kUInt8}, {"dist", module::FieldType::kUInt16}});
#endif
  }

 protected:
  VL53L1XPayload parse(uint16_t /*id*/, const std::vector<uint8_t>& bytes) override {
    VL53L1XPayload p{};
    if (bytes.size() >= 3) {
      p.valid = bytes[0];
      p.dist = static_cast<uint16_t>(bytes[1] | (static_cast<uint16_t>(bytes[2]) << 8)); // little-endian
    } else {
      p.valid = 0;
      p.dist = 0;
    }
    return p;
  }
};

} // namespace lumyn::modules

