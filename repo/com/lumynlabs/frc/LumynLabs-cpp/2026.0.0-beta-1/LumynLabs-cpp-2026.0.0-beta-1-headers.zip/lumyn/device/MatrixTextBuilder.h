#pragma once

#include <frc/util/Color8Bit.h>
#include <units/time.h>
#include "connectorXVariant/c_ConnectorX.h"
#include <string_view>
#include <optional>
#include <stdexcept>

namespace lumyn
{
  namespace device
  {
    // Forward declarations
    class ConnectorX;
    class ConnectorXAnimate;

    /**
     * Builder for setting matrix text with a fluent API.
     * 
     * Usage with ConnectorX:
     * ```cpp
     * m_cx.SetText("HELLO")
     *   .ForZone("front-matrix")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(50_ms)
     *   .WithDirection(MatrixTextScrollDirection::LEFT)
     *   .RunOnce(false);
     * ```
     * 
     * Usage with ConnectorXAnimate:
     * ```cpp
     * m_animate.SetText("HELLO")
     *   .ForZone("front-matrix")
     *   .WithColor({255, 0, 0})
     *   .WithDelay(50_ms)
     *   .WithDirection(MatrixTextScrollDirection::LEFT)
     *   .RunOnce(false);
     * ```
     */
    template<typename DeviceType>
    class MatrixTextBuilder
    {
    public:
      MatrixTextBuilder(DeviceType* device, std::string_view text)
        : _device(device), _text(text)
      {
      }

      /**
       * Set the target zone for this text.
       */
      MatrixTextBuilder& ForZone(std::string_view zoneId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _zoneId = zoneId;
        _groupId = std::nullopt;
        return *this;
      }

      /**
       * Set the target group for this text.
       */
      MatrixTextBuilder& ForGroup(std::string_view groupId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _groupId = groupId;
        _zoneId = std::nullopt;
        return *this;
      }

      /**
       * Set the color for this text.
       */
      MatrixTextBuilder& WithColor(frc::Color color)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _color = color;
        return *this;
      }

      /**
       * Set the delay between scroll steps.
       */
      MatrixTextBuilder& WithDelay(units::millisecond_t delay)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _delay = delay;
        return *this;
      }

      /**
       * Set the scroll direction for this text.
       */
      MatrixTextBuilder& WithDirection(lumyn::internal::Command::LED::MatrixTextScrollDirection direction)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _direction = direction;
        return *this;
      }

      /**
       * Set whether the text should scroll once or loop, and execute the command.
       */
      MatrixTextBuilder& RunOnce(bool oneShot)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _oneShot = oneShot;
        execute();
        return *this;
      }

      /**
       * Execute the text command.
       */
      void execute()
      {
        if (_executed) {
          return;
        }

        if (!_zoneId.has_value() && !_groupId.has_value()) {
          throw std::runtime_error("Must call ForZone() or ForGroup() before executing");
        }

        // Suppress deprecation warnings - builders intentionally use deprecated methods internally
        #pragma GCC diagnostic push
        #pragma GCC diagnostic ignored "-Wdeprecated-declarations"
        if (_zoneId.has_value()) {
          _device->SetText(_zoneId.value(), _text, _color, _direction, _delay, _oneShot);
        } else {
          _device->SetGroupText(_groupId.value(), _text, _color, _direction, _delay, _oneShot);
        }
        #pragma GCC diagnostic pop

        _executed = true;
      }

    private:
      DeviceType* _device;
      std::string_view _text;
      std::optional<std::string_view> _zoneId;
      std::optional<std::string_view> _groupId;
      frc::Color _color{1.0, 1.0, 1.0}; // Default white
      units::millisecond_t _delay{50}; // Default 50ms
      lumyn::internal::Command::LED::MatrixTextScrollDirection _direction{lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT}; // Default left
      bool _oneShot{false};
      bool _executed{false};
    };

  } // namespace device
} // namespace lumyn
