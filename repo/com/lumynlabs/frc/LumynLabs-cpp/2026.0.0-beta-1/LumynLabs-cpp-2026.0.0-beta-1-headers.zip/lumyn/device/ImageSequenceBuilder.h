#pragma once

#include <frc/util/Color8Bit.h>
#include <string_view>
#include <optional>
#include <stdexcept>

namespace lumyn
{
  namespace device
  {
    // Forward declarations
    class ConnectorX;
    class ConnectorXAnimate;

    /**
     * Builder for setting image sequences with a fluent API.
     * 
     * Usage with ConnectorX:
     * ```cpp
     * m_cx.SetImageSequence("Emoji_16x16_unknown")
     *   .ForZone("front-matrix")
     *   .WithColor({120, 0, 100})
     *   .SetColor(true)
     *   .RunOnce(false);
     * ```
     * 
     * Usage with ConnectorXAnimate:
     * ```cpp
     * m_animate.SetImageSequence("Emoji_16x16_unknown")
     *   .ForZone("front-matrix")
     *   .WithColor({120, 0, 100})
     *   .SetColor(true)
     *   .RunOnce(false);
     * ```
     */
    template<typename DeviceType>
    class ImageSequenceBuilder
    {
    public:
      ImageSequenceBuilder(DeviceType* device, std::string_view sequenceId)
        : _device(device), _sequenceId(sequenceId)
      {
      }

      /**
       * Set the target zone for this image sequence.
       */
      ImageSequenceBuilder& ForZone(std::string_view zoneId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _zoneId = zoneId;
        _groupId = std::nullopt;
        return *this;
      }

      /**
       * Set the target group for this image sequence.
       */
      ImageSequenceBuilder& ForGroup(std::string_view groupId)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _groupId = groupId;
        _zoneId = std::nullopt;
        return *this;
      }

      /**
       * Set the color for this image sequence.
       */
      ImageSequenceBuilder& WithColor(frc::Color color)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _color = color;
        return *this;
      }

      /**
       * Set whether the color should be applied to the image sequence.
       */
      ImageSequenceBuilder& SetColor(bool setColor)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _setColor = setColor;
        return *this;
      }

      /**
       * Set whether the image sequence should run once or loop, and execute the command.
       */
      ImageSequenceBuilder& RunOnce(bool oneShot)
      {
        if (_executed) {
          throw std::runtime_error("Builder has already been executed");
        }
        _oneShot = oneShot;
        execute();
        return *this;
      }

      /**
       * Execute the image sequence command.
       */
      void execute()
      {
        if (_executed) {
          return;
        }

        if (!_zoneId.has_value() && !_groupId.has_value()) {
          throw std::runtime_error("Must call ForZone() or ForGroup() before executing");
        }

        if (_zoneId.has_value()) {
          _device->SetImageSequence(_zoneId.value(), _sequenceId, _color, _setColor, _oneShot);
        } else {
          _device->SetGroupImageSequence(_groupId.value(), _sequenceId, _color, _setColor, _oneShot);
        }

        _executed = true;
      }

    private:
      DeviceType* _device;
      std::string_view _sequenceId;
      std::optional<std::string_view> _zoneId;
      std::optional<std::string_view> _groupId;
      frc::Color _color{1.0, 1.0, 1.0}; // Default white
      bool _setColor{true}; // Default to applying color
      bool _oneShot{false};
      bool _executed{false};
    };
  }
}

