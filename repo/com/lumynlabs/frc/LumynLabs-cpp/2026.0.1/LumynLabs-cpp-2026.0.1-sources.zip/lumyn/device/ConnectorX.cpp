#include "lumyn/device/ConnectorX.h"

using namespace lumyn::internal::c_ConnectorX;

void lumyn::device::ConnectorX::Connect(HAL_SerialPort port)
{
  _port = port;
  cx_Connect(_connectorXInternal, port);
}

bool lumyn::device::ConnectorX::IsConnected()
{
  return cx_IsConnected(_connectorXInternal);
}

lumyn::internal::Eventing::Status lumyn::device::ConnectorX::GetCurrentStatus()
{
  return cx_GetCurrentStatus(_connectorXInternal);
}

std::optional<lumyn::internal::Eventing::Event> lumyn::device::ConnectorX::GetLatestEvent()
{
  lumyn::internal::Eventing::Event evt;

  if (cx_GetLatestEvent(_connectorXInternal, &evt))
  {
    return evt;
  }

  return std::nullopt;
}

std::vector<lumyn::internal::Eventing::Event> lumyn::device::ConnectorX::GetEvents()
{
  lumyn::internal::Eventing::Event events[100];
  int ret = cx_GetEvents(_connectorXInternal, events);

  std::vector<lumyn::internal::Eventing::Event> eventsVec;
  eventsVec.reserve(ret);

  for (auto i = 0; i < ret; i++)
  {
    eventsVec.push_back(events[i]);
  }

  return eventsVec;
}

void lumyn::device::ConnectorX::InitSim(void)
{
  std::cout << "[Lumyn] C++: Initializing ConnectorX simulation\n";
  #ifdef IMGUI
  std::cout << "[Lumyn] Imgui is defined, hooking simgui\n";
  init_sim();
  #endif
}

void lumyn::device::ConnectorX::RegisterModule(const std::string &moduleID, std::function<void(const lumyn::internal::ModuleData::NewDataInfo &)> callback)
{
  std::lock_guard<std::mutex> lock(_callbacksMutex);
  // std::cout << "[Lumyn] C++: Registering module " << moduleID << "\n";
  _moduleCallbacks[moduleID] = callback;
}

void lumyn::device::ConnectorX::SetColor(std::string_view zoneID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetColor(_connectorXInternal, zoneID.data(), animationColor);
}

void lumyn::device::ConnectorX::SetGroupColor(std::string_view groupID, frc::Color color)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupColor(_connectorXInternal, groupID.data(), animationColor);
}

void lumyn::device::ConnectorX::SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetAnimation(_connectorXInternal, zoneID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color, units::millisecond_t delay, bool reversed, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetGroupAnimation(_connectorXInternal, groupID.data(), animation, animationColor, delay, reversed, oneShot);
}

void lumyn::device::ConnectorX::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  cx_SetAnimationSequence(_connectorXInternal, zoneID.data(), sequenceID.data());
}

void lumyn::device::ConnectorX::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  cx_SetGroupAnimationSequence(_connectorXInternal, groupID.data(), sequenceID.data());
}

void lumyn::device::ConnectorX::SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, zoneID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorX::SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color, bool setColor, bool oneShot)
{
  auto animationColor = ColorToRGB(color);
  cx_SetBitmap(_connectorXInternal, groupID.data(), sequenceID.data(), animationColor, setColor, oneShot);
}

void lumyn::device::ConnectorX::SetMatrixText(std::string_view zoneID, std::string_view text, frc::Color color,
                                              lumyn::internal::Command::LED::MatrixTextScrollDirection direction,
                                              units::millisecond_t delayMs, bool oneShot)
{
  auto textColor = ColorToRGB(color);
  cx_SetText(_connectorXInternal, zoneID.data(), text.data(), textColor, direction, delayMs, oneShot);
}

void lumyn::device::ConnectorX::SetGroupMatrixText(std::string_view groupID, std::string_view text, frc::Color color,
                                                   lumyn::internal::Command::LED::MatrixTextScrollDirection direction,
                                                   units::millisecond_t delayMs, bool oneShot)
{
  auto textColor = ColorToRGB(color);
  cx_SetGroupText(_connectorXInternal, groupID.data(), text.data(), textColor, direction, delayMs, oneShot);
}

void lumyn::device::ConnectorX::PollingLoop()
{
  try
  {
    while (_pollingRunning)
    {
      // std::cout << "[Lumyn] C++: Polling for data from modules\n";

      std::lock_guard<std::mutex> lock(_callbacksMutex);
      for (const auto &[moduleID, callback] : _moduleCallbacks)
      {
        if (!callback)
          continue;

        // std::cout << "[Lumyn] C++: Polling for data from module " << moduleID << "\n";

        std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> newData;
        bool gotData = lumyn::internal::c_ConnectorX::cx_GetLatestData(_connectorXInternal, moduleID.c_str(), newData);

        if (gotData && newData && !newData->empty())
        {
          // std::cout << "[Lumyn] C++: Found " << newData->size() << " new data entries for module " << moduleID << "\n";
          for (const auto &dataInfo : *newData)
          {
            callback(dataInfo);
          }
        }
      }

      std::this_thread::sleep_for(std::chrono::milliseconds(22));
    }
  }
  catch (const std::exception &e)
  {
    std::cerr << "[Lumyn] C++: Polling thread encountered some error: " << e.what() << std::endl;
  }
}