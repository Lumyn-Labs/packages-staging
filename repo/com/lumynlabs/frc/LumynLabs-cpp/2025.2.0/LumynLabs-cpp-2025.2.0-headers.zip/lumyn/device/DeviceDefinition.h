#pragma once

#include <iostream>
#include <vector>
#include <optional>

enum class CommunicationType
{
  USB,
  CAN,
  I2C,
  UART
};

struct BoardInfo
{
  std::string id;
  std::string name;
  std::string version;
  std::string productUrl;
  std::string productImgUrl;
  std::string usbVendorId;
  std::string usbProductId;
  std::string usbDebugProductId; // This might need clarification
  int regulatorOutputMa;
  std::vector<CommunicationType> supportedCommunication;
};

struct LEDConfiguration
{
  int ledPowerDrawMa;
  int channelCount;
};

struct DeviceConfiguration
{
  int maxDeviceCount;
  bool i2cEnabled;
  bool spiEnabled;
  bool uartEnabled;
};

struct DIOConfiguration
{
  std::string name;
};

struct AIOConfiguration
{
  std::string name;
};

struct ScreenConfiguration
{
  std::string i2cAddress;
  int widthPx;
  int heightPx;
};

struct FeatureFlags
{
  bool enableLEDs;
  bool enableDevices;
  bool enableScreen;
  bool enableMic;
  bool enableDIO;
  bool enableAIO;
};

struct DeviceDefinition
{
  BoardInfo info;
  FeatureFlags features;
  std::optional<LEDConfiguration> led;
  std::optional<DeviceConfiguration> devices;
  std::optional<ScreenConfiguration> screen;
  std::vector<DIOConfiguration> dios;
  std::vector<AIOConfiguration> aios;
};

struct AnimationColor
{
  uint8_t r;
  uint8_t g;
  uint8_t b;
};
