#pragma once

#include <hal/SerialPort.h>
#include <frc/util/Color8Bit.h>
#include <units/time.h>

#include "led/Animation.h"
#include "connectorXVariant/c_ConnectorX.h"

#include <iostream>
#include <thread>
#include <mutex>
#include <atomic>
#include <unordered_map>
#include <functional>
#include <chrono>
#include <optional>
#include <string>

namespace lumyn
{
  namespace device
  {

    class ConnectorX
    {
    public:
      ConnectorX()
      {
        _connectorXInternal = lumyn::internal::c_ConnectorX::cx_CreateInstance();
        _pollingRunning = true;
        _pollingThread = std::thread([this]()
                                     { this->PollingLoop(); });
        // std::cout << "[Lumyn] C++: ConnectorX created, starting data polling\n";
        #ifdef IMGUI
        init_sim();
        #endif
      }

      ~ConnectorX()
      {
        _pollingRunning = false;
        if (_pollingThread.joinable())
        {
          _pollingThread.join();
        }
        if (_connectorXInternal)
        {
          delete _connectorXInternal;
          _connectorXInternal = nullptr;
        }
      }

      ConnectorX(const ConnectorX &other) = delete;
      ConnectorX(ConnectorX &&other) = delete;
      ConnectorX &operator=(const ConnectorX &other) = delete;
      ConnectorX &operator=(ConnectorX &&other) = delete;

      void Connect(HAL_SerialPort port);
      bool IsConnected(void);
      lumyn::internal::Eventing::Status GetCurrentStatus(void);
      std::optional<lumyn::internal::Eventing::Event> GetLatestEvent(void);
      std::vector<lumyn::internal::Eventing::Event> GetEvents(void);

      void RegisterModule(const std::string &moduleID,
                          std::function<void(const lumyn::internal::ModuleData::NewDataInfo &)> callback);

      template <typename T>
      T ExtractFromPayload(const lumyn::internal::ModuleData::NewDataInfo &data)
      {
        T payload;
        memcpy(&payload, data.data, data.len);
        return payload;
      }

      template <typename T>
      std::optional<std::vector<T>> GetLatestData(std::string_view moduleID)
      {
        std::optional<std::vector<lumyn::internal::ModuleData::NewDataInfo>> payload = std::nullopt;

        if (lumyn::internal::c_ConnectorX::cx_GetLatestData(_connectorXInternal, moduleID.data(), payload))
        {
          std::vector<T> ret;
          ret.reserve(payload->size());
          for (const auto& data : *payload)
          {
            ret.push_back(ExtractFromPayload<T>(data));
          }

          return ret;
        }

        return std::nullopt;
      }

      void SetColor(std::string_view zoneID, frc::Color color);
      void SetGroupColor(std::string_view groupID, frc::Color color);

      void SetAnimation(std::string_view zoneID, lumyn::led::Animation animation, frc::Color color,
                        units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);
      void SetGroupAnimation(std::string_view groupID, lumyn::led::Animation animation, frc::Color color,
                             units::millisecond_t delay = 250_ms, bool reversed = false, bool oneShot = false);

      void SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID);
      void SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID);

      void SetImageSequence(std::string_view zoneID, std::string_view sequenceID, frc::Color color,
                            bool setColor = false, bool oneShot = false);
      void SetGroupImageSequence(std::string_view groupID, std::string_view sequenceID, frc::Color color,
                                 bool setColor = false, bool oneShot = false);

      void SetMatrixText(std::string_view zoneID, std::string_view text, frc::Color color,
                         lumyn::internal::Command::LED::MatrixTextScrollDirection direction =
                             lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
                         units::millisecond_t delayMs = 500_ms, bool oneShot = false);
      void SetGroupMatrixText(std::string_view groupID, std::string_view text, frc::Color color,
                              lumyn::internal::Command::LED::MatrixTextScrollDirection direction =
                                  lumyn::internal::Command::LED::MatrixTextScrollDirection::LEFT,
                              units::millisecond_t delayMs = 500_ms, bool oneShot = false);

    private:
      inline lumyn::internal::Command::LED::AnimationColor ColorToRGB(const frc::Color &color)
      {
        return {
            .r = static_cast<uint8_t>(color.red * 255),
            .g = static_cast<uint8_t>(color.green * 255),
            .b = static_cast<uint8_t>(color.blue * 255)};
      }

      void PollingLoop();

      lumyn::internal::c_ConnectorX::ConnectorX_int *_connectorXInternal;
      HAL_SerialPort _port;

      std::unordered_map<std::string, std::function<void(const lumyn::internal::ModuleData::NewDataInfo &)>> _moduleCallbacks;
      std::mutex _callbacksMutex;

      bool _pollingRunning = false;
      std::thread _pollingThread;
    };

  } // namespace device
} // namespace lumyn