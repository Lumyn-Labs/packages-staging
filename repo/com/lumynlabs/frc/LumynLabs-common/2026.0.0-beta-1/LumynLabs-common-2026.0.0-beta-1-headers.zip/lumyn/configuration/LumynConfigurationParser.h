#pragma once

#if __has_include(<nlohmann/json.hpp>)
#define LUMYN_HAS_JSON_PARSER 1

#include <nlohmann/json.hpp>
#include <optional>
#include <string>

#include "lumyn/configuration/Configuration.h"

namespace lumyn::config {

std::optional<lumyn::internal::Configuration::LumynConfiguration> ParseConfig(
    const std::string& jsonText);
std::optional<lumyn::internal::Configuration::LumynConfiguration> ParseConfig(
    const nlohmann::json& root);

}  // namespace lumyn::config

#else
#define LUMYN_HAS_JSON_PARSER 0
#endif
