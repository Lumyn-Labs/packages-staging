#pragma once

#include <cstring>
#include <cstdlib>
#include <new>
#include <utility>

#include "lumyn/domain/event/EventType.h"
#include "lumyn/packed.h"
#include "lumyn/util/RefCounted.h"

namespace lumyn::internal::Eventing {

PACK(struct BeginInitInfo{});
PACK(struct FinishInitInfo{});
PACK(struct EnabledInfo{});

enum class DisabledCause : uint8_t { NoHeartbeat, Manual, EStop, Restart };

PACK(struct DisabledInfo { DisabledCause cause; });

enum class ConnectionType : uint8_t {
  USB,
  WebUSB,
  I2C,
  CAN,
  UART,
};

PACK(struct ConnectedInfo { ConnectionType type; });
PACK(struct DisconnectedInfo { ConnectionType type; });

enum class ErrorType : uint8_t {
  FileNotFound = 0,
  InvalidFile,
  EntityNotFound,
  DeviceMalfunction,
  QueueFull,
  LedStrip,
  LedMatrix,
  InvalidAnimationSequence,
  InvalidChannel,
  DuplicateID,
  InvalidConfigUpload,
  ModuleError,
};

PACK(struct ErrorInfo {
  ErrorType type;
  char message[16];
});

enum class FatalErrorType : uint8_t {
  InitError = 0,
  BadConfig,
  StartTask,
  CreateQueue,
};

PACK(struct FatalErrorInfo {
  FatalErrorType type;
  char message[16];
});

PACK(struct ErrorFlags {
  union {
    struct {
  uint16_t nonFatalErrors;
  uint16_t fatalErrors;
    };
    uint32_t errors;
  };

  void raiseError(ErrorType error) {
    nonFatalErrors |= (1 << static_cast<uint32_t>(error));
  }
  void raiseError(FatalErrorType error) {
    fatalErrors |= (1 << static_cast<uint32_t>(error));
  }
  void clearError(ErrorType error) {
    nonFatalErrors &= ~(1 << static_cast<uint16_t>(error));
  }
  void clearError(FatalErrorType error) {
    fatalErrors &= ~(1 << static_cast<uint16_t>(error));
  }
  void clearError(uint32_t bitmask) { errors &= ~bitmask; }
  bool isErrorSet(ErrorType error) const {
    return nonFatalErrors & (1 << static_cast<uint16_t>(error));
  }
  bool isErrorSet(FatalErrorType error) const {
    return fatalErrors & (1 << static_cast<uint16_t>(error));
  }
});

PACK(struct RegisteredEntityInfo { uint16_t id; });

PACK(struct CustomInfo {
  uint8_t type;
  uint8_t data[16];
  uint8_t length;
});

PACK(struct PinInterruptInfo {
  uint8_t pin;
  void* param;
});

PACK(struct HeartBeatInfo {
  Status status;
  uint8_t enabled;
  uint8_t connectedUSB;
  uint8_t canOK;
});

class ExtraMessagePayload : public RefCounted {
 public:
  uint16_t length;
  uint8_t data[];  // Flexible array member

  static ExtraMessagePayload* create(const uint8_t* msgData,
                                     uint16_t msgLength) {
    if (!msgData || msgLength == 0) return nullptr;

    // Allocate payload + data in one block
    void* mem = malloc(sizeof(ExtraMessagePayload) + msgLength);
    if (!mem) return nullptr;

    auto* payload = new (mem) ExtraMessagePayload();
    payload->length = msgLength;
    memcpy(payload->data, msgData, msgLength);

    return payload;
  }

  static ExtraMessagePayload* create(const char* str) {
    if (!str) return nullptr;
    size_t len = strlen(str);
    return create(reinterpret_cast<const uint8_t*>(str),
                  static_cast<uint16_t>(len));
  }

 protected:
  ExtraMessagePayload() : RefCounted(), length(0) {}
  // TODO: Might need to be updated to delete[] data
  ~ExtraMessagePayload() override = default;
};

PACK(union EventData {
  BeginInitInfo beginInit;
  FinishInitInfo finishInit;
  EnabledInfo enabled;
  DisabledInfo disabled;
  ConnectedInfo connected;
  DisconnectedInfo disconnected;
  ErrorInfo error;
  FatalErrorInfo fatalError;
  RegisteredEntityInfo registeredEntity;
  CustomInfo custom;
  PinInterruptInfo pinInterrupt;
  HeartBeatInfo heartBeat;
});

PACK(struct EventHeader {
  EventType type;
  EventData data;
});

struct Event {
  EventHeader header;
  ExtraMessagePayload* extraMsg;

  Event()
      : header({.type = EventType::BeginInitialization}), extraMsg(nullptr) {
    memset(&header.data.beginInit, 0, sizeof(EventData));
  }

  Event(EventHeader hdr) : header(hdr), extraMsg(nullptr) {}

  Event(EventHeader hdr, const char* msg) : header(hdr), extraMsg(nullptr) {
    setExtraMessage(msg);
  }

  Event(const Event& other) : header(other.header), extraMsg(other.extraMsg) {
    if (extraMsg) {
      extraMsg->ref();
    }
  }

  Event(Event&& other) noexcept
      : header(other.header), extraMsg(other.extraMsg) {
    other.extraMsg = nullptr;
  }

  Event& operator=(const Event& other) {
    if (this != &other) {
      if (extraMsg) extraMsg->unref();

      header = other.header;
      extraMsg = other.extraMsg;

      if (extraMsg) extraMsg->ref();
    }
    return *this;
  }

  Event& operator=(Event&& other) noexcept {
    if (this != &other) {
      if (extraMsg) extraMsg->unref();

      header = std::move(other.header);
      extraMsg = other.extraMsg;

      other.extraMsg = nullptr;
    }
    return *this;
  }

  ~Event() {
    if (extraMsg) {
      extraMsg->unref();
    }
  }

  void setExtraMessage(const uint8_t* data, uint16_t length) {
    if (extraMsg) {
      extraMsg->unref();
      extraMsg = nullptr;
    }

    if (data && length > 0) {
      extraMsg = ExtraMessagePayload::create(data, length);
    }
  }

  void setExtraMessage(const char* str) {
    if (extraMsg) {
      extraMsg->unref();
      extraMsg = nullptr;
    }

    if (str) {
      extraMsg = ExtraMessagePayload::create(str);
    }
  }

  const uint8_t* getExtraMessage() const {
    return extraMsg ? extraMsg->data : nullptr;
  }

  uint16_t getExtraMessageLength() const {
    return extraMsg ? extraMsg->length : 0;
  }

  const char* getExtraMessageStr() const {
    return extraMsg ? reinterpret_cast<const char*>(extraMsg->data) : nullptr;
  }

  bool hasExtraMessage() const { return extraMsg != nullptr; }
};

static_assert(sizeof(Event) <= 32, "Event should be compact (~24-28 bytes)");

}  // namespace lumyn::internal::Eventing
