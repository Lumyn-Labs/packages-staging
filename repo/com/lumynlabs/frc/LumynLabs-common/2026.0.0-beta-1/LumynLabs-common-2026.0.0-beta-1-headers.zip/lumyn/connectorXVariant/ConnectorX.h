#pragma once

#include "./BaseConnectorXVariant.h"
#include "../led/LEDCommander.h"
#include "../led/MatrixCommander.h"
#include "../util/CircularBuffer.h"
#include "lumyn/domain/command/system/SystemCommand.h"
#include "lumyn/domain/request/RequestBuilder.h"
#include <lumyn/util/hashing/IDCreator.h>

#include <string_view>
#include <string>

namespace lumyn::internal
{
  class ConnectorX : public BaseConnectorXVariant
  {
  public:
    ConnectorX() : BaseConnectorXVariant()
    {
      _leds = std::make_unique<LEDCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
      _matrix = std::make_unique<MatrixCommander>(std::bind(&ConnectorX::SendLEDCommand, this, std::placeholders::_1));
      _events = std::make_unique<CircularBuffer<Eventing::Event>>(100);
    }

    // TODO: Add the variant definition

    std::vector<lumyn::internal::Eventing::Event> GetEvents(void)
    {
      std::vector<lumyn::internal::Eventing::Event> ret;
      ret.reserve(_events->size());

      while (_events->size())
      {
        ret.push_back(_events->front());
        _events->pop();
      }

      return ret;
    }


    LEDCommander &leds()
    {
      return *_leds;
    }

    MatrixCommander &matrix()
    {
      return *_matrix;
    }

    bool GetLatestModuleData(const char* moduleId, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out)
    {
      if (!moduleId)
      {
        return false;
      }
      return GetLatestModuleData(std::string_view(moduleId), out);
    }

    bool GetLatestModuleData(std::string_view moduleId, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out)
    {
      if (moduleId.empty())
      {
        return false;
      }
      const uint16_t moduleKey = lumyn::internal::IDCreator::createId(moduleId);
      return BaseConnectorXVariant::GetLatestModuleData(moduleKey, out);
    }

    bool RequestConfig(std::string &outConfigJson, int timeoutMs = 5000)
    {
#ifdef DESKTOP
      (void)outConfigJson;
      (void)timeoutMs;
      return false;
#else
      outConfigJson.clear();
      
      Request::Request request{};
      request.header.type = Request::RequestType::ConfigFull;

      auto response = SendRequest(request, timeoutMs);
      if (!response.has_value())
      {
        return false;
      }
      
      if (response->header.type != Request::RequestType::ConfigFull)
      {
        return false;
      }
      
      if (!_portListener)
      {
        return false;
      }
      
      std::vector<uint8_t> configData;
      if (!_portListener->GetConfigFullData(response->header.id, configData))
      {
        return false;
      }
      
      outConfigJson.assign(reinterpret_cast<const char *>(configData.data()), configData.size());
      return true;
#endif
    }

    void RestartDevice(uint16_t delayMs)
    {
      Command::CommandHeader header{};
      header.type = Command::CommandType::System;
      header.systemType = Command::System::SystemCommandType::RestartDevice;
      
      Command::System::SystemCommand cmd{};
      cmd.type = Command::System::SystemCommandType::RestartDevice;
      cmd.data.restartDevice.delayMs = delayMs;
      
      SendCommand(header, &cmd.data.restartDevice, sizeof(cmd.data.restartDevice));
    }

    void ApplyConfigurationPayload(const uint8_t* data, uint32_t length)
    {
      SendConfiguration(data, length);
    }

  protected:
    void OnEvent(const Eventing::Event &) override;

  private:
    void SendLEDCommand(Command::LED::LEDCommand &ledCmd)
    {
      Command::CommandHeader header{};
      header.type = Command::CommandType::LED;
      header.ledType = ledCmd.type;

      ConsoleLogger::getInstance().logVerbose("ConnectorX", "Sending LED Command of type %d", static_cast<uint8_t>(ledCmd.type));
      const void* payload = nullptr;
      size_t payloadLen = 0;

      using Command::LED::LEDCommandType;
      switch (ledCmd.type) {
        case LEDCommandType::SetAnimation:
          payload = &ledCmd.data.setAnimation;
          payloadLen = sizeof(ledCmd.data.setAnimation);
          break;
        case LEDCommandType::SetAnimationGroup:
          payload = &ledCmd.data.setAnimationGroup;
          payloadLen = sizeof(ledCmd.data.setAnimationGroup);
          break;
        case LEDCommandType::SetColor:
          payload = &ledCmd.data.setColor;
          payloadLen = sizeof(ledCmd.data.setColor);
          break;
        case LEDCommandType::SetColorGroup:
          payload = &ledCmd.data.setColorGroup;
          payloadLen = sizeof(ledCmd.data.setColorGroup);
          break;
        case LEDCommandType::SetAnimationSequence:
          payload = &ledCmd.data.setAnimationSequence;
          payloadLen = sizeof(ledCmd.data.setAnimationSequence);
          break;
        case LEDCommandType::SetAnimationSequenceGroup:
          payload = &ledCmd.data.setAnimationSequenceGroup;
          payloadLen = sizeof(ledCmd.data.setAnimationSequenceGroup);
          break;
        case LEDCommandType::SetBitmap:
          payload = &ledCmd.data.setBitmap;
          payloadLen = sizeof(ledCmd.data.setBitmap);
          break;
        case LEDCommandType::SetBitmapGroup:
          payload = &ledCmd.data.setBitmapGroup;
          payloadLen = sizeof(ledCmd.data.setBitmapGroup);
          break;
        case LEDCommandType::SetMatrixText:
          payload = &ledCmd.data.setMatrixText;
          payloadLen = sizeof(ledCmd.data.setMatrixText);
          break;
        case LEDCommandType::SetMatrixTextGroup:
          payload = &ledCmd.data.setMatrixTextGroup;
          payloadLen = sizeof(ledCmd.data.setMatrixTextGroup);
          break;
        case LEDCommandType::SetDirectBuffer:
          payload = &ledCmd.data.setDirectBuffer;
          payloadLen = sizeof(ledCmd.data.setDirectBuffer);
          break;
        default:
          ConsoleLogger::getInstance().logWarning("ConnectorX", "Unknown LED command type");
          return;
      }

      BaseConnectorXVariant::SendCommand(header, payload, payloadLen);
    }

    
    std::unique_ptr<LEDCommander> _leds;
    std::unique_ptr<MatrixCommander> _matrix;
    std::unique_ptr<CircularBuffer<Eventing::Event>> _events;
  };
}
