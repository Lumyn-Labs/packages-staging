#pragma once

#include "IDevice.h"
#include "lumyn/networking/ILumynTransmissionHandler.h"
#include "lumyn/networking/TransmissionPortListener.h"

namespace lumyn::internal
{
  typedef void (*EventCallback_t)(const Eventing::Event *);

  class BaseDevice : public ILumynTransmissionHandler
  {
  public:
    BaseDevice();

    virtual ~BaseDevice();

    bool Connect(ISerialIO* serial);
    void Disconnect(void);
    bool IsConnected(void);
    Eventing::Status GetCurrentStatus(void);
    std::optional<Eventing::Event> GetLatestEvent(void);
    void HandleEvent(const Eventing::Event &) override;
    void HandleTransmission(const TransmissionClass &) override;

  protected:
    bool Initialize(void);
    
    void SendConfiguration(const uint8_t *data, uint32_t length);

    std::optional<Response::ResponseHandshakeInfo> GetLatestHandshake(void);
    std::unique_ptr<TransmissionPortListener> _portListener;

    // Virtual hook for derived classes
    virtual void OnEvent(const Eventing::Event &) = 0;

  private:
    bool Handshake(void);

    std::optional<Response::ResponseHandshakeInfo> _latestHandshake;
    std::optional<Eventing::Event> _latestEvent;
    std::optional<std::pair<Eventing::HeartBeatInfo, int64_t>> _latestHeartbeat;
    std::unique_ptr<ISerialIO> _serialIO;
  };
}
