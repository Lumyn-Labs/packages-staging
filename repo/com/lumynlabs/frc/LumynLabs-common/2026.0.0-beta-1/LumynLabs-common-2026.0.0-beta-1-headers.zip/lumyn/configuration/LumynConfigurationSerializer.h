#pragma once

#if __has_include(<nlohmann/json.hpp>)
#define LUMYN_HAS_JSON_SERIALIZER 1

#include <string>

#include "lumyn/configuration/Configuration.h"

namespace lumyn::config {

std::string SerializeConfigToJson(
    const lumyn::internal::Configuration::LumynConfiguration& config);

}  // namespace lumyn::config

#else
#define LUMYN_HAS_JSON_SERIALIZER 0
#endif
