#pragma once

#include "lumyn/domain/command/led/LEDCommand.h"
#include "lumyn/led/Animation.h"

#include <functional>
#include <chrono>

using namespace std::chrono_literals;

namespace lumyn::internal
{
  class MatrixCommander
  {
  public:
    MatrixCommander(std::function<void(Command::LED::LEDCommand &)> handler) : _cmdHandler{handler} {}

    Command::LED::LEDCommand SetBitmap(std::string_view, std::string_view, Command::LED::AnimationColor,
                                       bool setColor = false, bool oneShot = false);
    Command::LED::LEDCommand SetGroupBitmap(std::string_view, std::string_view, Command::LED::AnimationColor,
                                            bool setColor = false, bool oneShot = false);
    Command::LED::LEDCommand SetText(std::string_view, std::string_view, Command::LED::AnimationColor,
                                     Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                                     std::chrono::milliseconds delayMs = 500ms, bool oneShot = false);
    Command::LED::LEDCommand SetGroupText(std::string_view, std::string_view, Command::LED::AnimationColor,
                                          Command::LED::MatrixTextScrollDirection = Command::LED::MatrixTextScrollDirection::LEFT,
                                          std::chrono::milliseconds delayMs = 500ms, bool oneShot = false);

  private:
    std::function<void(Command::LED::LEDCommand &)> _cmdHandler;
  };
}