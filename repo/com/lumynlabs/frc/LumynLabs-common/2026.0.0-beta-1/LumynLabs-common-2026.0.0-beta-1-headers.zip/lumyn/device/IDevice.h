#pragma once

#include "lumyn/util/serial/ISerialIO.h"
#include "lumyn/domain/response/Response.h"

#include <memory>
#include <optional>

namespace lumyn::internal
{
  class IDevice
  {
  public:
    virtual bool Connect(ISerialIO* serial) = 0;
    virtual bool IsConnected(void) = 0;
    virtual Eventing::Status GetCurrentStatus(void) = 0;
    virtual std::optional<Eventing::Event> GetLatestEvent(void) = 0;

  protected:
    virtual bool Initialize(void) = 0;
    virtual std::optional<Response::ResponseHandshakeInfo> GetLatestHandshake(void) = 0;
  };
}