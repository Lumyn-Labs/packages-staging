#pragma once

#include <cinttypes>
#include <map>
#include <string_view>

namespace lumyn::led
{
  enum class Animation : uint16_t
  {
    None,
    Fill,
    Blink,
    Breathe,
    RainbowRoll,
    SineRoll,
    Chase,
    FadeIn,
    FadeOut,
    RainbowCycle,
    AlternateBreathe,
    GrowingBreathe,
    Comet,
    Sparkle,
    Fire,
    Scanner,
    TheaterChase,
    Twinkle,
    Meteor,
    Wave,
    Pulse,
    Larson,
    Ripple,
    Confetti,
    Lava,
    Plasma,
    Heartbeat
  };

  const std::map<Animation, std::string_view> kAnimationMap =
      {
          {Animation::Fill, "Fill"},
          {Animation::Blink, "Blink"},
          {Animation::Breathe, "Breathe"},
          {Animation::RainbowRoll, "RainbowRoll"},
          {Animation::SineRoll, "SineRoll"},
          {Animation::Chase, "Chase"},
          {Animation::FadeIn, "FadeIn"},
          {Animation::FadeOut, "FadeOut"},
          {Animation::RainbowCycle, "RainbowCycle"},
          {Animation::AlternateBreathe, "AlternateBreathe"},
          {Animation::GrowingBreathe, "GrowingBreathe"},
          {Animation::Comet, "Comet"},
          {Animation::Sparkle, "Sparkle"},
          {Animation::Fire, "Fire"},
          {Animation::Scanner, "Scanner"},
          {Animation::TheaterChase, "TheaterChase"},
          {Animation::Twinkle, "Twinkle"},
          {Animation::Meteor, "Meteor"},
          {Animation::Wave, "Wave"},
          {Animation::Pulse, "Pulse"},
          {Animation::Larson, "Larson"},
          {Animation::Ripple, "Ripple"},
          {Animation::Confetti, "Confetti"},
          {Animation::Lava, "Lava"},
          {Animation::Plasma, "Plasma"},
          {Animation::Heartbeat, "Heartbeat"},
  };
} // namespace lumyn::led
