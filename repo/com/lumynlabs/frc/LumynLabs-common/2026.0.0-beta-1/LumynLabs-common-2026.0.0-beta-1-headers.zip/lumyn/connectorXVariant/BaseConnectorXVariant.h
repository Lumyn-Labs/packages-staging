#pragma once

#include "lumyn/device/BaseDevice.h"
#include "lumyn/connectorXVariant/IConnectorXVariant.h"
#include "lumyn/domain/transmission/Transmission.h"

#include <vector>

namespace lumyn::internal
{
  class BaseConnectorXVariant : public BaseDevice
  {
  public:
    BaseConnectorXVariant();

    virtual ~BaseConnectorXVariant();

  protected:
    virtual void OnEvent(const Eventing::Event &) override = 0;

    std::optional<const Response::Response> SendRequest(Request::Request &request, int timeoutMs = 10000);
    void SendCommand(const Command::CommandHeader &header, const void *payload, size_t payloadLen);

    bool GetLatestModuleData(uint16_t moduleId, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out);
  };
}
