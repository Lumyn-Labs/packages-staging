#pragma once

#include "lumyn/device/IDevice.h"
#include "lumyn/networking/TransmissionPortListener.h"

namespace lumyn::internal
{
  class IConnectorXVariant
  {
  };
}