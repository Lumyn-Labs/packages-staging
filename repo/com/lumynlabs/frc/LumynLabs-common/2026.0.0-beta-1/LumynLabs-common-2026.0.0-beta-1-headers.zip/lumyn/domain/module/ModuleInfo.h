#pragma once

#include <stdint.h>

namespace lumyn::internal::ModuleInfo {

enum class ModuleConnectionType : uint8_t { I2C = 0, SPI, UART, DIO, AIO };

}  // namespace lumyn::internal::ModuleInfo