#include "lumyn/connectorXVariant/BaseConnectorXVariant.h"
#include "lumyn/domain/command/system/SystemCommand.h"

#include <vector>

using namespace lumyn::internal;

BaseConnectorXVariant::BaseConnectorXVariant() : BaseDevice()
{
}

lumyn::internal::BaseConnectorXVariant::~BaseConnectorXVariant() {}

std::optional<const Response::Response> BaseConnectorXVariant::SendRequest(Request::Request &request, int timeoutMs)
{
  return _portListener->SendRequest(request, timeoutMs);
}

void BaseConnectorXVariant::SendCommand(const Command::CommandHeader &header, const void *payload, size_t payloadLen)
{
  _portListener->SendCommand(header, payload, payloadLen);
}

bool BaseConnectorXVariant::GetLatestModuleData(uint16_t moduleId, std::vector<std::pair<uint16_t, std::vector<uint8_t>>> &out)
{
  if (!_portListener)
  {
    return false;
  }

  std::vector<std::vector<uint8_t>> rawBodies;
  if (!_portListener->TryPopModuleDataRaw(moduleId, rawBodies))
  {
    return false;
  }

  out.clear();
  out.reserve(rawBodies.size());
  for (auto &payload : rawBodies)
  {
    out.emplace_back(moduleId, std::move(payload));
  }

  return !out.empty();
}
