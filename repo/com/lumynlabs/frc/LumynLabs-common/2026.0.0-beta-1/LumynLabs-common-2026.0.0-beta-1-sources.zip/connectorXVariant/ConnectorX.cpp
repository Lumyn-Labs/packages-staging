#include "lumyn/connectorXVariant/ConnectorX.h"

using namespace lumyn::internal;

void ConnectorX::OnEvent(const Eventing::Event &event)
{
  _events->push(event);
}
