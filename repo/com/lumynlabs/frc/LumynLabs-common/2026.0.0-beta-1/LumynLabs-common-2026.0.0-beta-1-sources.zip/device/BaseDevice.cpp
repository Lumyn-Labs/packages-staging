#include "lumyn/device/BaseDevice.h"

#include "lumyn/util/timing/CurrentTimestamp.h"
#include "lumyn/version.h"
#include "lumyn/domain/file/FileType.h"
#include "lumyn/domain/request/RequestBuilder.h"

using namespace lumyn::internal;

BaseDevice::BaseDevice()
{
  _portListener = std::make_unique<TransmissionPortListener>(*(dynamic_cast<ILumynTransmissionHandler *>(this)));
}

lumyn::internal::BaseDevice::~BaseDevice() {}

bool BaseDevice::Connect(ISerialIO* serial)
{
  _serialIO.reset(serial);

  _serialIO->setReadCallback([this](const uint8_t* data, size_t length) {
    _portListener->ingressBytes(data, length);
  });

  _portListener->setWriteCallback([this](const uint8_t* data, size_t length) {
    _serialIO->writeBytes(data, length);
  });

  _portListener->Init();

  bool success = Initialize();
  if (!success)
  {
    // Connection failed (handshake failed), clean up
    Disconnect();
  }
  return success;
}

void BaseDevice::Disconnect(void)
{
  // Clear read callback to stop processing incoming data
  if (_serialIO)
  {
    _serialIO->setReadCallback(nullptr);
  }

  // Clear write callback on port listener
  if (_portListener)
  {
    _portListener->setWriteCallback(nullptr);
  }

  // Reset serial IO (will call destructor and close the port)
  _serialIO.reset();

  // Clear state
  _latestHandshake = std::nullopt;
  _latestEvent = std::nullopt;
  _latestHeartbeat = std::nullopt;
}

bool BaseDevice::IsConnected(void)
{
  if (!_latestHeartbeat)
    return false;

  // Read the last received heartbeat timestamp; if within range, it is still connected
  return util::timing::CurrentTimestamp::GetCurrentTimestampMs() - _latestHeartbeat.value().second <= 5000;
}

Eventing::Status BaseDevice::GetCurrentStatus(void)
{
  if (_latestHeartbeat)
  {
    return _latestHeartbeat.value().first.status;
  }

  return Eventing::Status::Unknown;
}

std::optional<Eventing::Event> BaseDevice::GetLatestEvent(void)
{
  if (!_latestEvent)
    return std::nullopt;

  auto evt = _latestEvent.value();
  _latestEvent.reset();
  
  return evt;
}

bool BaseDevice::Initialize(void)
{
  bool success = Handshake();

  if (!success)
  {
    ConsoleLogger::getInstance().logError("BaseDevice", "Received unsuccessful handshake");
    return false;
  }

  return true;
}

void BaseDevice::SendConfiguration(const uint8_t *data, uint32_t length)
{
  if (_portListener)
  {
    _portListener->SendFile(Files::FileType::SendConfig, data, length, nullptr);
  }
}

std::optional<Response::ResponseHandshakeInfo> BaseDevice::GetLatestHandshake(void)
{
  return _latestHandshake;
}

void BaseDevice::HandleEvent(const Eventing::Event &event)
{
  _latestEvent = event;

  if (event.header.type == Eventing::EventType::HeartBeat)
  {
    // If it's a Heartbeat, update the timestamp for use in IsConnected()
    _latestHeartbeat = std::make_pair(event.header.data.heartBeat, util::timing::CurrentTimestamp::GetCurrentTimestampMs());
  }

  OnEvent(event);
}

void BaseDevice::HandleTransmission(const TransmissionClass &transmission)
{
}

bool BaseDevice::Handshake()
{
  Request::Request handshake{};
  handshake.header.type = Request::RequestType::Handshake;
  handshake.data.handshake.hostSource = Request::HostConnectionSource::Roborio;

  auto res = _portListener->SendRequest(handshake, 5000);
  if (!res.has_value())
  {
    ConsoleLogger::getInstance().logError("BaseDevice", "Handshake not received!");
    return false;
  }

  if (res->data.handshake.version.major != DRIVER_VERSION_MAJOR)
  {
    ConsoleLogger::getInstance().logError("BaseDevice", "Device version mismatch! Device version: %d, Driver version: %d",
                                         res->data.handshake.version.major, DRIVER_VERSION_MAJOR);
    return false;
  }

  _latestHandshake = res.value().data.handshake;
  ConsoleLogger::getInstance().logInfo("BaseDevice", "Successfully handshook with device which has ID=%s and version=%d.%d.%d",
                                      _latestHandshake.value().assignedId.id,
                                      _latestHandshake.value().version.major,
                                      _latestHandshake.value().version.minor,
                                      _latestHandshake.value().version.patch);

  Eventing::HeartBeatInfo syntheticHb{};
  syntheticHb.status = _latestHandshake->status.status;
  _latestHeartbeat = std::make_pair(syntheticHb, util::timing::CurrentTimestamp::GetCurrentTimestampMs());

  return true;
}
