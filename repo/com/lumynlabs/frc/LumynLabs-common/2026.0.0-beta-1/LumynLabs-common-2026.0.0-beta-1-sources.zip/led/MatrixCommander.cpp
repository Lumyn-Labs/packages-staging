#include "lumyn/led/MatrixCommander.h"

#include <lumyn/util/hashing/IDCreator.h>

using namespace lumyn::internal;
using namespace Command::LED;

LEDCommand MatrixCommander::SetBitmap(std::string_view zoneID, std::string_view bitmapID, AnimationColor color,
                                      bool setColor, bool oneShot)
{
  auto id = lumyn::internal::IDCreator::createId(zoneID);
  auto bmpId = lumyn::internal::IDCreator::createId(bitmapID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetBitmap,
      .data = {.setBitmap = {
          .zoneId = id,
          .bitmapId = bmpId,
          .color = color,
          .setColor = setColor,
          .oneShot = oneShot}}};

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand MatrixCommander::SetGroupBitmap(std::string_view groupID, std::string_view bitmapID, AnimationColor color,
                                           bool setColor, bool oneShot)
{
  auto id = lumyn::internal::IDCreator::createId(groupID);
  auto bmpId = lumyn::internal::IDCreator::createId(bitmapID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetBitmapGroup,
      .data = {.setBitmapGroup = {
          .groupId = id,
          .bitmapId = bmpId,
          .color = color,
          .setColor = setColor,
          .oneShot = oneShot}}};

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand MatrixCommander::SetText(std::string_view zoneID, std::string_view text, AnimationColor color,
                                    MatrixTextScrollDirection direction,
                                    std::chrono::milliseconds delayMs, bool oneShot)
{
  if (text.size() > sizeof(SetMatrixTextData::text))
  {
    throw "Text is too long";
  }

  auto id = lumyn::internal::IDCreator::createId(zoneID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetMatrixText,
      .data = {.setMatrixText = {
          .zoneId = id,
          .oneShot = oneShot,
          .color = color,
          .dir = direction,
          .text = "",
          .length = static_cast<uint8_t>(text.size()),
          .delay = static_cast<uint16_t>(delayMs.count())}}};

  memcpy(cmd.data.setMatrixText.text, text.data(), text.size());
  _cmdHandler(cmd);

  return cmd;
}

LEDCommand MatrixCommander::SetGroupText(std::string_view groupID, std::string_view text, AnimationColor color,
                                         MatrixTextScrollDirection direction,
                                         std::chrono::milliseconds delayMs, bool oneShot)
{
  if (text.size() > sizeof(SetMatrixTextData::text))
  {
    throw "Text is too long";
  }

  auto id = lumyn::internal::IDCreator::createId(groupID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetMatrixTextGroup,
      .data = {.setMatrixTextGroup = {
          .groupId = id,
          .oneShot = oneShot,
          .color = color,
          .dir = direction,
          .text = "",
          .length = static_cast<uint8_t>(text.size()),
          .delay = static_cast<uint16_t>(delayMs.count())}}};

  memcpy(cmd.data.setMatrixTextGroup.text, text.data(), text.size());
  _cmdHandler(cmd);

  return cmd;
}