#include "lumyn/led/LEDCommander.h"

#include "lumyn/util/hashing/IDCreator.h"
#include "lumyn/util/logging/ConsoleLogger.h"

using namespace lumyn::internal;
using namespace Command::LED;

LEDCommand LEDCommander::SetColor(std::string_view zoneID, Command::LED::AnimationColor color)
{
  auto id = IDCreator::createId(zoneID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetColor,
      .data = {.setColor = {
          .zoneId = id,
          .color = color}}};

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand LEDCommander::SetGroupColor(std::string_view groupID, Command::LED::AnimationColor color)
{
  auto id = IDCreator::createId(groupID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetColorGroup,
      .data = {.setColorGroup = {
          .groupId = id,
          .color = color}}};

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand LEDCommander::SetAnimation(std::string_view name, lumyn::led::Animation animation,
                                      Command::LED::AnimationColor color, std::chrono::milliseconds delay,
                                      bool reversed, bool oneShot)
{
  auto id = IDCreator::createId(name);
  std::string msg = "SetAnimation: name=" + std::string(name) +
      ", animation=" + std::string(lumyn::led::kAnimationMap.at(animation)) +
      ", color=(" + std::to_string(color.r) + "," + std::to_string(color.g) + "," + std::to_string(color.b) + ")" +
      ", delay=" +  std::to_string(delay.count()) +
      ", reversed=" + (reversed ? "true" : "false") +
      ", oneShot=" + (oneShot ? "true" : "false") +
      ", id=" + std::to_string(id);

  ConsoleLogger::getInstance().logVerbose("LEDCommander", msg.c_str());
  auto animationId = IDCreator::createId(lumyn::led::kAnimationMap.at(animation));
  ConsoleLogger::getInstance().logVerbose("LEDCommander", "Animation ID: %u", animationId);

  // Zero-init to avoid garbage in packed bitfield padding on some platforms.
  LEDCommand cmd{};
  cmd.type = LEDCommandType::SetAnimation;
  cmd.data.setAnimation.zoneId = id;
  cmd.data.setAnimation.animationId = animationId;
  cmd.data.setAnimation.delay = static_cast<uint16_t>(delay.count());
  cmd.data.setAnimation.color = color;
  cmd.data.setAnimation.reversed = reversed;
  cmd.data.setAnimation.oneShot = oneShot;

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand LEDCommander::SetGroupAnimation(std::string_view name, lumyn::led::Animation animation,
                                           Command::LED::AnimationColor color, std::chrono::milliseconds delay,
                                           bool reversed, bool oneShot)
{
  auto id = IDCreator::createId(name);
  auto animationId = IDCreator::createId(lumyn::led::kAnimationMap.at(animation));

  // Zero-init to avoid garbage in packed bitfield padding on some platforms.
  LEDCommand cmd{};
  cmd.type = LEDCommandType::SetAnimationGroup;
  cmd.data.setAnimationGroup.groupId = id;
  cmd.data.setAnimationGroup.animationId = animationId;
  cmd.data.setAnimationGroup.delay = static_cast<uint16_t>(delay.count());
  cmd.data.setAnimationGroup.color = color;
  cmd.data.setAnimationGroup.reversed = reversed;
  cmd.data.setAnimationGroup.oneShot = oneShot;

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand LEDCommander::SetAnimationSequence(std::string_view zoneID, std::string_view sequenceID)
{
  auto id = IDCreator::createId(zoneID);
  auto sequence = IDCreator::createId(sequenceID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetAnimationSequence,
      .data = {.setAnimationSequence = {
          .zoneId = id,
          .sequenceId = sequence}}};

  _cmdHandler(cmd);

  return cmd;
}

LEDCommand LEDCommander::SetGroupAnimationSequence(std::string_view groupID, std::string_view sequenceID)
{
  auto id = IDCreator::createId(groupID);
  auto sequence = IDCreator::createId(sequenceID);

  LEDCommand cmd = {
      .type = LEDCommandType::SetAnimationSequenceGroup,
      .data = {.setAnimationSequenceGroup = {
          .groupId = id,
          .sequenceId = sequence}}};

  _cmdHandler(cmd);

  return cmd;
}
